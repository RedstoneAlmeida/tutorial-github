<?php
/**
 *
 *   Copyright © 2010-2016 by xhost.ch GmbH
 *
 *   All rights reserved.
 *
 **/
$ajaxServerlist = false;
?>
<?php include dirname(__FILE__).'/../server/_view.php';
