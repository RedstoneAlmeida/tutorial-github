<?php

return array(
    'short'=>'',    //Short language code, for example 'de'
    'english'=>'',  //English name of the language
    'local'=>'',    //Local name of the language
);
