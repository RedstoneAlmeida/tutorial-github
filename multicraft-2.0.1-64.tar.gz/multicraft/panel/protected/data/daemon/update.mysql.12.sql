alter table `server` add `crash_check` varchar(32) not null default '';
