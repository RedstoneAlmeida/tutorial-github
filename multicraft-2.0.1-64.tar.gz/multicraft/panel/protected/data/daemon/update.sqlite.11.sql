alter table `server` add `template` text not null default '';
alter table `server` add `setup` text not null default '';
alter table `server` add `prev_jarfile` text not null default '';
alter table `server` add `params` text not null default '';
