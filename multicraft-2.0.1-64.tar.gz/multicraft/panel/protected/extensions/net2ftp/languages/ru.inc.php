<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2013 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | For credits, see the credits.txt file                                         |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a été copié vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |      if ($net2ftp_globals["state2"] == "rename") {           // <-- PHP code  |
//  |          $net2ftp_messages["Rename file"] = "Rename file";   // <-- message   |
//  |      }                                                       // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------


// -------------------------------------------------------------------------
// Language settings
// -------------------------------------------------------------------------

// HTML lang attribute
$net2ftp_messages["en"] = "ru";

// HTML dir attribute: left-to-right (LTR) or right-to-left (RTL)
$net2ftp_messages["ltr"] = "ltr";

// CSS style: align left or right (use in combination with LTR or RTL)
$net2ftp_messages["left"] = "left";
$net2ftp_messages["right"] = "right";

// Encoding
$net2ftp_messages["iso-8859-1"] = "windows-1251";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------

// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox

$net2ftp_messages["Connecting to the FTP server"] = "Ñîåäèíåíèå ñ FTP-ñåðâåðîì";
$net2ftp_messages["Logging into the FTP server"] = "Âõîä íà FTP-ñåðâåð";
$net2ftp_messages["Setting the passive mode"] = "Óñòàíîâêà ïàññèâíîãî ðåæèìà";
$net2ftp_messages["Getting the FTP system type"] = "Getting the FTP system type";
$net2ftp_messages["Changing the directory"] = "Ñìåíà äèðåêòîðèè";
$net2ftp_messages["Getting the current directory"] = "Ñìåíà òåêóùåé äèðåêòîðèè";
$net2ftp_messages["Getting the list of directories and files"] = "Ïîëó÷åíèå ñïèñêà ïàïîê è ôàéëîâ";
$net2ftp_messages["Parsing the list of directories and files"] = "Îáðàáîòêè ñïèñêà ôàéëîâ è äèðåêòîðèé";
$net2ftp_messages["Logging out of the FTP server"] = "Âûõîä ñ FTP ñåðâåðà";
$net2ftp_messages["Getting the list of directories and files"] = "Ïîëó÷åíèå ñïèñêà ïàïîê è ôàéëîâ";
$net2ftp_messages["Printing the list of directories and files"] = "Âûâîä ñïèñêà ïàïîê è ôàéëîâ";
$net2ftp_messages["Processing the entries"] = "Îáðàáîòêà ñîäåðæàíèÿ";
$net2ftp_messages["Processing entry %1\$s"] = "Îáðàáîòêà çàïèñè %1\$s";
$net2ftp_messages["Checking files"] = "Ïðîâåðêà ôàéëîâ";
$net2ftp_messages["Transferring files to the FTP server"] = "Ïåðåìåùåíèå ôàéëîâ íà FTP-ñåðâåð";
$net2ftp_messages["Decompressing archives and transferring files"] = "Ðàñïàêîâêà àðõèâîâ è ïåðåìåùåíèå ôàéëîâ";
$net2ftp_messages["Searching the files..."] = "Ïîèñê ôàéëà...";
$net2ftp_messages["Uploading new file"] = "Çàêà÷àòü íîâûé ôàéë";
$net2ftp_messages["Reading the file"] = "×òåíèå ôàéëà";
$net2ftp_messages["Parsing the file"] = "Ðåäàêòèðîâàíèå ôàéëà";
$net2ftp_messages["Reading the new file"] = "×òåíèå íîâîãî ôàéëà";
$net2ftp_messages["Reading the old file"] = "×òåíèå ñòàðîãî ôàéëà";
$net2ftp_messages["Comparing the 2 files"] = "Ñðàâíåíèå äâóõ ôàéëîâ";
$net2ftp_messages["Printing the comparison"] = "Âûâîä ðåçóëüòàòà";
$net2ftp_messages["Sending FTP command %1\$s of %2\$s"] = "Îòïðàâêà FTP êîìàíäû %1\$s of %2\$s";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "Ïîëó÷åíèå àðõèâà %1\$s of %2\$s ñ FTP ñåðâåðà";
$net2ftp_messages["Creating a temporary directory on the FTP server"] = "Ñîçäàíèå âðåìåííîé äèðåêòîðèè íà FTP ñåðâåðå";
$net2ftp_messages["Setting the permissions of the temporary directory"] = "Óñòàíîâêà ïðàâ íà âðåìåííóþ äèðåêòîðèþ";
$net2ftp_messages["Copying the net2ftp installer script to the FTP server"] = "Êîïèðîâàíèå óñòàíîâî÷íîãî ñêðèïòà íà FTP ñåðâåð";
$net2ftp_messages["Script finished in %1\$s seconds"] = "Ñêðèïò âûïîëåíåí çà %1\$s ñåêóíä";
$net2ftp_messages["Script halted"] = "Ñêðèïò ïðåðâàí";

// Used on various screens
$net2ftp_messages["Please wait..."] = "Ïîæàëóéñòà, ïîäîæäèòå...";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unexpected state string: %1\$s. Exiting."] = "Íåîæèäàííûé ôîðìàò ñòðîêè: %1\$s. Âûõîä.";
$net2ftp_messages["This beta function is not activated on this server."] = "Ýòà áåòà ôóíêöèÿ íå àêòèâèðîâàíà íà ñåðâåðå.";
$net2ftp_messages["This function has been disabled by the Administrator of this website."] = "Äàííàÿ ôóíêöèÿ îòêëþ÷åíà Àäìèíèñòðàòîðîì.";


// -------------------------------------------------------------------------
// /includes/browse.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the directory <b>%2\$s</b> is shown instead."] = "Äèðåêòîðèÿ <b>%1\$s</b> íå ñóùåñòâóåò èëè íå ìîæåò áûòü âûáðàíà, ïîýòîìó âûáðàíà äèðåêòîðèÿ <b>%2\$s</b> .";
$net2ftp_messages["Your root directory <b>%1\$s</b> does not exist or could not be selected."] = "Âàøà êîðíåâàÿ äèðåêòîðèÿ <b>%1\$s</b> íå ñóùåñòâóåò èëè íå ìîæåò áûòü âûáðàíà.";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected - you may not have sufficient rights to view this directory, or it may not exist."] = "Äèðåêòîðèÿ <b>%1\$s</b> íå ìîæåò áûòü âûáðàíà - ó Âàñ ìîæåò áûòü íåäîñòàòî÷íî ïðàâ äëÿ ïðîñìîòðà èëè äèðåêòîðèÿ íå ñóùåñòâóåò.";
$net2ftp_messages["Entries which contain banned keywords can't be managed using net2ftp. This is to avoid Paypal or Ebay scams from being uploaded through net2ftp."] = "Ñ ïîìîùüþ net2ftp íåëüçÿ óïðàâëÿòü äàííûìè, ñîäåðæàùèìè çàïðåùåííûå ñëîâà. Ýòî íåîáõîäèìî äëÿ çàùèòû îò ïîääåëîê PayPal èëè Ebay.";
$net2ftp_messages["Files which are too big can't be downloaded, uploaded, copied, moved, searched, zipped, unzipped, viewed or edited; they can only be renamed, chmodded or deleted."] = "Ñëèøêîì áîëüøèå ôàéëû íåëüçÿ çàãðóæàòü, ñêà÷èâàòü, êîïèðîâàòü, ïåðåìåùàòü, àðõèâèðîâàòü, ðàñïàêîâûâàòü, ïðîñìàòðèâàòü èëè ðåäàêòèðîâàòü; èõ ìîæíî ïåðåèìåíîâûâàòü, èçìåíÿòü ïðàâà äîñòóïà èëè óäàëÿòü.";
$net2ftp_messages["Execute %1\$s in a new window"] = "Âûïîëíèòü %1\$s â íîâîì îêíå";


// -------------------------------------------------------------------------
// /includes/main.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please select at least one directory or file!"] = "Âûáåðèòå õîòÿ áû îäíó ïàïêó èëè ôàéë.";


// -------------------------------------------------------------------------
// /includes/authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$net2ftp_messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "FTP-ñåðâåð <b>%1\$s</b> íå íàéäåí â ñïèñêå ðàçðåøåííûõ FTP-ñåðâåðîâ.";
$net2ftp_messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "FTP-ñåðâåð <b>%1\$s</b> íàõîäèòñÿ â ñïèñêå çàïðåùåííûõ FTP-ñåðâåðîâ.";
$net2ftp_messages["The FTP server port %1\$s may not be used."] = "Ïîðò FTP-ñåðâåðà %1\$s íå ìîæåò èñïîëüçîâàòüñÿ.";
$net2ftp_messages["Your IP address (%1\$s) is not in the list of allowed IP addresses."] = "Âàø IP-àäðåñ (%1\$s) íå íàõîäèòñÿ â ñïèñêå ðàçðåøåííûõ.";
$net2ftp_messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Âàø IP-àäðåñ (%1\$s) íàõîäèòñÿ â ñïèñêå çàïðåùåííûõ IP-àäðåñîâ.";

// isAuthorizedDirectory()
$net2ftp_messages["Table net2ftp_users contains duplicate rows."] = "Òàáëèöà net2ftp_users ñîäåðæèò îäèíàêîâûå çàïèñè.";

// checkAdminUsernamePassword()
$net2ftp_messages["You did not enter your Administrator username or password."] = "Âû íå óêàçàëè èìÿ ïîëüçîâàòåëÿ èëè ïàðîëü Àäìèíèñòðàòîðà.";
$net2ftp_messages["Wrong username or password. Please try again."] = "Íåïðàâèëüíîå èìÿ ïîëüçîâàòåëÿ èëè ïàðîëü. Ïîæàëóéñòà, ïîïðîáóéòå åùå ðàç.";

// -------------------------------------------------------------------------
// /includes/consumption.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to determine your IP address."] = "Íå óäàåòñÿ ðàñïîçíàòü Âàø ip àäðåñ.";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate rows."] = "Òàáëèöà net2ftp_log_consumption_ipaddress ñîäåðæèò îäèíàêîâûå çàïèñè.";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate rows."] = "Òàáëèöà net2ftp_log_consumption_ftpserver ñîäåðæèò îäèíàêîâûå çàïèñè.";
$net2ftp_messages["The variable <b>consumption_ipaddress_datatransfer</b> is not numeric."] = "Ïåðåìåííàÿ <b>consumption_ipaddress_datatransfer</b> íå ÿâëÿåòñÿ ÷èñëîì.";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress could not be updated."] = "Íå óäàëîñü îáíîâèòü òàáëèöó net2ftp_log_consumption_ipaddress.";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate entries."] = "Òàáëèöà net2ftp_log_consumption_ipaddress ñîäåðæèò îäèíàêîâûå çàïèñè.";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver could not be updated."] = "Íå óäàëîñü îáíîâèòü òàáëèöó net2ftp_log_consumption_ftpserver.";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate entries."] = "Table net2ftp_log_consumption_ftpserver contains duplicate entries.";
$net2ftp_messages["Table net2ftp_log_access could not be updated."] = "Íå óäàëîñü îáíîâèòü òàáëèöó net2ftp_log_access.";
$net2ftp_messages["Table net2ftp_log_access contains duplicate entries."] = "Òàáëèöà net2ftp_log_access ñîäåðæèò îäèíàêîâûå çàïèñè.";


// -------------------------------------------------------------------------
// /includes/database.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to connect to the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "Íåâîçìîæíî ñîåäèíèòüñÿ ñ ñåðâåðîì MySQL. Ïðîâåðüòå ïàðàìåòðû ïîäêëþ÷åíèÿ â ôàéëå settings.inc.php.";
$net2ftp_messages["Unable to select the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "Unable to select the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php.";


// -------------------------------------------------------------------------
// /includes/errorhandling.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["An error has occured"] = "Ïðîèçîøëà îøèáêà";
$net2ftp_messages["Go back"] = "Íàçàä";
$net2ftp_messages["Go to the login page"] = "Íà ñòðàíèöó âõîäà";


// -------------------------------------------------------------------------
// /includes/filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Íå óäàëîñü ñîåäèíèòüñÿ ñ FTP-ñåðâåðîì <b>%1\$s</b> íà ïîðòó <b>%2\$s</b>.<br /><br />Ïðàâèëüíûé ëè àäðåñ FTP-ñåðâåðà? Îí ÷àñòî îòëè÷àåòñÿ îò àäðåñà HTTP-ñåðâåðà. Ïîæàëóéñòà, ñâÿæèòåñü ñ ïîääåðæêîé âàøåãî ISP èëè ñ ñèñòåìíûì àäìèíèñòðàòîðîì.<br />";
$net2ftp_messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Íå óäàëîñü âîéòè íà FTP-ñåðâåð <b>%1\$s</b> ñ ëîãèíîì <b>%2\$s</b>.<br /><br />Ïðàâèëüíû ëè ëîãèí è ïàðîëü? Ïîæàëóéñòà, ñâÿæèòåñü ñ òåõïîääåðæêîé âàøåãî ISP èëè ñèñàäìèíîì.<br />";
$net2ftp_messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Íå óäàëîñü ïåðåêëþ÷èòüñÿ â ïàññèâíûé ðåæèì FTP <b>%1\$s</b>.";

// ftp_openconnection2()
$net2ftp_messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Íå óäàëîñü ñîåäèíèòüñÿ ñî âòîðûì FTP-ñåðâåðîì <b>%1\$s</b> íà ïîðòó <b>%2\$s</b>.<br /><br />Ïðàâèëåí ëè àäðåñ FTP-ñåðâåðà? Îí ÷àñòî îòëè÷àåòñÿ îò àäðåñà HTTP-ñåðâåðà. Ïîæàëóéñòà, ñâÿæèòåñü ñ âàøèì ISP èëè ñèñòåìíûì àäìèíèñòðàòîðîì.<br />";
$net2ftp_messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Íå óäàëîñü ñîåäèíèòüñÿ ñî âòîðûì FTP-ñåðâåðîì <b>%1\$s</b> ñ ëîãèíîì <b>%2\$s</b>.<br /><br />Ïðàâèëüíû ëè èìÿ ïîëüçîâàòåëÿ è ïàðîëü? Ñâÿæèòåñü ñ âàøèì ISP èëè ñèñòåìíûì àäìèíèñòðàòîðîì.<br />";
$net2ftp_messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Íå óäàëîñü ïåðåêëþ÷èòüñÿ â ïàññèâíûé ðåæèì íà âòîðîì FTP <b>%1\$s</b>.";

// ftp_myrename()
$net2ftp_messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Íå óäàëîñü ïåðåèìåíîâàòü ïàïêó èëè ôàéë <b>%1\$s</b> â <b>%2\$s</b>";

// ftp_mychmod()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Íå óäàëîñü âûïîëíèòü êîìàíäó <b>%1\$s</b>. Êîìàíäà CHMOD äîñòóïíà òîëüêî íà Unix-ñåðâåðàõ.";
$net2ftp_messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Ïàïêà <b>%1\$s</b> óñïåøíî chmodded <b>%2\$s</b>";
$net2ftp_messages["Processing entries within directory <b>%1\$s</b>:"] = "Îáðàáîòêà ôàéëîâ äèðåêòîðèé <b>%1\$s</b>:";
$net2ftp_messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "Ôàéë <b>%1\$s</b> óñïåøíî chmodded <b>%2\$s</b>";
$net2ftp_messages["All the selected directories and files have been processed."] = "Âñå âûáðàííûå ïàïêè è ôàéëû ïðîâåðåíû.";

// ftp_rmdir2()
$net2ftp_messages["Unable to delete the directory <b>%1\$s</b>"] = "Íå óäàëîñü óäàëèòü ïàïêó <b>%1\$s</b>";

// ftp_delete2()
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "Íå óäàëîñü óäàëèòü ôàéë <b>%1\$s</b>";

// ftp_newdirectory()
$net2ftp_messages["Unable to create the directory <b>%1\$s</b>"] = "Íå óäàëîñü ñîçäàòü ïàïêó <b>%1\$s</b>";

// ftp_readfile()
$net2ftp_messages["Unable to create the temporary file"] = "Íå óäàëîñü ñîçäàòü âðåìåííûé ôàéë";
$net2ftp_messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Íå óäàëîñü ñêà÷àòü ôàéë <b>%1\$s</b> ñ FTP-ñåðâåðà è ñîõðàíèòü åãî êàê âðåìåííûé ôàéë <b>%2\$s</b>.<br />Ïðîâåðüòå ðàçðåøåíèÿ ïàïêè %3\$s.<br />";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Íå óäàëîñü îòêðûòü ôàéë. Ïðîâåðüòå ðàçðåøåíèÿ ïàïêè %1\$s.";
$net2ftp_messages["Unable to read the temporary file"] = "Íå óäàëîñü ïðî÷èòàòü âðåìåííûé ôàéë";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "Íå óäàëîñü çàêðûòü âðåìåííûé ôàéë";
$net2ftp_messages["Unable to delete the temporary file"] = "Íå óäàëîñü óäàëèòü âðåìåííûé ôàéë";

// ftp_writefile()
$net2ftp_messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Íå óäàëîñü ñîçäàòü âðåìåííûé ôàéë. Ïðîâåðüòå ðàçðåøåíèÿ ïàïêè %1\$s.";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Íå óäàëîñü îòêðûòü ôàéë. Ïðîâåðüòå ðàçðåøåíèÿ ïàïêè %1\$s.";
$net2ftp_messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Íå óäàëîñü çàïèñàòü ñòðîêó âî âðåìåííûé ôàéë <b>%1\$s</b>.<br />Ïðîâåðüòå ðàçðåøåíèÿ ïàïêè %2\$s.";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "Íå óäàëîñü çàêðûòü âðåìåííûé ôàéë";
$net2ftp_messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Íå óäàëîñü çàêà÷àòü ôàéë <b>%1\$s</b> íà FTP-ñåðâåð.<br />Âîçìîæíî, ó âàñ íåò ïðàâ.";
$net2ftp_messages["Unable to delete the temporary file"] = "Íå óäàëîñü óäàëèòü âðåìåííûé ôàéë";

// ftp_copymovedelete()
$net2ftp_messages["Processing directory <b>%1\$s</b>"] = "Ïðîâåðêà ïàïêè <b>%1\$s</b>";
$net2ftp_messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "Ïàïêà íàçíà÷åíèÿ <b>%1\$s</b> ñîâïàäàåò ñ ïîäïàïêîé <b>%2\$s</b>, ñëåäîâàòåëüíî îíà áóäòå ïðîïóùåíà";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, so this directory will be skipped"] = "Äèðåêòîðèÿ <b>%1\$s</b> ñîäåðæèò çàïðåùåííîå ñëîâî, ïîýòîìó äèðåêòîðèÿ áóäåò ïðîïóùåíà";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, aborting the move"] = "Äèðåêòîðèÿ <b>%1\$s</b> ñîäåðæèò çàïðåùåííîå ñëîâî, ïåðåìåùåíèå íå áóäåò âûïîëíåíî";
$net2ftp_messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Íå óäàëîñü ñîçäàòü ïîäïàïêó <b>%1\$s</b>. Îíà óæå ñóùåñòâóåò. Ïðîäîëæåíèå ïðîöåññà...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected, so this directory will be skipped"] = "Äèðåêòîðèÿ <b>%1\$s</b> íå ìîæåò áûòü âûáðàíà, ïîýòîìó îíà áóäåò ïðîïóùåíà";
$net2ftp_messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Íå óäàëîñü óäàëèòü ïîäïàïêó <b>%1\$s</b> - îíà íå ïóñòà";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "Óäàëåíà ïîäïàïêà <b>%1\$s</b>";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "Óäàëåíà ïîäïàïêà <b>%1\$s</b>";
$net2ftp_messages["Unable to move the directory <b>%1\$s</b>"] = "Unable to move the directory <b>%1\$s</b>";
$net2ftp_messages["Moved directory <b>%1\$s</b>"] = "Moved directory <b>%1\$s</b>";
$net2ftp_messages["Processing of directory <b>%1\$s</b> completed"] = "Ïðîâåðêà ïàïêè <b>%1\$s</b> çàâåðøåíà";
$net2ftp_messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "Ôàéë íàçíà÷åíèÿ <b>%1\$s</b> ñîâïàäàåò ñ èñõîäíûì ôàéëîì, îí áóäåò ïðîïóùåí";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, so this file will be skipped"] = "Ôàéë <b>%1\$s</b> ñîäåðæèò çàïðåùåííûå ñëîâà, ïîýòîìó ôàéë áóäåò ïðîïóùåí";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, aborting the move"] = "Ôàéë <b>%1\$s</b> ñîäåðæèò çàïðåùåííûå ñëîâà, ôàéë íå áóäåò ïåðåìåùåí";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be copied, so this file will be skipped"] = "Ôàéë <b>%1\$s</b> ñëèøêîì áîëüøîé äëÿ êîïèðîâàíèÿ, ïîýòîìó îí áóäåò ïðîïóùåí";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be moved, aborting the move"] = "Ôàéë <b>%1\$s</b> ñëèøêîì áîëüøîé äëÿ ïåðåìåùåíèÿ, ïåðåìåùåíèå íå áóäåò âûïîëíåíî";
$net2ftp_messages["Unable to copy the file <b>%1\$s</b>"] = "Íå óäàëîñü ñêîïèðîâàòü ôàéë <b>%1\$s</b>";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>, aborting the move"] = "Íå óäàëîñü ïåðåìåñòèòü ôàéë <b>%1\$s</b>, ïåðåìåùåíèå íå âûïîëíåíî.";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>"] = "Unable to move the file <b>%1\$s</b>";
$net2ftp_messages["Moved file <b>%1\$s</b>"] = "Ïåðåìåùåí ôàéë <b>%1\$s</b>";
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "Íå óäàëîñü óäàëèòü ôàéë <b>%1\$s</b>";
$net2ftp_messages["Deleted file <b>%1\$s</b>"] = "Óäàëåí ôàéë <b>%1\$s</b>";
$net2ftp_messages["All the selected directories and files have been processed."] = "Âñå âûáðàííûå ïàïêè è ôàéëû ïðîâåðåíû.";

// ftp_processfiles()

// ftp_getfile()
$net2ftp_messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Íå óäàëîñü ñêîïèðîâàòü óäàëåííûé ôàéë <b>%1\$s</b> íà ëîêàëüíûé êîìïüþòåð, èñïîëüçóÿ FTP-ht;bv <b>%2\$s</b>";
$net2ftp_messages["Unable to delete file <b>%1\$s</b>"] = "Íå óäàëîñü óäàëèòü ôàéë <b>%1\$s</b>";

// ftp_putfile()
$net2ftp_messages["The file is too big to be transferred"] = "Ôàéë ñëèøêîì âåëèê äëÿ ïåðåäà÷è.";
$net2ftp_messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Äîñòèãíóò ñóòî÷íûé ëèìèò: ôàéë <b>%1\$s</b> íå áóäåò ïåðåäàí";
$net2ftp_messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Íå óäàëîñü ñêîïèðîâàòü ëîêàëüíûé ôàéë <b>%1\$s</b> íà óäàëåííûé êîìïüþòåð, èñïîëüçóÿ ðåæèì <b>%2\$s</b>";
$net2ftp_messages["Unable to delete the local file"] = "Íå óäàëîñü óäàëèòü ëîêàëüíûé ôàéë";

// ftp_downloadfile()
$net2ftp_messages["Unable to delete the temporary file"] = "Íå óäàëîñü óäàëèòü âðåìåííûé ôàéë";
$net2ftp_messages["Unable to send the file to the browser"] = "Íåâîçìîæíî ïåðåäàòü ôàéë áðàóçåðó";

// ftp_zip()
$net2ftp_messages["Unable to create the temporary file"] = "Íå óäàëîñü ñîçäàòü âðåìåííûé ôàéë";
$net2ftp_messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "Zip-ôàéë ñîõðàíåí íà FTP-ñåðâåðå êàê <b>%1\$s</b>";
$net2ftp_messages["Requested files"] = "Çàïðîøåííûé ôàéëû";

$net2ftp_messages["Dear,"] = "Óâàæàåìûé,";
$net2ftp_messages["Someone has requested the files in attachment to be sent to this email account (%1\$s)."] = "Êòî-òî (âîçìîæíî Âû) îòïðàâèë ôàéëû, ïðèëîæåííûå ê ïèñüìó, íà ýòîò àäðåñ (%1\$s).";
$net2ftp_messages["If you know nothing about this or if you don't trust that person, please delete this email without opening the Zip file in attachment."] = "Åñëè Âû íå çíàåòå, ÷òî ýòî çà ôàéëû, èëè íå äîâåðÿåòå îòïðàâèòåëþ, ïîæàëóéñòà, óäàëèòå ýòî ïèñüìî, íå îòêðûâàÿ ôàéëû.";
$net2ftp_messages["Note that if you don't open the Zip file, the files inside cannot harm your computer."] = "Åñëè Âû íå áóäåòå îòêðûâàòü zip-ôàéë, ôàéëû, ñîäåðæàùèåñÿ â í¸ì, íå ñìîãóò ïîâðåäèòü Âàøåìó êîìïüþòåðó.";
$net2ftp_messages["Information about the sender: "] = "Èíôîðìàöèÿ î îòïðàâèòåëå: ";
$net2ftp_messages["IP address: "] = "IP-àäðåñ: ";
$net2ftp_messages["Time of sending: "] = "Âðåìÿ îòïðàâêè: ";
$net2ftp_messages["Sent via the net2ftp application installed on this website: "] = "Îòïðàâëåíî ÷åðåç net2ftp ñ ñàéòà ";
$net2ftp_messages["Webmaster's email: "] = "Àäðåñ Âåá-ìàñòåðà: ";
$net2ftp_messages["Message of the sender: "] = "Message of the sender: ";
$net2ftp_messages["net2ftp is free software, released under the GNU/GPL license. For more information, go to http://www.net2ftp.com."] = "net2ftp áåñïëàòíîå ÏÎ, âûïóñêàåìîå ïîä ëèöåíçèåé GNU/GPL. Áîëåå ïîäðîáíàÿ èíôîðìàöèÿ íàõîäèòñÿ ïî àäðåñó http://www.net2ftp.com.";

$net2ftp_messages["The zip file has been sent to <b>%1\$s</b>."] = "Zip-ôàéë îòïðàâëåí <b>%1\$s</b>.";

// acceptFiles()
$net2ftp_messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "Ôàéë <b>%1\$s</b> ñëèøêîì áîëüøîé. Ôàéë íå áóäåò çàãðóæåí.";
$net2ftp_messages["File <b>%1\$s</b> is contains a banned keyword. This file will not be uploaded."] = "Ôàéë <b>%1\$s</b> ñîäåðæèò çàïðåùåííûå ñëîâà. Ôàéë íå áóäåò çàãðóæåí.";
$net2ftp_messages["Could not generate a temporary file."] = "Íå óäàëîñü ñãåíåðèðîâàòü âðåìåííûé ôàéë.";
$net2ftp_messages["File <b>%1\$s</b> could not be moved"] = "Ôàéë <b>%1\$s</b> íå ìîæåò áûòü ïåðåìåùåí";
$net2ftp_messages["File <b>%1\$s</b> is OK"] = "Ôàéë <b>%1\$s</b> Ok";
$net2ftp_messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Íå óäàëîñü ïåðåìåñòèòü çàêà÷àííûé ôàéë âî âðåìåííóþ ïàïêó.<br /><br />Àäìèíèñòðàòîðó ñàéòà íàäî ñìåíèòü <b>chmod</b> íà <b>777</b> ïàïêè /temp.";
$net2ftp_messages["You did not provide any file to upload."] = "Âû íå âûáðàëè ôàéë.";

// ftp_transferfiles()
$net2ftp_messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "Ôàéë <b>%1\$s</b> íå ìîæåò áûòü çàêà÷àí íà FTP-ñåðâåð";
$net2ftp_messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "Ôàéë <b>%1\$s</b> áûë çàêà÷àí íà FTP-ñåðâåð, èñïîëüçóÿ FTP-ðåæèì <b>%2\$s</b>";
$net2ftp_messages["Transferring files to the FTP server"] = "Ïåðåìåùåíèå ôàéëîâ íà FTP-ñåðâåð";

// ftp_unziptransferfiles()
$net2ftp_messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Ïðîâåðêà àðõèâà nr %1\$s: <b>%2\$s</b>";
$net2ftp_messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "Àðõèâ <b>%1\$s</b> íå áûë ïðîâåðåí, ïîòîìó ÷òî ðàñøèðåíèå ôàéëà íåïðàâèëüíî. Òîëüêî zip, tar, tgz è gz àðõèâû ïîääåðæèâàþòñÿ.";
$net2ftp_messages["Unable to extract the files and directories from the archive"] = "Íå óäàëîñü èçâëå÷ü ôàéëû èç àðõèâà";
$net2ftp_messages["Archive contains filenames with ../ or ..\\ - aborting the extraction"] = "Archive contains filenames with ../ or ..\\ - aborting the extraction";
$net2ftp_messages["Could not unzip entry %1\$s (error code %2\$s)"] = "Could not unzip entry %1\$s (error code %2\$s)";
$net2ftp_messages["Created directory %1\$s"] = "Ñîçäàíà äèðåêòîðèÿ %1\$s";
$net2ftp_messages["Could not create directory %1\$s"] = "Íå óäàëîñòü ñîçäàòü äèðåêòîðèþ %1\$s";
$net2ftp_messages["Copied file %1\$s"] = "Ñêîïèðîâàí ôàéë %1\$s";
$net2ftp_messages["Could not copy file %1\$s"] = "Íå óäàëîñü ñêîïèðîâàòü ôàéë %1\$s";
$net2ftp_messages["Unable to delete the temporary directory"] = "Íå óäàëîñü óäàëèòü âðåìåííóþ äèðåêòîðèþ";
$net2ftp_messages["Unable to delete the temporary file %1\$s"] = "Íå óäàëîñü óäàëèòü âðåìåííûé ôàéë %1\$s";

// ftp_mysite()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>"] = "Íå óäàëîñü âûïîëíèòü êîìàíäó <b>%1\$s</b>";

// shutdown()
$net2ftp_messages["Your task was stopped"] = "Âàøå çàäàíèå îñòàíîâëåíî";
$net2ftp_messages["The task you wanted to perform with net2ftp took more time than the allowed %1\$s seconds, and therefor that task was stopped."] = "Çàäàíèå, êîòîðîå âû õîòåëè ïðåêðàòèòü ÷åðåç net2ftp çàéìåò áîëüøå %1\$s ðàçðåøåííûõ ñåêóíä. Âûïîëíåíèå îñòàíîâëåíî.";
$net2ftp_messages["This time limit guarantees the fair use of the web server for everyone."] = "Ýòî îãðàíè÷åíèå âðåìåíè ïîçâîëÿåò ïîëüçîâàòüñÿ ñåðâåðîì áåç ïåðåáîåâ.";
$net2ftp_messages["Try to split your task in smaller tasks: restrict your selection of files, and omit the biggest files."] = "Ïîïðîáóéòå ðàçäåëèòü çàäàíèå: íàïðèìåð, çàïðåòèòå âûáîð îòäåëüíûõ ôàéëîâ.";
$net2ftp_messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "Åñëè âû äåéñòâèòåëüíî õîòèòå âûïîëíèòü ýòî çàäàíèå ÷åðåç net2ftp, òî óñòàíîâèòå net2ftp íà ñîáñòâåííîì ñåðâåðå.";

// SendMail()
$net2ftp_messages["You did not provide any text to send by email!"] = "Íåò òåêñòà äëÿ îòïðàâêè ïî ýëåêòðîííîé ïî÷òå!";
$net2ftp_messages["You did not supply a From address."] = "Âû íå óêàçàëè àäðåñ îòïðàâèòåëÿ.";
$net2ftp_messages["You did not supply a To address."] = "Âû íå óêàçàëè àäðåñ ïîëó÷àòåëÿ.";
$net2ftp_messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "Â ñâÿçè ñ òåõíè÷åñêèìè ïðîáëåìàìè email äëÿ <b>%1\$s</b> íå ìîæåò áûòü îòïðàâëåí.";

// tempdir2()
$net2ftp_messages["Unable to create a temporary directory because (unvalid parent directory)"] = "Unable to create a temporary directory because (unvalid parent directory)";
$net2ftp_messages["Unable to create a temporary directory because (parent directory is not writeable)"] = "Unable to create a temporary directory because (parent directory is not writeable)";
$net2ftp_messages["Unable to create a temporary directory (too many tries)"] = "Unable to create a temporary directory (too many tries)";

// -------------------------------------------------------------------------
// /includes/logging.inc.php
// -------------------------------------------------------------------------
// logAccess(), logLogin(), logError()
$net2ftp_messages["Unable to execute the SQL query."] = "Íå óäàåòñÿ âûïîëíèòü SQL çàïðîñ.";
$net2ftp_messages["Unable to open the system log."] = "Unable to open the system log.";
$net2ftp_messages["Unable to write a message to the system log."] = "Unable to write a message to the system log.";

// getLogStatus(), putLogStatus()
$net2ftp_messages["Table net2ftp_log_status contains duplicate entries."] = "Table net2ftp_log_status contains duplicate entries.";
$net2ftp_messages["Table net2ftp_log_status could not be updated."] = "Table net2ftp_log_status could not be updated.";

// rotateLogs()
$net2ftp_messages["The log tables were renamed successfully."] = "The log tables were renamed successfully.";
$net2ftp_messages["The log tables could not be renamed."] = "The log tables could not be renamed.";
$net2ftp_messages["The log tables were copied successfully."] = "The log tables were copied successfully.";
$net2ftp_messages["The log tables could not be copied."] = "The log tables could not be copied.";
$net2ftp_messages["The oldest log table was dropped successfully."] = "The oldest log table was dropped successfully.";
$net2ftp_messages["The oldest log table could not be dropped."] = "The oldest log table could not be dropped.";


// -------------------------------------------------------------------------
// /includes/registerglobals.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please enter your username and password for FTP server "] = "Ïîæàëóéñòà, ââåäèòå Âàø ëîãèí è ïàðîëü îò FTP ñåðâåðà";
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Âû íå çàïîëíèëè ôîðìó ëîãèíà âî âñïëûâàþùåì îêíå.<br />Íàæìèòå íà ññûëêó \"Íà ãëàâíóþ ñòðàíèöó\" íèæå.";
$net2ftp_messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "Äîñòóï ê ïàíåëè Àäìèíèñòðàòîðà net2ftp çàáëîêèðîâàí, ïîòîìó ÷òî â ôàéëå settings.inc.php íå óêàçàí ïàðîëü äëÿ âõîäà. Óñòàíîâèòå ïàðîëü â ýòîì ôàéëå è îáíîâèòå ñòðàíèöó.";
$net2ftp_messages["Please enter your Admin username and password"] = "Ïîæàëóéñòà, ââåäèòå ëîãèí è ïàðîëü Àäìèíèñòðàòîðà."; 
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Âû íå çàïîëíèëè ôîðìó ëîãèíà âî âñïëûâàþùåì îêíå.<br />Íàæìèòå íà ññûëêó \"Íà ãëàâíóþ ñòðàíèöó\" íèæå.";
$net2ftp_messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "Íåâåðíûé ëîãèí èëè ïàðîëü äëÿ âõîäà â ïàíåëü Àäìèíèñòðàòîðà net2ftp. Ëîãèí è ïàðîëü óêàçûâàþòñÿ â ôàéëå settings.inc.php.";


// -------------------------------------------------------------------------
// /skins/skins.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Blue"] = "Ñèíèé";
$net2ftp_messages["Grey"] = "Ñåðûé";
$net2ftp_messages["Black"] = "×åðíûé";
$net2ftp_messages["Yellow"] = "Æåëòûé";
$net2ftp_messages["Pastel"] = "Ïàñòåëüíûé";

// getMime()
$net2ftp_messages["Directory"] = "Ïàïêà";
$net2ftp_messages["Symlink"] = "Ññûëêà";
$net2ftp_messages["ASP script"] = "Ñêðèïò ASP";
$net2ftp_messages["Cascading Style Sheet"] = "CSS";
$net2ftp_messages["HTML file"] = "Ôàéë HTML";
$net2ftp_messages["Java source file"] = "Êîä Java";
$net2ftp_messages["JavaScript file"] = "Ôàéë JavaScript";
$net2ftp_messages["PHP Source"] = "PHP êîä";
$net2ftp_messages["PHP script"] = "Ñêðèïò PHP";
$net2ftp_messages["Text file"] = "Òåêñò";
$net2ftp_messages["Bitmap file"] = "Èçîáðàæåíèå";
$net2ftp_messages["GIF file"] = "GIF";
$net2ftp_messages["JPEG file"] = "JPEG";
$net2ftp_messages["PNG file"] = "PNG";
$net2ftp_messages["TIF file"] = "TIF";
$net2ftp_messages["GIMP file"] = "Ôàéë GIMP";
$net2ftp_messages["Executable"] = "Ïðèëîæåíèå";
$net2ftp_messages["Shell script"] = "Ñêðèïò shell";
$net2ftp_messages["MS Office - Word document"] = "MS Office - äîêóìåíò Word";
$net2ftp_messages["MS Office - Excel spreadsheet"] = "MS Office - òàáëèöà Excel";
$net2ftp_messages["MS Office - PowerPoint presentation"] = "MS Office - ïðåçåíòàöèÿ PowerPoint";
$net2ftp_messages["MS Office - Access database"] = "MS Office - ÁÄ Access";
$net2ftp_messages["MS Office - Visio drawing"] = "MS Office - ðèñóíîê Visio";
$net2ftp_messages["MS Office - Project file"] = "MS Office - ôàéë ïðîåêòà";
$net2ftp_messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - äîêóìåíò Writer 6.0";
$net2ftp_messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - øàáëîí Writer 6.0";
$net2ftp_messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - òàáëèöà Calc 6.0";
$net2ftp_messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - øàáëîí Calc 6.0";
$net2ftp_messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - äîêóìåíò Draw 6.0";
$net2ftp_messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - øàáëîí Draw 6.0";
$net2ftp_messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - ïðåçåíòàöèÿ Impress 6.0";
$net2ftp_messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - øàáëîí Impress 6.0";
$net2ftp_messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - äîêóìåíò Writer 6.0";
$net2ftp_messages["OpenOffice - Math 6.0 document"] = "OpenOffice - äîêóìåíò Math 6.0";
$net2ftp_messages["StarOffice - StarWriter 5.x document"] = "StarOffice - äîêóìåíò StarWriter 5.x";
$net2ftp_messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - äîêóìåíò StarWriter 5.x";
$net2ftp_messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - òàáëèöà StarCalc 5.x";
$net2ftp_messages["StarOffice - StarDraw 5.x document"] = "StarOffice - äîêóìåíò StarDraw 5.x";
$net2ftp_messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - ïðåçåíòàöèÿ StarImpress 5.x";
$net2ftp_messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - ôàéë StarImpress Packed 5.x";
$net2ftp_messages["StarOffice - StarMath 5.x document"] = "StarOffice - äîêóìåíò StarMath 5.x";
$net2ftp_messages["StarOffice - StarChart 5.x document"] = "StarOffice - äîêóìåíò StarChart 5.x";
$net2ftp_messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - ôàéë ïî÷òû StarMail 5.x";
$net2ftp_messages["Adobe Acrobat document"] = "Äîêóìåíò Adobe Acrobat";
$net2ftp_messages["ARC archive"] = "ARC-àðõèâ";
$net2ftp_messages["ARJ archive"] = "ARJ-àðõèâ";
$net2ftp_messages["RPM"] = "RPM";
$net2ftp_messages["GZ archive"] = "GZ-àðõèâ";
$net2ftp_messages["TAR archive"] = "TAR-àðõèâ";
$net2ftp_messages["Zip archive"] = "Zip-àðõèâ";
$net2ftp_messages["MOV movie file"] = "Ôèëüì MOV";
$net2ftp_messages["MPEG movie file"] = "Ôèëüì MPEG";
$net2ftp_messages["Real movie file"] = "Ôèëüì â ôîðìàòå Real";
$net2ftp_messages["Quicktime movie file"] = "Ôèëüì Quicktime";
$net2ftp_messages["Shockwave flash file"] = "ÔàéëShockwave flash";
$net2ftp_messages["Shockwave file"] = "Ôàéë Shockwave";
$net2ftp_messages["WAV sound file"] = "Çâóê WAV";
$net2ftp_messages["Font file"] = "Ôàéë øðèôòà";
$net2ftp_messages["%1\$s File"] = "%1\$s ôàéë";
$net2ftp_messages["File"] = "Ôàéë";

// getAction()
$net2ftp_messages["Back"] = "Íàçàä";
$net2ftp_messages["Submit"] = "Îòïðàâèòü";
$net2ftp_messages["Refresh"] = "Îáíîâèòü";
$net2ftp_messages["Details"] = "Äåòàëè";
$net2ftp_messages["Icons"] = "Çíà÷êè";
$net2ftp_messages["List"] = "Ñïèñîê";
$net2ftp_messages["Logout"] = "Âûõîä";
$net2ftp_messages["Help"] = "Ïîìîùü";
$net2ftp_messages["Bookmark"] = "Çàêëàäêà";
$net2ftp_messages["Save"] = "Ñîõðàíèòü";
$net2ftp_messages["Default"] = "Ïî óìîë÷àíèþ";


// -------------------------------------------------------------------------
// /skins/[skin]/header.template.php and footer.template.php
// -------------------------------------------------------------------------
$net2ftp_messages["Help Guide"] = "Ïîìîùü";
$net2ftp_messages["Forums"] = "Ôîðóìû";
$net2ftp_messages["License"] = "Ëèöåíçèÿ";
$net2ftp_messages["Powered by"] = "Ñîçäàíî íà";
$net2ftp_messages["You are now taken to the net2ftp forums. These forums are for net2ftp related topics only - not for generic webhosting questions."] = "Âû íàïðàâëåíû íà ôîðóì net2ftp. Ýòîò ôîðóì òîëüêî äëÿ îáñóæäåíèÿ net2ftp, îí íå ïðåäíàçíà÷åí äëÿ îáñóæäåíèÿ îáùèõ îïðîñîâ õîñòèíãà.";
$net2ftp_messages["Standard"] = "Standard";
$net2ftp_messages["Mobile"] = "Mobile";

// -------------------------------------------------------------------------
// Admin module
if ($net2ftp_globals["state"] == "admin") {
// -------------------------------------------------------------------------

// /modules/admin/admin.inc.php
$net2ftp_messages["Admin functions"] = "Ôóíêöèè àäìèíèñòðàòîðà";

// /skins/[skin]/admin1.template.php
$net2ftp_messages["Version information"] = "Èíôîðìàöèÿ î âåðñèè";
$net2ftp_messages["This version of net2ftp is up-to-date."] = "Ó Âàñ óñòàíîâëåíà ïîñëåäíÿÿ âåðñèÿ net2ftp.";
$net2ftp_messages["The latest version information could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "Íå óäàëîñü ïîëó÷èòü èíôîðìàöèÿ î ïîñëåäíåé âåðñèè ñ ñàéòà net2ftp.com. Ïðîâåðüòå íàñòðîéêè áåçîïàñíîñòè Âàøåãî áðàóçåðà, êîòîðûå ìîãóò ïðåïÿòñòâîâàòü çàãðóçêå íåáîëüøîãî ôàéëà ñ net2ftp.com.";
$net2ftp_messages["Logging"] = "Ëîãèðîâàíèå ";
$net2ftp_messages["Date from:"] = "Date from:";
$net2ftp_messages["to:"] = "to:";
$net2ftp_messages["Empty logs"] = "Î÷èñòèòü ëîãè";
$net2ftp_messages["View logs"] = "Ïðîñìîòð ëîãîâ";
$net2ftp_messages["Go"] = "Âïåðåä";
$net2ftp_messages["Setup MySQL tables"] = "Íàñòðîèòü òàáëèöû MySQL";
$net2ftp_messages["Create the MySQL database tables"] = "Ñîçäàòü òàáëèöû â áàçå äàííûõ MySQL";

} // end admin

// -------------------------------------------------------------------------
// Admin_createtables module
if ($net2ftp_globals["state"] == "admin_createtables") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_createtables.inc.php
$net2ftp_messages["Admin functions"] = "Ôóíêöèè àäìèíèñòðàòîðà";
$net2ftp_messages["The handle of file %1\$s could not be opened."] = "Íå óäàëîñü îòêðûòü óêàçàòåëü äëÿ ôàéëà %1\$s";
$net2ftp_messages["The file %1\$s could not be opened."] = "Ôàéë %1\$s íå ìîæåò áûòü îòêðûò.";
$net2ftp_messages["The handle of file %1\$s could not be closed."] = "Íå óäàëîñü çàêðûòü óêàçàòåëü íà ôàéë %1\$s";
$net2ftp_messages["The connection to the server <b>%1\$s</b> could not be set up. Please check the database settings you've entered."] = "Íå óäà¸òñÿ ñîåäèíèòüñÿ ñ ñåðâåðîì <b>%1\$s</b>. Ïîæàëóéñòà, ïðîâåðüòå ââåä¸ííûå ïàðàìåòðû ñîåäèíåíèÿ.";
$net2ftp_messages["Unable to select the database <b>%1\$s</b>."] = "Íå óäàåòñÿ âûáðàòü áàçó äàííûõ <b>%1\$s</b>.";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> could not be executed."] = "SQL-çàïðîñ <b>%1\$s</b> íå ìîæåò áûòü âûïîëíåí.";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> was executed successfully."] = "SQL-çàïðîñ <b>%1\$s</b> áûë óñïåøíî âûïîëíåí.";

// /skins/[skin]/admin_createtables1.template.php
$net2ftp_messages["Please enter your MySQL settings:"] = "Ïîæàëóéñòà, óêàæèòå ïàðàìåòðû ðàáîòû ñ MySQL:";
$net2ftp_messages["MySQL username"] = "Èìÿ ïîëüçîâàòåëÿ MySQL";
$net2ftp_messages["MySQL password"] = "Ïàðîëü MySQL";
$net2ftp_messages["MySQL database"] = "Áàçà äàííûõ MySQL";
$net2ftp_messages["MySQL server"] = "MySQL server";
$net2ftp_messages["This SQL query is going to be executed:"] = "Áóäåò âûïîëíåí ñëåäóþùèé SQL-çàïðîñ:";
$net2ftp_messages["Execute"] = "Âûïîëíèòü";

// /skins/[skin]/admin_createtables2.template.php
$net2ftp_messages["Settings used:"] = "Èñïîëüçóåìûå íàñòðîéêè:";
$net2ftp_messages["MySQL password length"] = "Äëèíà ïàðîëÿ MySQL";
$net2ftp_messages["Results:"] = "Ðåçóëüòàòû:";

} // end admin_createtables


// -------------------------------------------------------------------------
// Admin_viewlogs module
if ($net2ftp_globals["state"] == "admin_viewlogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_viewlogs.inc.php
$net2ftp_messages["Admin functions"] = "Ôóíêöèè àäìèíèñòðàòîðà";
$net2ftp_messages["Unable to execute the SQL query <b>%1\$s</b>."] = "Íå óäàëîñü âûïîëíèòü SQL çàïðîñ <b>%1\$s</b>.";
$net2ftp_messages["No data"] = "Íåò äàííûõ";

} // end admin_viewlogs


// -------------------------------------------------------------------------
// Admin_emptylogs module
if ($net2ftp_globals["state"] == "admin_emptylogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_emptylogs.inc.php
$net2ftp_messages["Admin functions"] = "Ôóíêöèè àäìèíèñòðàòîðà";
$net2ftp_messages["The table <b>%1\$s</b> was emptied successfully."] = "Òàáëèöà <b>%1\$s</b> óñïåøíî î÷èùåíà.";
$net2ftp_messages["The table <b>%1\$s</b> could not be emptied."] = "Òàáëèöà <b>%1\$s</b> íå ìîæåò áûòü î÷èùåíà.";
$net2ftp_messages["The table <b>%1\$s</b> was optimized successfully."] = "Òàáëèöà <b>%1\$s</b> óñïåøíî îïòè.";
$net2ftp_messages["The table <b>%1\$s</b> could not be optimized."] = "Òàáëèöà <b>%1\$s</b> íå ìîæåò áûòü îïòèìèçèðîâàíà.";

} // end admin_emptylogs


// -------------------------------------------------------------------------
// Advanced module
if ($net2ftp_globals["state"] == "advanced") {
// -------------------------------------------------------------------------

// /modules/advanced/advanced.inc.php
$net2ftp_messages["Advanced functions"] = "Ðàñøèðåííûå ôóíêöèè";

// /skins/[skin]/advanced1.template.php
$net2ftp_messages["Go"] = "Âïåðåä";
$net2ftp_messages["Disabled"] = "Îòêëþ÷åíî";
$net2ftp_messages["Advanced FTP functions"] = "Äîïîëíèòåëüíûå FTP ôóíêöèè";
$net2ftp_messages["Send arbitrary FTP commands to the FTP server"] = "Send arbitrary FTP commands to the FTP server";
$net2ftp_messages["This function is available on PHP 5 only"] = "Ýòà ôóíêöèÿ äîñòóïíà òîëüêî ñ PHP 5";
$net2ftp_messages["Troubleshooting functions"] = "Ôóíêöèè äëÿ óñòðàíåíèÿ ïðîáëåì";
$net2ftp_messages["Troubleshoot net2ftp on this webserver"] = "Ðåøåíèå ïðîáëåì net2ftp íà ýòîì âåá-ñåðâåðå";
$net2ftp_messages["Troubleshoot an FTP server"] = "Ðåøåíèå ïðîáëåì FTP-ñåðâåðà";
$net2ftp_messages["Test the net2ftp list parsing rules"] = "Ïðîâåðèòü ïðàâèëà ðàçáîðà ñïèñêà net2ftp";
$net2ftp_messages["Translation functions"] = "Ôóíêöèè ïåðåâîäà";
$net2ftp_messages["Introduction to the translation functions"] = "Íà÷àëüíàÿ èíôîðìàöèÿ î ôóíêöèÿõ ïåðåâîäà";
$net2ftp_messages["Extract messages to translate from code files"] = "Extract messages to translate from code files";
$net2ftp_messages["Check if there are new or obsolete messages"] = "Ïðîâåðèòü íàëè÷èå íîâûõ èëè óñòàðåâøèõ ñîîáùåíèé";

$net2ftp_messages["Beta functions"] = "Áåòà-ôóíêöèè";
$net2ftp_messages["Send a site command to the FTP server"] = "Send a site command to the FTP server";
$net2ftp_messages["Apache: password-protect a directory, create custom error pages"] = "Apache: çàùèòèòü ïàïêó ïàðîëåì, ñîçäàòü ïåðñîíàëüíûå ñòðàíèöû îøèáîê";
$net2ftp_messages["MySQL: execute an SQL query"] = "MySQL: âûïîëíèòü SQL-çàïðîñ";


// advanced()
$net2ftp_messages["The site command functions are not available on this webserver."] = "Êîìàíäíûå ôóíêöèè ýòîã ñàéòà íåäîñòóïíû íà âåá-ñåðâåðå.";
$net2ftp_messages["The Apache functions are not available on this webserver."] = "Ôóíêöèè Apache íåäîñòóïíû íà ýòîì âåá-ñåðâåðå.";
$net2ftp_messages["The MySQL functions are not available on this webserver."] = "Ôóíêöèè MySQL íåäîñòóïíû íà ýòîì âåá-ñåðâåðå.";
$net2ftp_messages["Unexpected state2 string. Exiting."] = "Íåîæèäàííîå ñîäåðæàíèå ñòðîêè 2. Çàâåðøåíèå.";

} // end advanced


// -------------------------------------------------------------------------
// Advanced_ftpserver module
if ($net2ftp_globals["state"] == "advanced_ftpserver") {
// -------------------------------------------------------------------------

// /modules/advanced_ftpserver/advanced_ftpserver.inc.php
$net2ftp_messages["Troubleshoot an FTP server"] = "Ðåøåíèå ïðîáëåì FTP-ñåðâåðà";

// /skins/[skin]/advanced_ftpserver1.template.php
$net2ftp_messages["Connection settings:"] = "Ïàðàìåòðû ñîåäèíåíèÿ:";
$net2ftp_messages["FTP server"] = "FTP-ñåðâåð";
$net2ftp_messages["FTP server port"] = "Ïîðò FTP-ñåðâåðà";
$net2ftp_messages["Username"] = "Ëîãèí";
$net2ftp_messages["Password"] = "Ïàðîëü";
$net2ftp_messages["Password length"] = "Äëèíà ïàðîëÿ";
$net2ftp_messages["Passive mode"] = "Ïàññèâíûé ðåæèì";
$net2ftp_messages["Directory"] = "Ïàïêà";
$net2ftp_messages["Printing the result"] = "Printing the result";

// /skins/[skin]/advanced_ftpserver2.template.php
$net2ftp_messages["Connecting to the FTP server: "] = "Ñîåäèíåíèå ñ FTP-ñåðâåðîì: ";
$net2ftp_messages["Logging into the FTP server: "] = "Âõîä íà FTP-ñåðâåð: ";
$net2ftp_messages["Setting the passive mode: "] = "Ïåðåõîä íà ïàññèâíûé ðåæèì: ";
$net2ftp_messages["Getting the FTP server system type: "] = "Îïðåäåëÿåòñÿ òèï ñèñòåìû FTP-ñåðâåðà: ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "Ïåðåõîä â ïàïêó %1\$s: ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "Ïàïêà FTP-ñåðâåðà: %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "Ïîëó÷åíèå ñïèñêà ïàïîê è ôàéëîâ: ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "Ïîâòîðíàÿ ïîïûêà ïîëó÷åíèÿ ñïèñêà: ";
$net2ftp_messages["Closing the connection: "] = "Çàêðûòèå ñîåäèíåíèÿ: ";
$net2ftp_messages["Raw list of directories and files:"] = "Ñïèñîê ïàïîê è ôàéëîâ:";
$net2ftp_messages["Parsed list of directories and files:"] = "Îáðàáîòàííûé ñïèñîê ïàïîê è ôàéëîâ:";

$net2ftp_messages["OK"] = "OK";
$net2ftp_messages["not OK"] = "not OK";

} // end advanced_ftpserver


// -------------------------------------------------------------------------
// Advanced_parsing module
if ($net2ftp_globals["state"] == "advanced_parsing") {
// -------------------------------------------------------------------------

$net2ftp_messages["Test the net2ftp list parsing rules"] = "Ïðîâåðèòü ïðàâèëà ðàçáîðà ñïèñêà net2ftp";
$net2ftp_messages["Sample input"] = "Ïðèìåð âõîäíûõ äàííûõ";
$net2ftp_messages["Parsed output"] = "Îáðàáîòàííûå âûõîäíûå äàííûå";

} // end advanced_parsing


// -------------------------------------------------------------------------
// Advanced_webserver module
if ($net2ftp_globals["state"] == "advanced_webserver") {
// -------------------------------------------------------------------------

$net2ftp_messages["Troubleshoot your net2ftp installation"] = "Ðåøåíèå ïðîáëåì óñòàíîâêè net2ftp";
$net2ftp_messages["Printing the result"] = "Printing the result";

$net2ftp_messages["Checking if the FTP module of PHP is installed: "] = "Ïðîâåðêà óñòàíîâêè ìîäóëÿ FTP îò PHP: ";
$net2ftp_messages["yes"] = "äà";
$net2ftp_messages["no - please install it!"] = "íåò - ïîæàëóéñòà, óñòàíîâèòå åãî!";

$net2ftp_messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "Ïðîâåðêà ðàçðåøåíèé ïàïêè íà âåá-ñåðâåðå: íåáîëüøîé ôàéë ìîæåò áûòü çàïèñàí â ïàïêó /temp è ïîòîì óäàëåí.";
$net2ftp_messages["Creating filename: "] = "Èìÿ ôàéëà äëÿ ñîçäàíèÿ: ";
$net2ftp_messages["OK. Filename: %1\$s"] = "OK. Èìÿ ôàéëà: %1\$s";
$net2ftp_messages["not OK"] = "not OK";
$net2ftp_messages["OK"] = "OK";
$net2ftp_messages["not OK. Check the permissions of the %1\$s directory"] = "íå OK. Ïðîâåðüòå ðàçðåøåíèÿ ïàïêè %1\$s";
$net2ftp_messages["Opening the file in write mode: "] = "Îòêðûòèå ôàéëà â ðåæèìå äëÿ çàïèñè: ";
$net2ftp_messages["Writing some text to the file: "] = "Çàïèñü òåêñòà â ôàéë: ";
$net2ftp_messages["Closing the file: "] = "Çàêðûòèå ôàéëà: ";
$net2ftp_messages["Deleting the file: "] = "Óäàëåíèå ôàéëà: ";

$net2ftp_messages["Testing the FTP functions"] = "Òåñòèðîâàíèå ôóíêöèé FTP";
$net2ftp_messages["Connecting to a test FTP server: "] = "Ïîäêëþ÷åíèå ê òåñòîâîìó FTP ñåðâåðó: ";
$net2ftp_messages["Connecting to the FTP server: "] = "Ñîåäèíåíèå ñ FTP-ñåðâåðîì: ";
$net2ftp_messages["Logging into the FTP server: "] = "Âõîä íà FTP-ñåðâåð: ";
$net2ftp_messages["Setting the passive mode: "] = "Ïåðåõîä íà ïàññèâíûé ðåæèì: ";
$net2ftp_messages["Getting the FTP server system type: "] = "Îïðåäåëÿåòñÿ òèï ñèñòåìû FTP-ñåðâåðà: ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "Ïåðåõîä â ïàïêó %1\$s: ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "Ïàïêà FTP-ñåðâåðà: %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "Ïîëó÷åíèå ñïèñêà ïàïîê è ôàéëîâ: ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "Ïîâòîðíàÿ ïîïûêà ïîëó÷åíèÿ ñïèñêà: ";
$net2ftp_messages["Closing the connection: "] = "Çàêðûòèå ñîåäèíåíèÿ: ";
$net2ftp_messages["Raw list of directories and files:"] = "Ñïèñîê ïàïîê è ôàéëîâ:";
$net2ftp_messages["Parsed list of directories and files:"] = "Îáðàáîòàííûé ñïèñîê ïàïîê è ôàéëîâ:";
$net2ftp_messages["OK"] = "OK";
$net2ftp_messages["not OK"] = "not OK";

} // end advanced_webserver


// -------------------------------------------------------------------------
// Bookmark module
if ($net2ftp_globals["state"] == "bookmark") {
// -------------------------------------------------------------------------

$net2ftp_messages["Drag and drop one of the links below to the bookmarks bar"] = "Drag and drop one of the links below to the bookmarks bar";
$net2ftp_messages["Right-click on one of the links below and choose \"Add to Favorites...\""] = "Right-click on one of the links below and choose \"Add to Favorites...\"";
$net2ftp_messages["Right-click on one the links below and choose \"Add Link to Bookmarks...\""] = "Right-click on one the links below and choose \"Add Link to Bookmarks...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark link...\""] = "Right-click on one of the links below and choose \"Bookmark link...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark This Link...\""] = "Right-click on one of the links below and choose \"Bookmark This Link...\"";
$net2ftp_messages["One click access (net2ftp won't ask for a password - less safe)"] = "One click access (net2ftp won't ask for a password - less safe)";
$net2ftp_messages["Two click access (net2ftp will ask for a password - safer)"] = "Two click access (net2ftp will ask for a password - safer)";
$net2ftp_messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Ïðèìå÷àíèå: êîãäà Âû áóäåòå èñïîëüçîâàòü çàêëàäêó, âñïëûâàþùåå îêíî ñïðîñèò ó Âàñ èìÿ è ïàðîëü.";

} // end bookmark


// -------------------------------------------------------------------------
// Browse module
if ($net2ftp_globals["state"] == "browse") {
// -------------------------------------------------------------------------

// /modules/browse/browse.inc.php
$net2ftp_messages["Choose a directory"] = "Âûáåðèòå ïàïêó";
$net2ftp_messages["Please wait..."] = "Ïîæàëóéñòà, ïîäîæäèòå...";

// browse()
$net2ftp_messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Ïàïêè ñ èìåíàìè, ñîäåðæàùèìè \' íå ìîãóò êîððåêòíî îòîáðàæàòüñÿ. Èõ ìîæíî òîëüêî óäàëèòü. Ïîæàëóéñòà, âåðíèòåñü è âûáåðèòå äðóãóþ ïàïêó.";

$net2ftp_messages["Daily limit reached: you will not be able to transfer data"] = "Äîñòèãíóò ñóòî÷íûé ëèìèò: Âû íå ìîæåòå áîëüøå ïåðåäàâàòü äàííûå";
$net2ftp_messages["In order to guarantee the fair use of the web server for everyone, the data transfer volume and script execution time are limited per user, and per day. Once this limit is reached, you can still browse the FTP server but not transfer data to/from it."] = "×òîáû ãàðàíòèðîâàòü ðàâíóþ äîñòóïíîñòü ýòîãî ñåðâåðà äëÿ êàæäîãî ïîëüçîâàòåëÿ, íàêëàäûâàåòñÿ îãðàíè÷åíèå íà îáú¸ì ïåðåäàâàåìûõ äàííûõ è âðåìÿ âûïîëíåíèÿ ñêðèïòîâ äëÿ ïîëüçîâàòåëÿ â äåíü. Êàê òîëüêî ýòîò ëèìèò ïðåâûøåí, Âû ìîæåòå ïðîñìàòðèâàòü ïàïêè, íî íå ìîæåòå çàêà÷èâàòü èëè ñêà÷èâàòü ôàéëû.";
$net2ftp_messages["If you need unlimited usage, please install net2ftp on your own web server."] = "Åñëè Âàì íåîáõîäèìû íåîãðàíè÷åííûå ðåñóðñû, ïîæàëóéñòà óñòàíîâèòå net2ftp íà Âàø ñîáñòâåííûé ftp ñåðâåð.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$net2ftp_messages["New dir"] = "Íîâàÿ ïàïêà";
$net2ftp_messages["New file"] = "Íîâûé ôàéë";
$net2ftp_messages["HTML templates"] = "HTML templates";
$net2ftp_messages["Upload"] = "Çàêà÷àòü";
$net2ftp_messages["Java Upload"] = "Çàêà÷àòü Java";
$net2ftp_messages["Flash Upload"] = "Çàêà÷àòü Flash";
$net2ftp_messages["Install"] = "Óñòàíîâèòü";
$net2ftp_messages["Advanced"] = "Îïöèè";
$net2ftp_messages["Copy"] = "Êîïèð.";
$net2ftp_messages["Move"] = "Ïåðåìåñò.";
$net2ftp_messages["Delete"] = "Óäàëèòü";
$net2ftp_messages["Rename"] = "Ïåðåèì.";
$net2ftp_messages["Chmod"] = "Chmod";
$net2ftp_messages["Download"] = "Ñêà÷àòü";
$net2ftp_messages["Unzip"] = "Ðàñïàêîâàòü";
$net2ftp_messages["Zip"] = "Àðõèâèðîâàòü";
$net2ftp_messages["Size"] = "Ðàçìåð";
$net2ftp_messages["Search"] = "Ïîèñê";
$net2ftp_messages["Go to the parent directory"] = "Ïåðåéòè íà óðîâåíü âûøå";
$net2ftp_messages["Go"] = "Âïåðåä";
$net2ftp_messages["Transform selected entries: "] = "Ïðåîáðàçîâàòü âûáðàííîå: ";
$net2ftp_messages["Transform selected entry: "] = "Ïðåîáðàçîâàòü âûáðàííîå: ";
$net2ftp_messages["Make a new subdirectory in directory %1\$s"] = "Ñîçäàòü ïîäïàïêó â ïàïêå %1\$s";
$net2ftp_messages["Create a new file in directory %1\$s"] = "Ñîçäàòü ôàéë â ïàïêå %1\$s";
$net2ftp_messages["Create a website easily using ready-made templates"] = "Create a website easily using ready-made templates";
$net2ftp_messages["Upload new files in directory %1\$s"] = "Çàêà÷àòü íîâûå ôàéëû â ïàïêó %1\$s";
$net2ftp_messages["Upload directories and files using a Java applet"] = "Çàãðóçèòü ôàéëû è äèðåêòîðèè èñïîëüçóÿ Java àïïëåò";
$net2ftp_messages["Upload files using a Flash applet"] = "Çàãðóçèòü ôàéëû íà ñåðâåð, èñïîëüçóÿ Flash àïïëåò";
$net2ftp_messages["Install software packages (requires PHP on web server)"] = "Óñòàíîâèòü ïàêåòû (òðåáóåò íàëè÷èÿ PHP íà âåá-ñåðâåðå)";
$net2ftp_messages["Go to the advanced functions"] = "Ïåðåéòè â äîï. ôóíêöèè";
$net2ftp_messages["Copy the selected entries"] = "Êîïèðîâàòü âûáðàííûå ïàïêè";
$net2ftp_messages["Move the selected entries"] = "Ïåðåìåñòèòü âûáðàííûå ïàïêè";
$net2ftp_messages["Delete the selected entries"] = "Óäàëèòü âûáðàííûå ïàïêè";
$net2ftp_messages["Rename the selected entries"] = "Ïåðåèìåíîâàòü âûáðàííîå";
$net2ftp_messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "Chmod âûáðàííîãî (ðàáîòàåò íà Unix/Linux/BSD ñåðâåðàõ)";
$net2ftp_messages["Download a zip file containing all selected entries"] = "Ñêà÷àòü zip-ôàéë, ñîäåðæàùèé âûáðàííûå ôàéëû";
$net2ftp_messages["Unzip the selected archives on the FTP server"] = "Ðàñïàêîâàòü âûáðàííûå àðõèâû íà FTP ñåðâåð";
$net2ftp_messages["Zip the selected entries to save or email them"] = "Ñæàòü âûáðàííîå è îòïðàâèòü ïî email";
$net2ftp_messages["Calculate the size of the selected entries"] = "Âû÷èñëèòü ðàçìåð âûáðàííîãî";
$net2ftp_messages["Find files which contain a particular word"] = "Íàéòè ôàéëû, ñîäåðæàùèå ÷àñòü ñëîâà";
$net2ftp_messages["Click to sort by %1\$s in descending order"] = "Íàæìèòå äëÿ ñîðòèðîâêè %1\$s â ïîðÿäêå âîçðàñòàíèÿ";
$net2ftp_messages["Click to sort by %1\$s in ascending order"] = "Íàæìèòå äëÿ ñîðòèðîâêè %1\$s â ïîðÿäêå óáûâàíèÿ";
$net2ftp_messages["Ascending order"] = "Óáûâàíèå";
$net2ftp_messages["Descending order"] = "Âîçðàñòàíèå";
$net2ftp_messages["Upload files"] = "Çàãðóçèòü ôàéëû íà ñåðâåð";
$net2ftp_messages["Up"] = "Ââåðõ";
$net2ftp_messages["Click to check or uncheck all rows"] = "Íàæìèòå äëÿ âûáîðà èëè îòìåíû âûáîðà âñåõ";
$net2ftp_messages["All"] = "Âñå";
$net2ftp_messages["Name"] = "Èìÿ";
$net2ftp_messages["Type"] = "Òèï";
//$net2ftp_messages["Size"] = "Size";
$net2ftp_messages["Owner"] = "Ïîëüçîâàòåëü";
$net2ftp_messages["Group"] = "Ãðóïïà";
$net2ftp_messages["Perms"] = "Ðàçðåøåíèÿ";
$net2ftp_messages["Mod Time"] = "Âðåìÿ";
$net2ftp_messages["Actions"] = "Äåéñòâèÿ";
$net2ftp_messages["Select the directory %1\$s"] = "Âûáðàòü äèðåêòîðèþ %1\$s";
$net2ftp_messages["Select the file %1\$s"] = "Âûáðàòü ôàéë %1\$s";
$net2ftp_messages["Select the symlink %1\$s"] = "Âûáðàòü symlink %1\$s";
$net2ftp_messages["Go to the subdirectory %1\$s"] = "Ïåðåéòè â ïîääèðåêòîðèþ %1\$s";
$net2ftp_messages["Download the file %1\$s"] = "Ñêà÷àòü ôàéë%1\$s";
$net2ftp_messages["Follow symlink %1\$s"] = "Ñëåäîâàòü symlink'ó %1\$s";
$net2ftp_messages["View"] = "Ïîêàç.";
$net2ftp_messages["Edit"] = "Ðåäàêò.";
$net2ftp_messages["Update"] = "Îáíîâèòü";
$net2ftp_messages["Open"] = "Îòêðûòü";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "Ïîêàçàòü èñõîäíûé êîä %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "Ðåäàêòèðîâàòü èñõîäíûé êîä ôàéëà %1\$s";
$net2ftp_messages["Upload a new version of the file %1\$s and merge the changes"] = "Çàêà÷àòü íîâóþ âåðñèþ ôàéëà 1\$s è ïðèìåíèòü èçìåíåíèÿ";
$net2ftp_messages["View image %1\$s"] = "Ïîêàçàòü ðèñóíîê %1\$s";
$net2ftp_messages["View the file %1\$s from your HTTP web server"] = "Ïîêàçàòü ôàéë %1\$s ñ âàøåãî HTTP-ñåðâåðà";
$net2ftp_messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Ïðèìå÷àíèå: Ññûëêà ìîæåò íå ðàáîòàòü, åñëè ó âàñ íåò äîìåííîãî èìåíè.)";
$net2ftp_messages["This folder is empty"] = "Ïàïêà ïóñòà";

// printSeparatorRow()
$net2ftp_messages["Directories"] = "Ïàïêè";
$net2ftp_messages["Files"] = "Ôàéëû";
$net2ftp_messages["Symlinks"] = "Ññûëêè";
$net2ftp_messages["Unrecognized FTP output"] = "Íåèçâåñòíûé âûõîä FTP";
$net2ftp_messages["Number"] = "Íîìåð";
$net2ftp_messages["Size"] = "Ðàçìåð";
$net2ftp_messages["Skipped"] = "Ïðîïóùåíî";
$net2ftp_messages["Data transferred from this IP address today"] = "Îáüåì äàííûõ, ïåðåäàííûé ñ ýòîãî IP àäðåñà çà ñåãîäíÿ";
$net2ftp_messages["Data transferred to this FTP server today"] = "Îáüåì äàííûõ ïåðåäàííûõ ýòîìó FTP ñåðâåðó ñåãîäíÿ";

// printLocationActions()
$net2ftp_messages["Language:"] = "ßçûê:";
$net2ftp_messages["Skin:"] = "Ñêèí:";
$net2ftp_messages["View mode:"] = "Ðåæèì ïðîñìîòðà:";
$net2ftp_messages["Directory Tree"] = "Äåðåâî ïàïîê";

// ftp2http()
$net2ftp_messages["Execute %1\$s in a new window"] = "Âûïîëíèòü %1\$s â íîâîì îêíå";
$net2ftp_messages["This file is not accessible from the web"] = "Ýòîò ôàéë íå äîñòóïåí èç web-èíòåðôåéñà";

// printDirectorySelect()
$net2ftp_messages["Double-click to go to a subdirectory:"] = "Íàæìèòå äâàæäû äëÿ ïåðåõîäà â ïîäïàïêó:";
$net2ftp_messages["Choose"] = "Âûáîð";
$net2ftp_messages["Up"] = "Ââåðõ";

} // end browse


// -------------------------------------------------------------------------
// Calculate size module
if ($net2ftp_globals["state"] == "calculatesize") {
// -------------------------------------------------------------------------
$net2ftp_messages["Size of selected directories and files"] = "Ðàçìåð âûáðàííûõ ïàïîê è ôàéëîâ";
$net2ftp_messages["The total size taken by the selected directories and files is:"] = "Îáùèé ðàçìåð ôàéëîâ è ïàïîê:";
$net2ftp_messages["The number of files which were skipped is:"] = "Êîëè÷åñòâî ôàéëîâ, êîòîðûå áûëè ïðîïóùåíû:";

} // end calculatesize


// -------------------------------------------------------------------------
// Chmod module
if ($net2ftp_globals["state"] == "chmod") {
// -------------------------------------------------------------------------
$net2ftp_messages["Chmod directories and files"] = "Chmod íà ïàïêè è ôàéëû";
$net2ftp_messages["Set all permissions"] = "Ñìåíèòü âñå ïðàâà";
$net2ftp_messages["Read"] = "×òåíèå";
$net2ftp_messages["Write"] = "Çàïèñü";
$net2ftp_messages["Execute"] = "Âûïîëíèòü";
$net2ftp_messages["Owner"] = "Ïîëüçîâàòåëü";
$net2ftp_messages["Group"] = "Ãðóïïà";
$net2ftp_messages["Everyone"] = "Âñå";
$net2ftp_messages["To set all permissions to the same values, enter those permissions and click on the button \"Set all permissions\""] = "Äëÿ âûáîðà îäèíàêîâûõ ðàçðåøåíèé, ââåäèòå èõ çíà÷åíèÿ íèæå è íàæìèòå íà êíîïêó \"Âûáðàòü ðàçðåøåíèÿ\"";
$net2ftp_messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Âûáðàòü ðàçðåøåíèÿ äëÿ ïàïêè <b>%1\$s</b>: ";
$net2ftp_messages["Set the permissions of file <b>%1\$s</b> to: "] = "Âûáðàòü ðàçðåøåíèÿ äëÿ ôàéëà <b>%1\$s</b>: ";
$net2ftp_messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Âûáðàòü ðàçðåøåíèÿ äëÿ ñèìëèíêà <b>%1\$s</b>: ";
$net2ftp_messages["Chmod value"] = "Chmod value";
$net2ftp_messages["Chmod also the subdirectories within this directory"] = "Chmod òàêæå íà ïîäïàïêè âíóòðè ýòîé ïàïêè";
$net2ftp_messages["Chmod also the files within this directory"] = "Chmod òàêæå íà ôàéëû âíóòðè ýòîé ïàïêè";
$net2ftp_messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "Chmod <b>%1\$s</b> âûõîäèò èç äèàïàçîíà 000-777. Ïîïðîáóéòå åù¸ ðàç.";

} // end chmod


// -------------------------------------------------------------------------
// Clear cookies module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// Copy/Move/Delete module
if ($net2ftp_globals["state"] == "copymovedelete") {
// -------------------------------------------------------------------------
$net2ftp_messages["Choose a directory"] = "Âûáåðèòå ïàïêó";
$net2ftp_messages["Copy directories and files"] = "Êîïèðîâàòü ïàïêè è ôàéëû";
$net2ftp_messages["Move directories and files"] = "Ïåðåìåñòèòü ïàïêè è ôàéëû";
$net2ftp_messages["Delete directories and files"] = "Óäàëèòü ïàïêè è ôàéëû";
$net2ftp_messages["Are you sure you want to delete these directories and files?"] = "Âû äåéñòâèòåëüíî õîòèòå óäàëèòü ýòè ôàéëû è ïàïêè?";
$net2ftp_messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Âñå ïîäïàïêè è ôàéëû â óêàçàííûõ ïàïêàõ áóäóò óäàëåíû!";
$net2ftp_messages["Set all targetdirectories"] = "Âûáðàòü âñå ïàïêè";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "×òîáû çàäàòü ãëàâíóþ ïàïêó, ââåäèòå å¸ íàçâàíèå â ïîëå âûøå è âûáåðèòå ïóíêò \"Âûáðàòü âñå ïàïêè\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "Ïðèìå÷àíèå: ïàïêà äîëæíà óæå ñóùåñòâîâàòü.";
$net2ftp_messages["Different target FTP server:"] = "Äðóãîé FTP-ñåðâåð:";
$net2ftp_messages["Username"] = "Ëîãèí";
$net2ftp_messages["Password"] = "Ïàðîëü";
$net2ftp_messages["Leave empty if you want to copy the files to the same FTP server."] = "Îñòàâüòå ïóñòûì, åñëè âû õîòèòå ñêîïèðîâàòü ôàéëû â òó æå ïàïêó FTP-ñåðâåðà.";
$net2ftp_messages["If you want to copy the files to another FTP server, enter your login data."] = "Åñëè âû õîòèòå îòêðûòü ôàéëû íà äðóãîì FTP-ñåðâåðå, òî ââåäèòå äàííûå äëÿ âõîäà.";
$net2ftp_messages["Leave empty if you want to move the files to the same FTP server."] = "Îñòàâüòå ïóñòûì, åñëè âû õîòèòå ïåðåìåñòèòü ôàéëû â òó æå ïàïêó FTP-ñåðâåðà.";
$net2ftp_messages["If you want to move the files to another FTP server, enter your login data."] = "Åñëè âû õîòèòå ïåðåìåñòèòü ôàéëû íà äðóãîé FTP-ñåðâåð, ââåäèòå äàííûå äëÿ âõîäà.";
$net2ftp_messages["Copy directory <b>%1\$s</b> to:"] = "Êîïèðîâàòü ïàïêó <b>%1\$s</b> â:";
$net2ftp_messages["Move directory <b>%1\$s</b> to:"] = "Ïåðåìåñòèòü ïàïêó <b>%1\$s</b> â:";
$net2ftp_messages["Directory <b>%1\$s</b>"] = "Ïàïêà <b>%1\$s</b>";
$net2ftp_messages["Copy file <b>%1\$s</b> to:"] = "Êîïèðîâàòü ôàéë <b>%1\$s</b> â:";
$net2ftp_messages["Move file <b>%1\$s</b> to:"] = "Ïåðåìåñòèòü ôàéë <b>%1\$s</b> â:";
$net2ftp_messages["File <b>%1\$s</b>"] = "Ôàéë <b>%1\$s</b>";
$net2ftp_messages["Copy symlink <b>%1\$s</b> to:"] = "Êîïèðîâàòü ñèìëèíê <b>%1\$s</b> â:";
$net2ftp_messages["Move symlink <b>%1\$s</b> to:"] = "Ïåðåìåñòèòü ñèìëèíê <b>%1\$s</b> â:";
$net2ftp_messages["Symlink <b>%1\$s</b>"] = "Ñèìëèíê <b>%1\$s</b>";
$net2ftp_messages["Target directory:"] = "Ïàïêà íàçíà÷åíèÿ:";
$net2ftp_messages["Target name:"] = "Èìÿ íàçíà÷åíèÿ:";
$net2ftp_messages["Processing the entries:"] = "Ïðîñìîòð ñîäåðæèìîãî:";

} // end copymovedelete


// -------------------------------------------------------------------------
// Download file module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// EasyWebsite module
if ($net2ftp_globals["state"] == "easyWebsite") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create a website in 4 easy steps"] = "Cîçäàéòå ñàéò çà 4 øàãà";
$net2ftp_messages["Template overview"] = "Ïðîñìîòð ùàáëîíà";
$net2ftp_messages["Template details"] = "Äåòàëè øàáëîíà";
$net2ftp_messages["Files are copied"] = "Ñêîïèðîâàííûå ôàéëû";
$net2ftp_messages["Edit your pages"] = "Ðåäàêòèðîâàòü ñòðàíèöû";

// Screen 1 - printTemplateOverview
$net2ftp_messages["Click on the image to view the details of a template."] = "Íàæìèòå íà èçîáðàæåíèå ÷òîáû ïîñìîòðåòü ïîäðîáíîñòè î øàáëîíå.";
$net2ftp_messages["Back to the Browse screen"] = "Íàçàä, ê ñòðàíèöå ïðîñìîòðà";
$net2ftp_messages["Template"] = "Øàáëîí";
$net2ftp_messages["Copyright"] = "Copyright";
$net2ftp_messages["Click on the image to view the details of this template"] = "Íàæìèòå íà èçîáðàæåíèå ÷òîáû ïîñìîòðåòü ïîäðîáíîñòè î øàáëîíå";

// Screen 2 - printTemplateDetails
$net2ftp_messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "Ôàéëû øàáëîíà áóäóò ñêîïèðîâàíû íà Âàø FTP-ñåðâåð. Ñóùåñòâóþùèå ôàéëû ñ òàêèìè æå èìåíàìè áóäóò çàìåíåíû íîâûìè. Õîòèòå ëè Âû ïðîäîëæèòü?";
$net2ftp_messages["Install template to directory: "] = "Óñòàíîâèòü øàáëîí â äèðåêòîðèþ: ";
$net2ftp_messages["Install"] = "Óñòàíîâèòü";
$net2ftp_messages["Size"] = "Ðàçìåð";
$net2ftp_messages["Preview page"] = "Ïðåäïðîñìîòð ñòðàíèöû";
$net2ftp_messages["opens in a new window"] = "îòêðîåòñÿ â íîâîì îêíå";

// Screen 3
$net2ftp_messages["Please wait while the template files are being transferred to your server: "] = "Ïîæàëóéñòà, äîæäèòåñü îêîí÷àíèÿ ïåðåíîñà ôàéëîâ íà ñåðâåð: ";
$net2ftp_messages["Done."] = "Çàâåðøåíî.";
$net2ftp_messages["Continue"] = "Ïðîäîëæèòü";

// Screen 4 - printEasyAdminPanel
$net2ftp_messages["Edit page"] = "Ðåäàêòèðîâàíèå";
$net2ftp_messages["Browse the FTP server"] = "Ïðîñìîòð  FTP ñåðâåðà";
$net2ftp_messages["Add this link to your favorites to return to this page later on!"] = "Äîáàâüòå ýòó ññûëêó â çàêëàäêè ÷òîáû âåðíóòüñÿ ñþäà ïîçæå!";
$net2ftp_messages["Edit website at %1\$s"] = "Ðåäàêòèðîâàòü ñàéò %1\$s";
$net2ftp_messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: êëèêíèòå ïðàâîé êíîïêîé íà ññûëêå è âûáåðèòå \"Äîáàâèòü â Èçáðàííîå...\"";
$net2ftp_messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: êëèêíèòå ïðàâîé êíîïêîé íà ññûëêó è âûáåðèòå \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$net2ftp_messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "ÂÍÈÌÀÍÈÅ: íåâîçìîæíî ñîçäàòü ïîäïàïêó <b>%1\$s</b>. Âîçìîæíî, îíà óæå ñóùåñòâóåò. Ïðîäîëæåíèå...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "Created target subdirectory <b>%1\$s</b>";
$net2ftp_messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "ÂÍÈÌÀÍÈÅ: íå óäàëîñü ñêîïèðîâàòü ôàéë <b>%1\$s</b>. Ïðîäîëæåíèå...";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// Edit module
if ($net2ftp_globals["state"] == "edit") {
// -------------------------------------------------------------------------

// /modules/edit/edit.inc.php
$net2ftp_messages["Unable to open the template file"] = "Íå óäàëîñü îòêðûòü âðåìåííûé ôàéë";
$net2ftp_messages["Unable to read the template file"] = "Íå óäàëîñü ïðî÷èòàòü âðåìåííûé ôàéë";
$net2ftp_messages["Please specify a filename"] = "Óêàæèòå èìÿ ôàéëà";
$net2ftp_messages["Status: This file has not yet been saved"] = "Ñîñòîÿíèå: ôàéë íå ñîõðàíåí";
$net2ftp_messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Ñîñòîÿíèå: ñîõðàíåíî â <b>%1\$s</b> â ðåæèìå %2\$s";
$net2ftp_messages["Status: <b>This file could not be saved</b>"] = "Ñîñòîÿíèå: <b>ýòîò ôàéë íå ìîæåò áûòü ñîõðàíåí</b>";
$net2ftp_messages["Not yet saved"] = "Not yet saved";
$net2ftp_messages["Could not be saved"] = "Could not be saved";
$net2ftp_messages["Saved at %1\$s"] = "Saved at %1\$s";

// /skins/[skin]/edit.template.php
$net2ftp_messages["Directory: "] = "Ïàïêà: ";
$net2ftp_messages["File: "] = "Ôàéë: ";
$net2ftp_messages["New file name: "] = "Íîâîå èìÿ ôàéëà: ";
$net2ftp_messages["Character encoding: "] = "Character encoding: ";
$net2ftp_messages["Note: changing the textarea type will save the changes"] = "Ïðèìå÷àíèå: èçìåíåíèå òåêñòà ñîõðàíèò èçìåíåíèÿ";
$net2ftp_messages["Copy up"] = "Ñêîïèðîâàòü íàâåðõ";
$net2ftp_messages["Copy down"] = "Ñêîïèðîâàòü âíèç";

} // end if edit


// -------------------------------------------------------------------------
// Find string module
if ($net2ftp_globals["state"] == "findstring") {
// -------------------------------------------------------------------------

// /modules/findstring/findstring.inc.php 
$net2ftp_messages["Search directories and files"] = "Ïîèñê ïàïîê è ôàéëîâ";
$net2ftp_messages["Search again"] = "Èñêàòü ñíîâà";
$net2ftp_messages["Search results"] = "Ðåçóëüòàòû ïîèñêà";
$net2ftp_messages["Please enter a valid search word or phrase."] = "Ââåäèòå ïðàâèëüíîå ñëîâî èëè ôðàçó.";
$net2ftp_messages["Please enter a valid filename."] = "Ââåäèòå ïðàâèëüíîå èìÿ ôàéëà.";
$net2ftp_messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Ïîæàëóéñòà, ââåäèòå ïðàâèëüíîå íàçâàíèå â ïîëå \"èç\", íàïðèìåð, 0.";
$net2ftp_messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Ïîæàëóéñòà, ââåäèòå ïðàâèëüíûé ðàçìåð â ïîëå \"â\", íàïðèìåð, 500000.";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Ïîæàëóéñòà, ââåäèòå ïðàâèëüíóþ äàòó â ôîðìàòå ã-ì-ä â ïîëå \"èç\".";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Ïîæàëóéñòà, ââåäèòå ïðàâèëüíóþ äàòó â ôîðìàòå ã-ì-ä â ïîëå \"â\".";
$net2ftp_messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "Ñëîâî <b>%1\$s</b> íå áûëî íàéäåíî.";
$net2ftp_messages["The word <b>%1\$s</b> was found in the following files:"] = "Ñëîâî <b>%1\$s</b> áûëî íàéäåíî â ñëåäóþùèõ ôðàçàõ:";

// /skins/[skin]/findstring1.template.php
$net2ftp_messages["Search for a word or phrase"] = "Ïîèñê ñëîâà èëè ôðàçû";
$net2ftp_messages["Case sensitive search"] = "×óâñòâèòåëüíî ê ðåãèñòðó";
$net2ftp_messages["Restrict the search to:"] = "Çàïðåòèòü èñêàòü:";
$net2ftp_messages["files with a filename like"] = "èìÿ ôàéëà êàê";
$net2ftp_messages["(wildcard character is *)"] = "(ñèìâîë *)";
$net2ftp_messages["files with a size"] = "ôàéëû ñ ðàçìåðîì";
$net2ftp_messages["files which were last modified"] = "ôàéëû, èçìåíåííûå";
$net2ftp_messages["from"] = "îò";
$net2ftp_messages["to"] = "äî";

$net2ftp_messages["Directory"] = "Ïàïêà";
$net2ftp_messages["File"] = "Ôàéë";
$net2ftp_messages["Line"] = "Ñòðîêà";
$net2ftp_messages["Action"] = "Äåéñòâèå";
$net2ftp_messages["View"] = "Ïîêàç.";
$net2ftp_messages["Edit"] = "Ðåäàêò.";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "Ïîêàçàòü èñõîäíûé êîä %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "Ðåäàêòèðîâàòü èñõîäíûé êîä ôàéëà %1\$s";

} // end findstring


// -------------------------------------------------------------------------
// Help module
// -------------------------------------------------------------------------
// No messages yet


// -------------------------------------------------------------------------
// Install size module
if ($net2ftp_globals["state"] == "install") {
// -------------------------------------------------------------------------

// /modules/install/install.inc.php
$net2ftp_messages["Install software packages"] = "Óñòàíîâèòü ïàêåòû ÏÎ";
$net2ftp_messages["Unable to open the template file"] = "Íå óäàëîñü îòêðûòü âðåìåííûé ôàéë";
$net2ftp_messages["Unable to read the template file"] = "Íå óäàëîñü ïðî÷èòàòü âðåìåííûé ôàéë";
$net2ftp_messages["Unable to get the list of packages"] = "Íå óäàåòñÿ ïîëó÷èòü ñïèñîê ïàêåòîâ";

// /skins/blue/install1.template.php
$net2ftp_messages["The net2ftp installer script has been copied to the FTP server."] = "Óñòàíîâî÷íûé ñêðèïò net2ftp áûë ñêîïèðîâàí íà FTP ñåðâåð.";
$net2ftp_messages["This script runs on your web server and requires PHP to be installed."] = "Ýòîò ñêðèïò âûïîëíÿåòñÿ íà Âàøåì ñåðâåðå è òðåáóåò íàëè÷èå PHP.";
$net2ftp_messages["In order to run it, click on the link below."] = "Äëÿ çàïóñêà íàæìèòå ññûëêó íèæå";
$net2ftp_messages["net2ftp has tried to determine the directory mapping between the FTP server and the web server."] = "net2ftp ïîïûòàëñÿ îïðåäåëèòü ñâÿçü äèðåêòîðèé ìåæäó FTP- è âåá-ñåðâåðîì.";
$net2ftp_messages["Should this link not be correct, enter the URL manually in your web browser."] = "Should this link not be correct, enter the URL manually in your web browser.";

} // end install


// -------------------------------------------------------------------------
// Java upload module
if ($net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload directories and files using a Java applet"] = "Çàãðóçèòü ôàéëû è äèðåêòîðèè èñïîëüçóÿ Java àïïëåò";
$net2ftp_messages["Your browser does not support applets, or you have disabled applets in your browser settings."] = "Your browser does not support applets, or you have disabled applets in your browser settings.";
$net2ftp_messages["To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now."] = "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.";
$net2ftp_messages["The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment)."] = "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).";
$net2ftp_messages["Alternatively, use net2ftp's normal upload or upload-and-unzip functionality."] = "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.";

} // end jupload



// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login") {
// -------------------------------------------------------------------------
$net2ftp_messages["Login!"] = "Âîéòè!";
$net2ftp_messages["Once you are logged in, you will be able to:"] = "Êîãäà Âû îñóùåñòâèòå âõîä, Âû ñìîæåòå:";
$net2ftp_messages["Navigate the FTP server"] = "Ïðîñìàòðèâàòü ïàïêè è ôàéëû íà FTP-ñåðâåðå";
$net2ftp_messages["Once you have logged in, you can browse from directory to directory and see all the subdirectories and files."] = "Êîãäà Âû îñóùåñòâèòå âõîä, Âû ñìîæåòå ïåðåõîäèòü îò ïàïêè ê ïàïêå è ïðîñìàòðèâàòü âñå ôàéëû è ïîäïàïêè.";
$net2ftp_messages["Upload files"] = "Çàãðóçèòü ôàéëû íà ñåðâåð";
$net2ftp_messages["There are 3 different ways to upload files: the standard upload form, the upload-and-unzip functionality, and the Java Applet."] = "Åñòü 3 ñïîñîáà çàêà÷àòü ôàéëû: ñòàíäàðòíàÿ ôîðìà çàãðóçêè, ôóíêöèÿ upload-and-unzip (çàãðóçèòü è ðàñïàêîâàòü) è ñ ïîìîùüþ Java-àïïëåòà.";
$net2ftp_messages["Download files"] = "Ñêà÷àòü ôàéëû";
$net2ftp_messages["Click on a filename to quickly download one file.<br />Select multiple files and click on Download; the selected files will be downloaded in a zip archive."] = "Íàæìèòå íà èìÿ ôàéëà ÷òîáû áûñòðî çàãðóçèòü îäèí ôàéë.<br />Âûáåðèòå íåñêîëüêî ôàéëîâ è íàæìèòå Ñêà÷àòü - âûáðàííûå ôàéëû áóäóò ñêà÷àíû êàê zip-àðõèâ.";
$net2ftp_messages["Zip files"] = "Çàïàêîâàòü ôàéëû";
$net2ftp_messages["... and save the zip archive on the FTP server, or email it to someone."] = "... è ñîõðàíèòü àðõèâ íà ñåðâåðå èëè îòïðàâèòü ïî ïî÷òå.";
$net2ftp_messages["Unzip files"] = "Ðàñïàêîâàòü ôàéëû";
$net2ftp_messages["Different formats are supported: .zip, .tar, .tgz and .gz."] = "Ïîääåðæèâàþòñÿ ðàçëè÷íûå ôîðìàòû: .zip, .tar, .tgz è .gz.";
$net2ftp_messages["Install software"] = "Óñòàíîâèòü ÏÎ";
$net2ftp_messages["Choose from a list of popular applications (PHP required)."] = "Âûáðàòü èç ñïèñêà ïîïóëÿðíûõ ïðèëîæåíèé (òðåáóåòñÿ PHP).";
$net2ftp_messages["Copy, move and delete"] = "Êîïèðîâàòü, ïåðåìåùàòü è óäàëÿòü";
$net2ftp_messages["Directories are handled recursively, meaning that their content (subdirectories and files) will also be copied, moved or deleted."] = "Ïàïêè îáðàáàòûâàþòñÿ ðåêóðñèâíî, ÷òî îçíà÷àåò, ÷òî âñå ïîäïàïêè è ôàéëû â íèõ òàêæå áóäóò ñêîïèðîâàíû, ïåðåìåùåíû èëè óäàëåíû.";
$net2ftp_messages["Copy or move to a 2nd FTP server"] = "Ñêîïèðîâàòü èëè ïåðåìåñòèòü íà âòîðîé FTP-ñåðâåð";
$net2ftp_messages["Handy to import files to your FTP server, or to export files from your FTP server to another FTP server."] = "Óäîáíî äëÿ òîãî, ÷òîáû èìïîðòèðîâàòü ôàéëû íà FTP-ñåðâåð èëè îòïðàâèòü ôàéëâ ñ Âàøåãî FTP-ñåðâåðà íà äðóãîé FTP-ñåðâåð.";
$net2ftp_messages["Rename and chmod"] = "Ïåðåèìåíîâûâàòü è èçìåíÿòü ïðàâà äîñòóïà";
$net2ftp_messages["Chmod handles directories recursively."] = "Âûïîëíèòü chmod ðåêóðñèâíî.";
$net2ftp_messages["View code with syntax highlighting"] = "Ïðîñìîòð êîäà ñ ïîäñâåòêîé ñèíòàêñèñà";
$net2ftp_messages["PHP functions are linked to the documentation on php.net."] = "PHP functions are linked to the documentation on php.net.";
$net2ftp_messages["Plain text editor"] = "Òåêñòîâûé ðåäàêòîð";
$net2ftp_messages["Edit text right from your browser; every time you save the changes the new file is transferred to the FTP server."] = "Ðåäàêòèðîâàòü òåêñò ïðÿìî â áðàóçåðå. Êàæäûé ðàç, êîãäà Âû ñîõðàíÿåòå èçìåíåíèÿ, îíè êîïèðóþòñÿ íà FTP-ñåðâåð.";
$net2ftp_messages["HTML editors"] = "HTML ðåäàêòîð";
$net2ftp_messages["Edit HTML a What-You-See-Is-What-You-Get (WYSIWYG) form; there are 2 different editors to choose from."] = "Ðåäàêòèðîâàòü HTML ðåäàêòîðîì WYSIWYG. Ìîæíî âûáðàòü îäèí èç äâóõ ðåäàêòîðîâ.";
$net2ftp_messages["Code editor"] = "Ðåäàêòîð êîäà";
$net2ftp_messages["Edit HTML and PHP in an editor with syntax highlighting."] = "Ðåäàêòèðîâàòü HTML è PHP ñ ïîäñâåòêîé ñèíòàêñèñà.";
$net2ftp_messages["Search for words or phrases"] = "Èñêàòü ñëîâà è ôðàçû";
$net2ftp_messages["Filter out files based on the filename, last modification time and filesize."] = "Ôèëüòðîâàòü ôàéëû ïî èìåíè, âðåìåíè èçìåíåíèÿ è ðàçìåðó.";
$net2ftp_messages["Calculate size"] = "Ïîäñ÷èòàòü ðàçìåð";
$net2ftp_messages["Calculate the size of directories and files."] = "Ïîäñ÷èòàòü ðàçìåð äèðåêòîðèé è ôàéëîâ.";

$net2ftp_messages["FTP server"] = "FTP-ñåðâåð";
$net2ftp_messages["Example"] = "Ïðèìåð";
$net2ftp_messages["Port"] = "Ïîðò";
$net2ftp_messages["Protocol"] = "Protocol";
$net2ftp_messages["Username"] = "Ëîãèí";
$net2ftp_messages["Password"] = "Ïàðîëü";
$net2ftp_messages["Anonymous"] = "Àíîíèìíî";
$net2ftp_messages["Passive mode"] = "Ïàññèâíûé ðåæèì";
$net2ftp_messages["Initial directory"] = "Ïàïêà";
$net2ftp_messages["Language"] = "ßçûê";
$net2ftp_messages["Skin"] = "Ñêèí";
$net2ftp_messages["FTP mode"] = "Ðåæèì ðàáîòû FTP";
$net2ftp_messages["Automatic"] = "Àâòîìàòè÷åñêèé";
$net2ftp_messages["Login"] = "Âõîä";
$net2ftp_messages["Clear cookies"] = "Î÷èñòèòü êóêè";
$net2ftp_messages["Admin"] = "Àäìèíèñòðàòîð";
$net2ftp_messages["Please enter an FTP server."] = "Ïîæàëóéñòà, ââåäèòå FTP ñåðâåð.";
$net2ftp_messages["Please enter a username."] = "Ïîæàëóéñòà, ââåäèòå èìÿ ïîëüçîâàòåëÿ.";
$net2ftp_messages["Please enter a password."] = "Ïîæàëóéñòà, ââåäèòå ïàðîëü.";

} // end login


// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login_small") {
// -------------------------------------------------------------------------

$net2ftp_messages["Please enter your Administrator username and password."] = "Ïîæàëóéñòà, ââåäèòå ëîãèí è ïàðîëü àäìèíèñòðàòîðà.";
$net2ftp_messages["Please enter your username and password for FTP server <b>%1\$s</b>."] = "Ïîæàëóéñòà, ââåäèòå ëîãèí è ïàðîëü ê FTP ñåðâåðó <b>%1\$s</b>.";
$net2ftp_messages["Username"] = "Ëîãèí";
$net2ftp_messages["Your session has expired; please enter your password for FTP server <b>%1\$s</b> to continue."] = "Âðåìÿ äåéñòâèÿ ñåññèè èñòåêëî; ïîæàëóéñòà, ââåäèòå Âàø ïàðîëü ê FTP ñåðâåðó <b>%1\$s</b> ÷òîáû ïðîäîëæèòü.";
$net2ftp_messages["Your IP address has changed; please enter your password for FTP server <b>%1\$s</b> to continue."] = "Âàø IP àäðåñ èçìåíèëñÿ; ïîæàëóéñòà, ââåäèòå Âàø ïàðîëü îò FTP ñåðâåðà <b>%1\$s</b> ÷òîáû ïðîäîëæèòü.";
$net2ftp_messages["Password"] = "Ïàðîëü";
$net2ftp_messages["Login"] = "Âõîä";
$net2ftp_messages["Continue"] = "Ïðîäîëæèòü";

} // end login_small


// -------------------------------------------------------------------------
// Logout module
if ($net2ftp_globals["state"] == "logout") {
// -------------------------------------------------------------------------

// logout.inc.php
$net2ftp_messages["Login page"] = "Ñòðàíèöà âõîäà";

// logout.template.php
$net2ftp_messages["You have logged out from the FTP server. To log back in, <a href=\"%1\$s\" title=\"Login page (accesskey l)\" accesskey=\"l\">follow this link</a>."] = "Âû âûøëè ñ FTP ñåðâåðà. ×òîáû çàéòè îáðàòíî, <a href=\"%1\$s\" title=\"Login page (accesskey l)\" accesskey=\"l\">íàæìèòå íà ýòó ññûëêó</a>.";
$net2ftp_messages["Note: other users of this computer could click on the browser's Back button and access the FTP server."] = "Âíèìàíèå: äðóãèå ïîëüçîâàòåëè ýòîãî êîìïüþòåðà ìîãóò íàæàòü íà êíîïêó \"íàçàä\" è ïîëó÷èòü äîñòóï ê FTP ñåðâåðó.";
$net2ftp_messages["To prevent this, you must close all browser windows."] = "×òîáû ïðåäîòâðàòèòü ýòî, çàêðîéòå âñå îêíà áðàóçåðà.";
$net2ftp_messages["Close"] = "Çàêðûòü";
$net2ftp_messages["Click here to close this window"] = "Íàæìèòå çäåñü, ÷òîáû çàêðûòü îêíî";

} // end logout


// -------------------------------------------------------------------------
// New directory module
if ($net2ftp_globals["state"] == "newdir") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create new directories"] = "Ñîçäàòü íîâûå ïàïêè";
$net2ftp_messages["The new directories will be created in <b>%1\$s</b>."] = "Íîâûå ïàïêè áóäóò ñîçäàíû â <b>%1\$s</b>.";
$net2ftp_messages["New directory name:"] = "Íîâîå èìÿ ïàïêè:";
$net2ftp_messages["Directory <b>%1\$s</b> was successfully created."] = "Ïàïêà <b>%1\$s</b> áûëà óñïåøíî ñîçäàíà.";
$net2ftp_messages["Directory <b>%1\$s</b> could not be created."] = "Äèðåêòîðèÿ <b>%1\$s</b> íå ìîæåò áûòü ñîçäàíà.";

} // end newdir


// -------------------------------------------------------------------------
// Raw module
if ($net2ftp_globals["state"] == "raw") {
// -------------------------------------------------------------------------

// /modules/raw/raw.inc.php
$net2ftp_messages["Send arbitrary FTP commands"] = "Îòïðàâêà ñëó÷àéíîé FTP êîìàíäû";


// /skins/[skin]/raw1.template.php
$net2ftp_messages["List of commands:"] = "Ñïèñîê êîìàíä:";
$net2ftp_messages["FTP server response:"] = "Îòâåò FTP ñåðâåðà:";

} // end raw


// -------------------------------------------------------------------------
// Rename module
if ($net2ftp_globals["state"] == "rename") {
// -------------------------------------------------------------------------
$net2ftp_messages["Rename directories and files"] = "Ïåðåèìåíîâàòü ïàïêè è ôàéëû";
$net2ftp_messages["Old name: "] = "Ñòàðîå èìÿ: ";
$net2ftp_messages["New name: "] = "Íîâîå èìÿ: ";
$net2ftp_messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "Èìÿ íå ìîæåò ñîäåðæàòü òî÷åê. Íå áûëî ïåðåèìåíîâàíî â <b>%1\$s</b>";
$net2ftp_messages["The new name may not contain any banned keywords. This entry was not renamed to <b>%1\$s</b>"] = "Èìÿ íå ìîæåò ñîäåðæàòü çàïðåùåííûå ñëîâà. Ôàéë íå áûë ïåðåèìåíîâàí â <b>%1\$s</b>";
$net2ftp_messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> áûëî óñïåøíî ïåðåèìåíîâàíî â <b>%2\$s</b>";
$net2ftp_messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> íå óäàëîñü ïåðåèìåíîâàòü â <b>%2\$s</b>";

} // end rename


// -------------------------------------------------------------------------
// Unzip module
if ($net2ftp_globals["state"] == "unzip") {
// -------------------------------------------------------------------------

// /modules/unzip/unzip.inc.php
$net2ftp_messages["Unzip archives"] = "Ðàñïîêàâàòü àðõèâû";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "Ïîëó÷åíèå àðõèâà %1\$s of %2\$s ñ FTP ñåðâåðà";
$net2ftp_messages["Unable to get the archive <b>%1\$s</b> from the FTP server"] = "Íå óäàëîñü ïîëó÷èòü àðõèâ <b>%1\$s</b> ñ FTP ñåðâåðà";

// /skins/[skin]/unzip1.template.php
$net2ftp_messages["Set all targetdirectories"] = "Âûáðàòü âñå ïàïêè";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "×òîáû çàäàòü ãëàâíóþ ïàïêó, ââåäèòå å¸ íàçâàíèå â ïîëå âûøå è âûáåðèòå ïóíêò \"Âûáðàòü âñå ïàïêè\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "Ïðèìå÷àíèå: ïàïêà äîëæíà óæå ñóùåñòâîâàòü.";
$net2ftp_messages["Unzip archive <b>%1\$s</b> to:"] = "Ðàñïàêîâàòü àðõèâ <b>%1\$s</b> to:";
$net2ftp_messages["Target directory:"] = "Ïàïêà íàçíà÷åíèÿ:";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "Èñïîëüçîâàòü èìåíà ïàïîê (ñîçäàâàòü ïîäïàïêè àâòîìàòè÷åñêè)";

} // end unzip


// -------------------------------------------------------------------------
// Upload module
if ($net2ftp_globals["state"] == "upload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload to directory:"] = "Çàêà÷àòü â ïàïêó:";
$net2ftp_messages["Files"] = "Ôàéëû";
$net2ftp_messages["Archives"] = "Àðõèâû";
$net2ftp_messages["Files entered here will be transferred to the FTP server."] = "Ôàéëû, ââåäåííûå çäåñü áóäóò ïåðåìåùåíû íà FTP-ñåðâåð.";
$net2ftp_messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Àðõèâû ââåäåííûå çäåñü áóäóò ðàñïàêîâàíû è ôàéëû áóäóò ïåðåìåùåíû íà FTP-ñåðâåð.";
$net2ftp_messages["Add another"] = "Äîáàâèòü äðóãîé";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "Èñïîëüçîâàòü èìåíà ïàïîê (ñîçäàâàòü ïîäïàïêè àâòîìàòè÷åñêè)";

$net2ftp_messages["Choose a directory"] = "Âûáåðèòå ïàïêó";
$net2ftp_messages["Please wait..."] = "Ïîæàëóéñòà, ïîäîæäèòå...";
$net2ftp_messages["Uploading... please wait..."] = "Çàãðóçêà... ïîäîæäèòå...";
$net2ftp_messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "Åñëè çàêà÷êà çàíèìàåò áîëåå <b>%1\$s ñåêóíä<\/b>, ïîïðîáóéòå çàãðóçèòü ìåíüøå èëè ìåíüøèå ôàéëû.";
$net2ftp_messages["This window will close automatically in a few seconds."] = "Ýòî îêíî àâòîìàòè÷åñêè çàêðîåòñÿ ÷åðåç íåñêîëüêî ñåêóíä.";
$net2ftp_messages["Close window now"] = "Çàêðûòü îêíî ñåé÷àñ";

$net2ftp_messages["Upload files and archives"] = "Çàêà÷àòü ôàéëû è ïàïêè";
$net2ftp_messages["Upload results"] = "Ðåçóëüòàòû çàêà÷èâàíèÿ";
$net2ftp_messages["Checking files:"] = "Ïðîâåðêà ôàéëîâ:";
$net2ftp_messages["Transferring files to the FTP server:"] = "Ïåðåìåùåíèå ôàéëîâ íà FTP-ñåðâåð:";
$net2ftp_messages["Decompressing archives and transferring files to the FTP server:"] = "Èçâëå÷åíèå è ïåðåìåùåíèå ôàéëîâ íà ñåðâåð:";
$net2ftp_messages["Upload more files and archives"] = "Çàêà÷àòü äðóãèå ôàéëû è àðõèâû";

} // end upload


// -------------------------------------------------------------------------
// Messages which are shared by upload and jupload
if ($net2ftp_globals["state"] == "upload" || $net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Restrictions:"] = "Îãðàíè÷åíèÿ:";
$net2ftp_messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s</b> and by PHP to <b>%2\$s</b>"] = "Ìàêñèìàëüíûé ðàçìåð îäíîãî ôàéëà îãðàíè÷åí net2ftp äî <b>%1\$s</b> è PHP äî <b>%2\$s</b>";
$net2ftp_messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Ìàêñèìàëüíîå âðåìÿ âûïîëíåíèÿ <b>%1\$s ñåêóíä</b>";
$net2ftp_messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Ðåæèì ïåðåäà÷è FTP (ASCII èëè BINARY) áóäåò àâòîìàòè÷åñêè îïðåäåëåí, îñíîâàí íà ðàñøèðåíèè";
$net2ftp_messages["If the destination file already exists, it will be overwritten"] = "Åñëè ôàéë óæå ñóùåñòâóåò, îí áóäåò ïåðåçàïèñàí";

} // end upload or jupload


// -------------------------------------------------------------------------
// View module
if ($net2ftp_globals["state"] == "view") {
// -------------------------------------------------------------------------

// /modules/view/view.inc.php
$net2ftp_messages["View file %1\$s"] = "Ïðîñìîòð ôàéëà %1\$s";
$net2ftp_messages["View image %1\$s"] = "Ïîêàçàòü ðèñóíîê %1\$s";
$net2ftp_messages["View Macromedia ShockWave Flash movie %1\$s"] = "Ïîñìîòðåòü ðîëèê Macromedia ShockWave Flash %1\$s";
$net2ftp_messages["Image"] = "Èçîáðàæåíèå";

// /skins/[skin]/view1.template.php
$net2ftp_messages["Syntax highlighting powered by <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>"] = "Ïîäñâåòêà ñèíòàêñèñà ðåàëèçîâàíà <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>";
$net2ftp_messages["To save the image, right-click on it and choose 'Save picture as...'"] = "Äëÿ ñîõðàíåíèÿ íàæìèòå ïðàâóþ êëàâèøó ìûøè è âûáåðèòå 'Save picture as...'";

} // end view


// -------------------------------------------------------------------------
// Zip module
if ($net2ftp_globals["state"] == "zip") {
// -------------------------------------------------------------------------

// /modules/zip/zip.inc.php
$net2ftp_messages["Zip entries"] = "Ñîäåðæèìîå Zip";

// /skins/[skin]/zip1.template.php
$net2ftp_messages["Save the zip file on the FTP server as:"] = "Ñîõðàíèòü zip-ôàéë íà FTP-ñåðâåðå êàê:";
$net2ftp_messages["Email the zip file in attachment to:"] = "Email zip-ôàéë ïðèêðåïëåííûì:";
$net2ftp_messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Çàìåòüòå, ÷òî îòïðàâêà ôàéëîâ íå àíîíèìíà: âàø IP-àäðåñ òàê æå êàê è âðåìÿ îòïðàâëåíèÿ áóäåò äîáàâëåí â email.";
$net2ftp_messages["Some additional comments to add in the email:"] = "Êîììåíòàðèè ê email:";

$net2ftp_messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "Âû íå ââåëè èìÿ ôàéëà äëÿ zip. Âåðíèòåñü íàçàä è ââåäèòå èìÿ ôàéëà.";
$net2ftp_messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "Email àäðåñ, êîòîðûé âû ââåëè (%1\$s) íåïðàâèëåí.<br />Ïîæàëóéñòà, ââåäèòå àäðåñ â ôîðìàòå <b>èìÿ_ïîëüçîâàòåëÿ@äîìåí.ru</b>";

} // end zip

?>