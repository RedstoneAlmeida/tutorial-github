<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2013 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | For credits, see the credits.txt file                                         |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a été copié vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |      if ($net2ftp_globals["state2"] == "rename") {           // <-- PHP code  |
//  |          $net2ftp_messages["Rename file"] = "Rename file";   // <-- message   |
//  |      }                                                       // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------


// -------------------------------------------------------------------------
// Language settings
// -------------------------------------------------------------------------

// HTML lang attribute
$net2ftp_messages["en"] = "ua";

// HTML dir attribute: left-to-right (LTR) or right-to-left (RTL)
$net2ftp_messages["ltr"] = "ltr";

// CSS style: align left or right (use in combination with LTR or RTL)
$net2ftp_messages["left"] = "left";
$net2ftp_messages["right"] = "right";

// Encoding
$net2ftp_messages["iso-8859-1"] = "windows-1251";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------

// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox

$net2ftp_messages["Connecting to the FTP server"] = "Ç'ºäíàííÿ ç FTP-ñåðâåðîì";
$net2ftp_messages["Logging into the FTP server"] = "Âõiä íà FTP-ñåðâåð";
$net2ftp_messages["Setting the passive mode"] = "Âñòàíîâëåííÿ ïàññèâíîãî ðåæèìà";
$net2ftp_messages["Getting the FTP system type"] = "Âèçíà÷åííÿ  òèïó FTP ñåðâåðà";
$net2ftp_messages["Changing the directory"] = "Çìiíà äèðåêòîði¿";
$net2ftp_messages["Getting the current directory"] = "Çìiíà ïîòî÷íî¿ äèðåêòîði¿";
$net2ftp_messages["Getting the list of directories and files"] = "Îòðèìàííÿ ñïèñêó ïàïîê òà ôàéëiâ";
$net2ftp_messages["Parsing the list of directories and files"] = "Îáðîáêà ñïèñêó ôàéëiâ òà äèðåêòîðié";
$net2ftp_messages["Logging out of the FTP server"] = "Âèõiä ç FTP ñåðâåðà";
$net2ftp_messages["Getting the list of directories and files"] = "Îòðèìàííÿ ñïèñêó ïàïîê òà ôàéëiâ";
$net2ftp_messages["Printing the list of directories and files"] = "Âèâiä ñïèñêó ïàïîê òà ôàéëiâ";
$net2ftp_messages["Processing the entries"] = "Îáðîáêà çìiñòó";
$net2ftp_messages["Processing entry %1\$s"] = "Îáðîáêà çàïèñó %1\$s";
$net2ftp_messages["Checking files"] = "Ïåðåâiðêà ôàéëiâ";
$net2ftp_messages["Transferring files to the FTP server"] = "Ïåðåìiùåííÿ ôàéëiâ íà FTP-ñåðâåð";
$net2ftp_messages["Decompressing archives and transferring files"] = "Ðîçïàêóâàííÿ àðõiâiâ òà ïåðåìiùåííÿ ôàéëiâ";
$net2ftp_messages["Searching the files..."] = "Ïîøóê ôàéëó...";
$net2ftp_messages["Uploading new file"] = "Çàêà÷àòè íîâèé ôàéë";
$net2ftp_messages["Reading the file"] = "×èòàííÿ ôàéëó";
$net2ftp_messages["Parsing the file"] = "Ðåäàãóâàííÿ ôàéëó";
$net2ftp_messages["Reading the new file"] = "×èòàííÿ íîâîãî ôàéëó";
$net2ftp_messages["Reading the old file"] = "×èòàííÿ ñòàðîãî ôàéëó";
$net2ftp_messages["Comparing the 2 files"] = "Ïîðiâíÿííÿ äâîõ ôàéëiâ";
$net2ftp_messages["Printing the comparison"] = "Âèâiä ðåçóëüòàòó";
$net2ftp_messages["Sending FTP command %1\$s of %2\$s"] = "Âiäïðàâëåííÿ FTP êîìàíäè %1\$s of %2\$s";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "Îòðèìàííÿ àðõiâó %1\$s of %2\$s ç FTP ñåðâåðà";
$net2ftp_messages["Creating a temporary directory on the FTP server"] = "Ñòâîðåííÿ òèì÷àñîâî¿ äèðåêòîði¿ íà FTP ñåðâåði";
$net2ftp_messages["Setting the permissions of the temporary directory"] = "Âñòàíîâëåííÿ ïðàâ íà òèì÷àñîâó äèðåêòîðiþ";
$net2ftp_messages["Copying the net2ftp installer script to the FTP server"] = "Êîïiþâàííÿ óñòàíîâî÷íîãî ñêðèïòà íà FTP ñåðâåð";
$net2ftp_messages["Script finished in %1\$s seconds"] = "Ñêðèïò âèêîíàíèé çà %1\$s ñåêóíä";
$net2ftp_messages["Script halted"] = "Ñêðèïò ïåðåðâàíèé";

// Used on various screens
$net2ftp_messages["Please wait..."] = "Áóäü ëàñêà, çà÷åêàéòå...";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unexpected state string: %1\$s. Exiting."] = "Íåñïîäiâàíèé ôîðìàò ðÿäêà: %1\$s. Âèõiä.";
$net2ftp_messages["This beta function is not activated on this server."] = "Öÿ áåòà ôóíêöiÿ íå àêòèâîâàíà íà ñåðâåði.";
$net2ftp_messages["This function has been disabled by the Administrator of this website."] = "Äàííàÿ ôóíêöiÿ âiäêëþ÷åíà Àäìiíiñòðàòîðîì.";


// -------------------------------------------------------------------------
// /includes/browse.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the directory <b>%2\$s</b> is shown instead."] = "Äèðåêòîðiÿ <b>%1\$s</b> íå iñíóº àáî íå ìîæå áóòè âèáðàíîþ, òîìóùî âèáðàíà äèðåêòîðiÿ <b>%2\$s</b> .";
$net2ftp_messages["Your root directory <b>%1\$s</b> does not exist or could not be selected."] = "Âàøà êîðíåâàÿ äèðåêòîðiÿ <b>%1\$s</b> íå iñíóº àáî íå ìîæå áóòè âèáðàíîþ.";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected - you may not have sufficient rights to view this directory, or it may not exist."] = "Äèðåêòîðiÿ <b>%1\$s</b> íå ìîæå áóòè âèáðàíà - ó Âàñ ìîæå áóòè íåäîñòàòíüî ïðàâ äëÿ ïåðåãëÿäó àáî äèðåêòîðiÿ íå iñíóº.";
$net2ftp_messages["Entries which contain banned keywords can't be managed using net2ftp. This is to avoid Paypal or Ebay scams from being uploaded through net2ftp."] = "Ç äîïîìîãîþ net2ftp íåìîæëèâî êåðóâàòè äàííèìè, ÿêi ìiñòÿòü çàáîðîíåíi ñëîâà. Öå íåîáõiäíî äëÿ çàõèñòó âiä ïiäðîáîê PayPal àáî Ebay.";
$net2ftp_messages["Files which are too big can't be downloaded, uploaded, copied, moved, searched, zipped, unzipped, viewed or edited; they can only be renamed, chmodded or deleted."] = "Çàíàäòî âåëèêi ôàéëè íåìîæíà çàâàíòàæóâàòè, êîïiþâàòè, ïåðåìiùàòè, àðõiâóâàòè, ðîçïàêîâóâàòè, ïåðåãëÿäàòè àáî ðåäàãóâàòè; ¿õ ìîæíà ïåðåéìåíîâóâàòè, çìiíþâàòè ïðàâà äîñòóïó àáî âèäàëÿòè.";
$net2ftp_messages["Execute %1\$s in a new window"] = "Âèêîíàòè %1\$s â íîâîìó âiêíi";


// -------------------------------------------------------------------------
// /includes/main.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please select at least one directory or file!"] = "Âèáåðiòü õî÷à á îäíó ïàïêó àáî ôàéë.";


// -------------------------------------------------------------------------
// /includes/authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$net2ftp_messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "FTP-ñåðâåð <b>%1\$s</b> íå çíàéäåíèé â ñïèñêó äîçâîëåíèõ FTP-ñåðâåðiâ.";
$net2ftp_messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "FTP-ñåðâåð <b>%1\$s</b> çíàõîäèòüñÿ â ñïèñêó çàáîðîíåíèõ FTP-ñåðâåðiâ.";
$net2ftp_messages["The FTP server port %1\$s may not be used."] = "Ïîðò FTP-ñåðâåðà %1\$s íå ìîæå âèêîðèñòîâóâàòèñÿ.";
$net2ftp_messages["Your IP address (%1\$s) is not in the list of allowed IP addresses."] = "Âàø IP-àäðåñà (%1\$s) íå çíàõîäèòüñÿ â ñïèñêó äîçâîëåíèõ.";
$net2ftp_messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Âàø IP-àäðåñà (%1\$s) çíàõîäèòüñÿ â ñïèñêó çàáîðîíåíèõ IP-àäðåñ.";

// isAuthorizedDirectory()
$net2ftp_messages["Table net2ftp_users contains duplicate rows."] = "Òàáëèöÿ net2ftp_users ìiñòèòü îäíàêîâi çàïèñè.";

// checkAdminUsernamePassword()
$net2ftp_messages["You did not enter your Administrator username or password."] = "Âè íå âêàçàëè iì'ÿ êîðèñòóâà÷à àáî ïàðîëü Àäìiíiñòðàòîðà.";
$net2ftp_messages["Wrong username or password. Please try again."] = "Íåïðàâèëüíå iì'ÿ êîðèñòóâà÷à àáî ïàðîëü. Áóäü ëàñêà, ñïðîáóéòå ùå ðàç.";

// -------------------------------------------------------------------------
// /includes/consumption.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to determine your IP address."] = "Íå âäàºòüñÿ ðîçïiçíàòè Âàøó ip àäðåñó.";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate rows."] = "Òàáëèöÿ net2ftp_log_consumption_ipaddress ìiñòèòü îäíàêîâi çàïèñè.";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate rows."] = "Òàáëèöÿ net2ftp_log_consumption_ftpserver ìiñòèòü îäíàêîâi çàïèñè.";
$net2ftp_messages["The variable <b>consumption_ipaddress_datatransfer</b> is not numeric."] = "Çìiííà <b>consumption_ipaddress_datatransfer</b> íå ÿâëÿºòüñÿ ÷èñëîì.";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress could not be updated."] = "Íå âäàëîñÿ îíîâèòè òàáëèöþ net2ftp_log_consumption_ipaddress.";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate entries."] = "Òàáëèöÿ net2ftp_log_consumption_ipaddress ìiñòèòü îäíàêîâi çàïèñè.";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver could not be updated."] = "Íå âäàëîñÿ îíîâèòè òàáëèöþ net2ftp_log_consumption_ftpserver.";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate entries."] = "Table net2ftp_log_consumption_ftpserver contains duplicate entries.";
$net2ftp_messages["Table net2ftp_log_access could not be updated."] = "Íå âäàëîñÿ îíîâèòè òàáëèöþ net2ftp_log_access.";
$net2ftp_messages["Table net2ftp_log_access contains duplicate entries."] = "Òàáëèöÿ net2ftp_log_access ìiñòèòü îäíàêîâi çàïèñè.";


// -------------------------------------------------------------------------
// /includes/database.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to connect to the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "Íåìîæëèâî ç'ºäíàòèñÿ ç ñåðâåðîì MySQL. Ïåðåâiðòå ïàðàìåòðè ïiäêëþ÷åííÿ â ôàéëi settings.inc.php.";
$net2ftp_messages["Unable to select the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "Unable to select the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php.";


// -------------------------------------------------------------------------
// /includes/errorhandling.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["An error has occured"] = "Âèíèêëà ïîìèëêà";
$net2ftp_messages["Go back"] = "Íàçàä";
$net2ftp_messages["Go to the login page"] = "Íà ñòîðiíêó âõîäó";


// -------------------------------------------------------------------------
// /includes/filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Íå âäàëîñÿ ç'ºäíàòèñÿ ç FTP-ñåðâåðîì <b>%1\$s</b> íà ïîðòó <b>%2\$s</b>.<br /><br />×è ïðàâèëüíà àäðåñà FTP-ñåðâåðà? Âîíà ÷àñòî âiäðiçíÿºòüñÿ âiä àäðåñà HTTP-ñåðâåðà. Áóäü ëàñêà, çâ'ÿæiòüñÿ ç òåõïiäòðèìêîþ âàøîãî ISP àáî ñèñàäìiíîì.<br />";
$net2ftp_messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Íå âäàëîñÿ ââiéòè íà FTP-ñåðâåð <b>%1\$s</b> ç ëîãiíîì <b>%2\$s</b>.<br /><br />Ïðàâèëüíi ëîãií òà ïàðîëü? Áóäü ëàñêà, çâ'ÿæiòüñÿ ç òåõïiäòðèìêîþ âàøîãî ISP àáî ñèñàäìiíîì.<br />";
$net2ftp_messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Íå âäàëîñÿ ïåðåìêíóòèñÿ â ïàñèâíèé ðåæèì FTP <b>%1\$s</b>.";

// ftp_openconnection2()
$net2ftp_messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Íå âäàëîñÿ ç'ºäíàòèñÿ ç äðóãèì FTP-ñåðâåðîì <b>%1\$s</b> íà ïîðòó <b>%2\$s</b>.<br /><br />×è ïðàâèëüíà àäðåñà FTP-ñåðâåðà? Âîíà ÷àñòî âiäðiçíÿºòüñÿ âiä àäðåñà HTTP-ñåðâåðà. Áóäü ëàñêà, çâ'ÿæiòüñÿ ç òåõïiäòðèìêîþ âàøîãî ISP àáî ñèñàäìiíîì.<br />";
$net2ftp_messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Íå âäàëîñÿ ç'ºäíàòèñÿ ç äðóãèì FTP-ñåðâåðîì <b>%1\$s</b> ç ëîãiíîì <b>%2\$s</b>.<br /><br />Ïðàâèëüíi iì'ÿ êîðèñòóâà÷à òà ïàðîëü? Áóäü ëàñêà, çâ'ÿæiòüñÿ ç òåõïiäòðèìêîþ âàøîãî ISP àáî ñèñàäìiíîì.<br />";
$net2ftp_messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Íå âäàëîñÿ ïåðåìêíóòèñÿ â ïàñèâíèé ðåæèì íà äðóãîìó FTP <b>%1\$s</b>.";

// ftp_myrename()
$net2ftp_messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Íå âäàëîñÿ ïåðåéìåíóâàòè ïàïêó àáî ôàéë <b>%1\$s</b> â <b>%2\$s</b>";

// ftp_mychmod()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Íå âäàëîñÿ âèêîíàòè êîìàíäó <b>%1\$s</b>. Êîìàíäà CHMOD äîñòóïíà òiëüêè íà Unix-ñåðâåðàõ.";
$net2ftp_messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "Ïàïêà <b>%1\$s</b> óñïiøíî chmodded <b>%2\$s</b>";
$net2ftp_messages["Processing entries within directory <b>%1\$s</b>:"] = "Îáðîáêà ôàéëiâ äèðåêòîðié <b>%1\$s</b>:";
$net2ftp_messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "Ôàéë <b>%1\$s</b> óñïiøíî chmodded <b>%2\$s</b>";
$net2ftp_messages["All the selected directories and files have been processed."] = "Âñi âèáðàíi ïàïêè òà ôàéëè ïåðåâiðåíi.";

// ftp_rmdir2()
$net2ftp_messages["Unable to delete the directory <b>%1\$s</b>"] = "Íå âäàëîñÿ âèäàëèòè ïàïêó <b>%1\$s</b>";

// ftp_delete2()
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "Íå âäàëîñÿ âèäàëèòè ôàéë <b>%1\$s</b>";

// ftp_newdirectory()
$net2ftp_messages["Unable to create the directory <b>%1\$s</b>"] = "Íå âäàëîñÿ ñòâîðèòè ïàïêó <b>%1\$s</b>";

// ftp_readfile()
$net2ftp_messages["Unable to create the temporary file"] = "Íå âäàëîñÿ ñòâîðèòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Íå âäàëîñÿ çàâàíòàæèòè ôàéë <b>%1\$s</b> ç FTP-ñåðâåðà òà çáåðåãòè éîãî ÿê òèì÷àñîâèé ôàéë <b>%2\$s</b>.<br />Ïåðåâiðòå äîçâîëè ïàïêè %3\$s.<br />";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Íå âäàëîñÿ âiäêðèòè ôàéë. Ïåðåâiðòå äîçâîëè ïàïêè %1\$s.";
$net2ftp_messages["Unable to read the temporary file"] = "Íå âäàëîñÿ ïðî÷èòàòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "Íå âäàëîñÿ çàêðèòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["Unable to delete the temporary file"] = "Íå âäàëîñÿ âèäàëèòè òèì÷àñîâèé ôàéë";

// ftp_writefile()
$net2ftp_messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Íå âäàëîñÿ ñòâîðèòè òèì÷àñîâèé ôàéë. Ïåðåâiðòå äîçâîëè ïàïêè %1\$s.";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Íå âäàëîñÿ âiäêðèòè ôàéë. Ïåðåâiðòå äîçâîëè ïàïêè %1\$s.";
$net2ftp_messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Íå âäàëîñÿ çàïèñàòè ðÿäîê â òèì÷àñîâèé ôàéë <b>%1\$s</b>.<br />Ïåðåâiðòå äîçâîëè ïàïêè %2\$s.";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "Íå âäàëîñÿ çàêðèòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Íå âäàëîñÿ çàâàíòàæèòè ôàéë <b>%1\$s</b> íà FTP-ñåðâåð.<br />Ìàáóòü, ó âàñ íåìàº ïðàâ.";
$net2ftp_messages["Unable to delete the temporary file"] = "Íå âäàëîñÿ âèäàëèòè òèì÷àñîâèé ôàéë";

// ftp_copymovedelete()
$net2ftp_messages["Processing directory <b>%1\$s</b>"] = "Ïåðåâiðêà ïàïêè <b>%1\$s</b>";
$net2ftp_messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "Ïàïêà ïðèçíà÷åííÿ <b>%1\$s</b> çïiâïàäàº ç ïiäïàïêîþ <b>%2\$s</b>, òîìó âîíà áóäå ïðîïóùåíà";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, so this directory will be skipped"] = "Äèðåêòîðiÿ <b>%1\$s</b> ìiñòèòü çàáîðîíåíå ñëîâî, òîìó äèðåêòîðiÿ áóäåò ïðîïóùåíà";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, aborting the move"] = "Äèðåêòîðiÿ <b>%1\$s</b> ìiñòèòü çàáîðîíåíå ñëîâî, ïåðåìiùåííÿ íå áóäå âèêîíàíî";
$net2ftp_messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Íå âäàëîñÿ ñòâîðèòè ï³äïàïêó <b>%1\$s</b>. Âîíà âæå iñíóº. Ïðîäîâæåííÿ ïðîöåñó...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "Ñòâîðåíî ïiäïàïêó <b>%1\$s</b>";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected, so this directory will be skipped"] = "Äèðåêòîðiÿ <b>%1\$s</b> íå ìîæå áóòè âèáðàíà, òîìóùî âîíà áóäå ïðîïóùåíà";
$net2ftp_messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Íå âäàëîñÿ âèäàëèòè ï³äïàïêó <b>%1\$s</b> - âîíà íå ïóñòà";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "Âèäàëåíà ïiäïàïêà <b>%1\$s</b>";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "Âèäàëåíà ïiäïàïêà <b>%1\$s</b>";
$net2ftp_messages["Unable to move the directory <b>%1\$s</b>"] = "Unable to move the directory <b>%1\$s</b>";
$net2ftp_messages["Moved directory <b>%1\$s</b>"] = "Moved directory <b>%1\$s</b>";
$net2ftp_messages["Processing of directory <b>%1\$s</b> completed"] = "Ïåðåâiðêà ïàïêè <b>%1\$s</b> çàêií÷åíà";
$net2ftp_messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "Ôàéë ïðèçíà÷åííÿ <b>%1\$s</b> çïiâïàäàº ç âèõiäíèì ôàéëîì, âií áóäå ïðîïóùåíèé";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, so this file will be skipped"] = "Ôàéë <b>%1\$s</b> ìiñòèòü çàáîðîíåíi ñëîâà, òîìó ôàéë áóäå ïðîïóùåíèé";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, aborting the move"] = "Ôàéë <b>%1\$s</b> ìiñòèòü çàáîðîíåíi ñëîâà, ôàéë íå áóäå ïåðåìiùåíèé";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be copied, so this file will be skipped"] = "Ôàéë <b>%1\$s</b> çàíàäòî âåëèêèé äëÿ êîïiþâàííÿ, òîìó âií áóäå ïðîïóùåíèé";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be moved, aborting the move"] = "Ôàéë <b>%1\$s</b> çàíàäòî âåëèêèé äëÿ ïåðåìiùåííÿ, ïåðåìiùåííÿ íå áóäå âèêîíàíî";
$net2ftp_messages["Unable to copy the file <b>%1\$s</b>"] = "Íå âäàëîñÿ çêîïiþâàòè ôàéë <b>%1\$s</b>";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>, aborting the move"] = "Íå âäàëîñÿ ïåðåìiñòèòè ôàéë <b>%1\$s</b>, ïåðåìiùåííÿ íå âèêîíàíî.";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>"] = "Unable to move the file <b>%1\$s</b>";
$net2ftp_messages["Moved file <b>%1\$s</b>"] = "Ïåðåìiùåíî ôàéë <b>%1\$s</b>";
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "Íå âäàëîñÿ âèäàëèòè ôàéë <b>%1\$s</b>";
$net2ftp_messages["Deleted file <b>%1\$s</b>"] = "Âèäàëåíî ôàéë <b>%1\$s</b>";
$net2ftp_messages["All the selected directories and files have been processed."] = "Âñi âèáðàíi ïàïêè òà ôàéëè ïåðåâiðåíi.";

// ftp_processfiles()

// ftp_getfile()
$net2ftp_messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Íå âäàëîñÿ ñêîïiþâàòè âèäàëåíèé ôàéë <b>%1\$s</b> íà ëîêàëüíèé êîìï'þòåð, âèêîðèñòîâóþ÷è FTP-ht;bv <b>%2\$s</b>";
$net2ftp_messages["Unable to delete file <b>%1\$s</b>"] = "Íå âäàëîñÿ âèäàëèòè ôàéë <b>%1\$s</b>";

// ftp_putfile()
$net2ftp_messages["The file is too big to be transferred"] = "Ôàéë çàíàäòî âåëèêèé äëÿ ïåðåäà÷i.";
$net2ftp_messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Äîñÿãíóòî äîáîâèé ëiìiò: ôàéë <b>%1\$s</b> íå áóäå ïåðåäàíèé";
$net2ftp_messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Íå âäàëîñÿ ñêîïiþâàòè ëîêàëüíèé ôàéë <b>%1\$s</b> íà âèäàëåíèé êîìï'þòåð, âèêîðèñòîâóþ÷è ðåæèì <b>%2\$s</b>";
$net2ftp_messages["Unable to delete the local file"] = "Íå âäàëîñÿ âèäàëèòè ëîêàëüíèé ôàéë";

// ftp_downloadfile()
$net2ftp_messages["Unable to delete the temporary file"] = "Íå âäàëîñÿ âèäàëèòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["Unable to send the file to the browser"] = "Íåìîæëèâî ïåðåäàòè ôàéë áðàóçåð";

// ftp_zip()
$net2ftp_messages["Unable to create the temporary file"] = "Íå âäàëîñÿ ñòâîðèòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "Zip-ôàéë çáåðåæåíèé íà FTP-ñåðâåði ÿê <b>%1\$s</b>";
$net2ftp_messages["Requested files"] = "Çàïèòàíi ôàéëè";

$net2ftp_messages["Dear,"] = "Øàíîâíèé,";
$net2ftp_messages["Someone has requested the files in attachment to be sent to this email account (%1\$s)."] = "Õòîñü (ìîæëèâî Âè) âiäïðàâèâ ôàéëè, ïðèêëàäåíi äî ëèñòîâi, íà öþ àäðåñó (%1\$s).";
$net2ftp_messages["If you know nothing about this or if you don't trust that person, please delete this email without opening the Zip file in attachment."] = "ßêùî Âè íå çíàºòå, ùî öå çà ôàéëè, àáî íå äîâiðÿºòå âiäïðàâíèêîâi, áóäü ëàñêà, âèäàëèòå öåé ëèñò, íå âiäêðèâàþ÷è ôàéëè.";
$net2ftp_messages["Note that if you don't open the Zip file, the files inside cannot harm your computer."] = "ßêùî Âè íå áóäåòå âiäêðèâàòè zip-ôàéë, ôàéëè, ùî óòðèìóþòüñÿ â íüîìó, âîíè íå çìîæóòü çàøêîäèòè Âàøîìó êîìï'þòåðîâi.";
$net2ftp_messages["Information about the sender: "] = "Iíôîðìàöiÿ ïðî âiäïðàâíèêà: ";
$net2ftp_messages["IP address: "] = "IP-àäðåñà: ";
$net2ftp_messages["Time of sending: "] = "×àñ âiäïðàâëåííÿ: ";
$net2ftp_messages["Sent via the net2ftp application installed on this website: "] = "Âiäïðàâëåíî ÷åðåç net2ftp ç ñàéòà ";
$net2ftp_messages["Webmaster's email: "] = "Àäðåñà Âåá-ìàéñòðà: ";
$net2ftp_messages["Message of the sender: "] = "Ïîâ³äîìëåííÿ â³äïðàâíèêó: ";
$net2ftp_messages["net2ftp is free software, released under the GNU/GPL license. For more information, go to http://www.net2ftp.com."] = "net2ftp áåçêîøòîâíå ÏÎ, ùî âèïóñêàºòüñÿ ïiä ëiöåíçiºþ GNU/GPL. Áiëüø äîêëàäíà iíôîðìàöiÿ çíàõîäèòüñÿ çà àäðåñîþ http://www.net2ftp.com.";

$net2ftp_messages["The zip file has been sent to <b>%1\$s</b>."] = "Zip-ôàéë â³äïðàâëåíèé <b>%1\$s</b>.";

// acceptFiles()
$net2ftp_messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "Ôàéë <b>%1\$s</b> çàíàäòî âåëèêèé. Ôàéë íå áóäå çàâàíòàæåíèé.";
$net2ftp_messages["File <b>%1\$s</b> is contains a banned keyword. This file will not be uploaded."] = "Ôàéë <b>%1\$s</b> ìiñòèòü çàáîðîíåíi ñëîâà. Ôàéë íå áóäå çàâàíòàæåíèé.";
$net2ftp_messages["Could not generate a temporary file."] = "Íå âäàëîñÿ çãåíåðóâàòè òèì÷àñîâèé ôàéë.";
$net2ftp_messages["File <b>%1\$s</b> could not be moved"] = "Ôàéë <b>%1\$s</b> íå ìîæå áóòè ïåðåìiùåíèé";
$net2ftp_messages["File <b>%1\$s</b> is OK"] = "Ôàéë <b>%1\$s</b> Ok";
$net2ftp_messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Íå âäàëîñÿ ïåðåìiñòèòè çàâàíòàæåíèé ôàéë â òèì÷àñîâó ïàïêó.<br /><br />Àäì³í³ñòðàòîðó ñàéòó ïîòð³áíî çì³íèòè <b>chmod</b> íà <b>777</b> ïàïêè /temp.";
$net2ftp_messages["You did not provide any file to upload."] = "Âè íå âèáðàëè ôàéë.";

// ftp_transferfiles()
$net2ftp_messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "Ôàéë <b>%1\$s</b> íå ìîæå áóòè çàâàíòàæåíèé íà FTP-ñåðâåð";
$net2ftp_messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "Ôàéë <b>%1\$s</b> áóë çàâàíòàæåíèé íà FTP-ñåðâåð, âèêîðèñòîâóþ÷è FTP-ðåæèì <b>%2\$s</b>";
$net2ftp_messages["Transferring files to the FTP server"] = "Ïåðåìiùåííÿ ôàéëiâ íà FTP-ñåðâåð";

// ftp_unziptransferfiles()
$net2ftp_messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "Ïåðåâiðêà àðõiâó nr %1\$s: <b>%2\$s</b>";
$net2ftp_messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "Àðõ³â <b>%1\$s</b> íå áóë ïåðåâ³ðåíèé, òîìó ùî ðîçøèðåííÿ ôàéëó íåïðàâèëüíî. Ò³ëüêè z³p, tar, tgz òà gz àðõ³âè ï³äòðèìóþòüñÿ.";
$net2ftp_messages["Unable to extract the files and directories from the archive"] = "Íå âäàëîñÿ âèòÿãòè ôàéëè èç àðõiâó";
$net2ftp_messages["Archive contains filenames with ../ or ..\\ - aborting the extraction"] = "²ìåíà ÿê³ àðõ³â³â ì³ñòÿòü ../ or ..\\ - íåäîïóñêàþòüñÿ. Âèòÿãóâàííÿ ïðèïèíåíî.";
$net2ftp_messages["Could not unzip entry %1\$s (error code %2\$s)"] = "Could not unzip entry %1\$s (error code %2\$s)";
$net2ftp_messages["Created directory %1\$s"] = "Ñòâîðåíà äèðåêòîðiÿ %1\$s";
$net2ftp_messages["Could not create directory %1\$s"] = "Íå âäàëîñÿ ñòâîðèòè äèðåêòîðiþ %1\$s";
$net2ftp_messages["Copied file %1\$s"] = "Çêîï³éîâàíèé ôàéë %1\$s";
$net2ftp_messages["Could not copy file %1\$s"] = "Íå âäàëîñÿ ñêîïiþâàòè ôàéë %1\$s";
$net2ftp_messages["Unable to delete the temporary directory"] = "Íå âäàëîñÿ âèäàëèòè òèì÷àñîâó äèðåêòîðiþ";
$net2ftp_messages["Unable to delete the temporary file %1\$s"] = "Íå âäàëîñÿ âèäàëèòè òèì÷àñîâèé ôàéë %1\$s";

// ftp_mysite()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>"] = "Íå âäàëîñÿ âèêîíàòè êîìàíäó <b>%1\$s</b>";

// shutdown()
$net2ftp_messages["Your task was stopped"] = "Âàøå çàâäàííÿ çóïèíåíå";
$net2ftp_messages["The task you wanted to perform with net2ftp took more time than the allowed %1\$s seconds, and therefor that task was stopped."] = "Çàâäàííÿ, ùî âè õîò³ëè ïðèïèíèòè ÷åðåç net2ftp çàéìå á³ëüøå %1\$s äîçâîëåíèõ ñåêóíä. Âèêîíàííÿ çóïèíåíå.";
$net2ftp_messages["This time limit guarantees the fair use of the web server for everyone."] = "Öå îáìåæåííÿ ÷àñó äîçâîëÿº êîðèñòóâàòèñÿ ñåðâåðîì áåç ïåðåáî¿â.";
$net2ftp_messages["Try to split your task in smaller tasks: restrict your selection of files, and omit the biggest files."] = "Ñïðîáóéòå ðîçä³ëèòè çàâäàííÿ: íàïðèêëàä, çàáîðîí³òü âèá³ð îêðåìèõ ôàéë³â.";
$net2ftp_messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "ßêùî âè ä³éñíî õî÷åòå âèêîíàòè öå çàâäàííÿ ÷åðåç net2ftp, òî âñòàíîâ³òü net2ftp íà âëàñíîìó ñåðâåð³.";

// SendMail()
$net2ftp_messages["You did not provide any text to send by email!"] = "Íåìàº òåêñòó äëÿ â³äïðàâëåííÿ ïî åëåêòðîíí³é ïîøò³!";
$net2ftp_messages["You did not supply a From address."] = "Âè íå âêàçàëè àäðåñó â³äïðàâíèêà.";
$net2ftp_messages["You did not supply a To address."] = "Âè íå âêàçàëè àäðåñó îäåðæóâà÷à.";
$net2ftp_messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "Ó çâ'ÿçêó ç òåõí³÷íèìè ïðîáëåìàìè ema³l äëÿ <b>%1\$s</b> íå ìîæå áóòè â³äïðàâëåíèé.";

// tempdir2()
$net2ftp_messages["Unable to create a temporary directory because (unvalid parent directory)"] = "Unable to create a temporary directory because (unvalid parent directory)";
$net2ftp_messages["Unable to create a temporary directory because (parent directory is not writeable)"] = "Unable to create a temporary directory because (parent directory is not writeable)";
$net2ftp_messages["Unable to create a temporary directory (too many tries)"] = "Unable to create a temporary directory (too many tries)";

// -------------------------------------------------------------------------
// /includes/logging.inc.php
// -------------------------------------------------------------------------
// logAccess(), logLogin(), logError()
$net2ftp_messages["Unable to execute the SQL query."] = "Íå âäàºòüñÿ âèêîíàòè SQL çàïèò.";
$net2ftp_messages["Unable to open the system log."] = "Íåìîæëèâî âiäêðèòè ñèñòåìíèé ëîã.";
$net2ftp_messages["Unable to write a message to the system log."] = "Íåìîæëèâî çàïèñàòè ïîâiäîìëåííÿ äî ñèñòåìíîãî ëîãó.";

// getLogStatus(), putLogStatus()
$net2ftp_messages["Table net2ftp_log_status contains duplicate entries."] = "Table net2ftp_log_status contains duplicate entries.";
$net2ftp_messages["Table net2ftp_log_status could not be updated."] = "Table net2ftp_log_status could not be updated.";

// rotateLogs()
$net2ftp_messages["The log tables were renamed successfully."] = "The log tables were renamed successfully.";
$net2ftp_messages["The log tables could not be renamed."] = "The log tables could not be renamed.";
$net2ftp_messages["The log tables were copied successfully."] = "The log tables were copied successfully.";
$net2ftp_messages["The log tables could not be copied."] = "The log tables could not be copied.";
$net2ftp_messages["The oldest log table was dropped successfully."] = "The oldest log table was dropped successfully.";
$net2ftp_messages["The oldest log table could not be dropped."] = "The oldest log table could not be dropped.";


// -------------------------------------------------------------------------
// /includes/registerglobals.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please enter your username and password for FTP server "] = "Áóäü ëàñêà, ââåäiòü Âàø ëîãií òà ïàðîëü âiä FTP ñåðâåðà";
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Âè íå çàïîëíëè ôîðìó ëîã³íó â ñïëèâàþ÷îìó â³êí³.<br />Íàòèñí³òü íà ïîñèëàííÿ \"Íà ãîëîâíó ñòîðiíêó\" íèæ÷å.";
$net2ftp_messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "Äîñòóï äî ïàíåë³ Àäìiíiñòðàòîðà net2ftp çàáëîêîâàíèé, òîìó ùî â ôàéëi settings.inc.php íå çàçíà÷åíèé ïàðîëü äëÿ âõîäó. Âñòàíîâ³òü ïàðîëü ó öüîìó ôàéë³ òà îíîâ³òü ñòîð³íêó.";
$net2ftp_messages["Please enter your Admin username and password"] = "Áóäü ëàñêà, ââåäiòü ëîãií òà ïàðîëü Àäìiíiñòðàòîðà."; 
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Âè íå çàïîëíëè ôîðìó ëîã³íó â ñïëèâàþ÷îìó â³êí³.<br />Íàòèñí³òü íà ïîñèëàííÿ \"Íà ãîëîâíó ñòîðiíêó\" íèæ÷å.";
$net2ftp_messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "Íåâ³ðíèé ëîã³í àáî ïàðîëü äëÿ âõîäó â ïàíåëü Àäìiíiñòðàòîðà net2ftp. Ëîã³í òà ïàðîëü âêàçóþòüñÿ ó ôàéë³ settings.inc.php.";


// -------------------------------------------------------------------------
// /skins/skins.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Blue"] = "Ñèíié";
$net2ftp_messages["Grey"] = "Ñiðèé";
$net2ftp_messages["Black"] = "×îðíèé";
$net2ftp_messages["Yellow"] = "Æîâòèé";
$net2ftp_messages["Pastel"] = "Ïàñòåëüíèé";

// getMime()
$net2ftp_messages["Directory"] = "Ïàïêà";
$net2ftp_messages["Symlink"] = "Ïîñèëàííÿ";
$net2ftp_messages["ASP script"] = "Ñêðèïò ASP";
$net2ftp_messages["Cascading Style Sheet"] = "CSS";
$net2ftp_messages["HTML file"] = "Ôàéë HTML";
$net2ftp_messages["Java source file"] = "Êîä Java";
$net2ftp_messages["JavaScript file"] = "Ôàéë JavaScript";
$net2ftp_messages["PHP Source"] = "PHP êîä";
$net2ftp_messages["PHP script"] = "Ñêðèïò PHP";
$net2ftp_messages["Text file"] = "Òåêñò";
$net2ftp_messages["Bitmap file"] = "Çîáðàæåííÿ";
$net2ftp_messages["GIF file"] = "GIF";
$net2ftp_messages["JPEG file"] = "JPEG";
$net2ftp_messages["PNG file"] = "PNG";
$net2ftp_messages["TIF file"] = "TIF";
$net2ftp_messages["GIMP file"] = "Ôàéë GIMP";
$net2ftp_messages["Executable"] = "Äîäàòîê";
$net2ftp_messages["Shell script"] = "Ñêðèïò shell";
$net2ftp_messages["MS Office - Word document"] = "MS Office - äîêóìåíò Word";
$net2ftp_messages["MS Office - Excel spreadsheet"] = "MS Office - òàáëèöÿ Excel";
$net2ftp_messages["MS Office - PowerPoint presentation"] = "MS Office - ïðåçåíòàöiÿ PowerPoint";
$net2ftp_messages["MS Office - Access database"] = "MS Office - ÁÄ Access";
$net2ftp_messages["MS Office - Visio drawing"] = "MS Office - ìàëþíîê Visio";
$net2ftp_messages["MS Office - Project file"] = "MS Office - ôàéë ïðîåêòà";
$net2ftp_messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - äîêóìåíò Writer 6.0";
$net2ftp_messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - øàáëîí Writer 6.0";
$net2ftp_messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - òàáëèöÿ Calc 6.0";
$net2ftp_messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - øàáëîí Calc 6.0";
$net2ftp_messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - äîêóìåíò Draw 6.0";
$net2ftp_messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - øàáëîí Draw 6.0";
$net2ftp_messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - ïðåçåíòàöiÿ Impress 6.0";
$net2ftp_messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - øàáëîí Impress 6.0";
$net2ftp_messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - äîêóìåíò Writer 6.0";
$net2ftp_messages["OpenOffice - Math 6.0 document"] = "OpenOffice - äîêóìåíò Math 6.0";
$net2ftp_messages["StarOffice - StarWriter 5.x document"] = "StarOffice - äîêóìåíò StarWriter 5.x";
$net2ftp_messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - äîêóìåíò StarWriter 5.x";
$net2ftp_messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - òàáëèöÿ StarCalc 5.x";
$net2ftp_messages["StarOffice - StarDraw 5.x document"] = "StarOffice - äîêóìåíò StarDraw 5.x";
$net2ftp_messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - ïðåçåíòàöiÿ StarImpress 5.x";
$net2ftp_messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - ôàéë StarImpress Packed 5.x";
$net2ftp_messages["StarOffice - StarMath 5.x document"] = "StarOffice - äîêóìåíò StarMath 5.x";
$net2ftp_messages["StarOffice - StarChart 5.x document"] = "StarOffice - äîêóìåíò StarChart 5.x";
$net2ftp_messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - ôàéë ïîøòè StarMail 5.x";
$net2ftp_messages["Adobe Acrobat document"] = "Äîêóìåíò Adobe Acrobat";
$net2ftp_messages["ARC archive"] = "ARC-àðõiâ";
$net2ftp_messages["ARJ archive"] = "ARJ-àðõiâ";
$net2ftp_messages["RPM"] = "RPM";
$net2ftp_messages["GZ archive"] = "GZ-àðõiâ";
$net2ftp_messages["TAR archive"] = "TAR-àðõiâ";
$net2ftp_messages["Zip archive"] = "Zip-àðõiâ";
$net2ftp_messages["MOV movie file"] = "Ôiëüì MOV";
$net2ftp_messages["MPEG movie file"] = "Ôiëüì MPEG";
$net2ftp_messages["Real movie file"] = "Ôiëüì â ôîðìàòi Real";
$net2ftp_messages["Quicktime movie file"] = "Ôiëüì Quicktime";
$net2ftp_messages["Shockwave flash file"] = "ÔàéëShockwave flash";
$net2ftp_messages["Shockwave file"] = "Ôàéë Shockwave";
$net2ftp_messages["WAV sound file"] = "Çâóê WAV";
$net2ftp_messages["Font file"] = "Ôàéë øðèôòà";
$net2ftp_messages["%1\$s File"] = "%1\$s ôàéë";
$net2ftp_messages["File"] = "Ôàéë";

// getAction()
$net2ftp_messages["Back"] = "Íàçàä";
$net2ftp_messages["Submit"] = "Âiäïðàâèòè";
$net2ftp_messages["Refresh"] = "Îíîâèòè";
$net2ftp_messages["Details"] = "Äåòàëi";
$net2ftp_messages["Icons"] = "Çíà÷êè";
$net2ftp_messages["List"] = "Ñïèñîê";
$net2ftp_messages["Logout"] = "Âèõiä";
$net2ftp_messages["Help"] = "Äîïîìîãà";
$net2ftp_messages["Bookmark"] = "Çàêëàäêà";
$net2ftp_messages["Save"] = "Çáåðåãòè";
$net2ftp_messages["Default"] = "Çà çàìîâ÷óâàííÿì";


// -------------------------------------------------------------------------
// /skins/[skin]/header.template.php and footer.template.php
// -------------------------------------------------------------------------
$net2ftp_messages["Help Guide"] = "Äîïîìîãà";
$net2ftp_messages["Forums"] = "Ôîðóìè";
$net2ftp_messages["License"] = "Ë³öåíç³ÿ";
$net2ftp_messages["Powered by"] = "Ñòâîðåíî íà";
$net2ftp_messages["You are now taken to the net2ftp forums. These forums are for net2ftp related topics only - not for generic webhosting questions."] = "Âè ñïðÿìîâàí³ íà ôîðóì net2ftp. Öåé ôîðóì ò³ëüêè äëÿ îáãîâîðåííÿ net2ftp, â³í íå ïðèçíà÷åíèé äëÿ îáãîâîðåííÿ çàãàëüíèõ îïèòóâàíü õîñòèíãó.";
$net2ftp_messages["Standard"] = "Standard";
$net2ftp_messages["Mobile"] = "Mobile";

// -------------------------------------------------------------------------
// Admin module
if ($net2ftp_globals["state"] == "admin") {
// -------------------------------------------------------------------------

// /modules/admin/admin.inc.php
$net2ftp_messages["Admin functions"] = "Ôóíêö³¿ àäì³í³ñòðàòîðà";

// /skins/[skin]/admin1.template.php
$net2ftp_messages["Version information"] = "Iíôîðìàöiÿ ïðî âåðñ³þ";
$net2ftp_messages["This version of net2ftp is up-to-date."] = "Ó Âàñ âñòàíîâëåíà îñòàííÿ âåðñ³ÿ net2ftp.";
$net2ftp_messages["The latest version information could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "Íå âäàëîñÿ îäåðæàòè ³íôîðìàö³þ ïðî îñòàííþ âåðñ³þ ç ñàéòà net2ftp.com. Ïåðåâiðòå íàëàøòóâàííÿ áåçïåêè Âàøåãî áðàóçåðà, ÿê³ ìîæóòü ïåðåøêîäæàòè çàâàíòàæåííþ íåâåëèêîãî ôàéëó ç net2ftp.com.";
$net2ftp_messages["Logging"] = "Ëîã³íóâàííÿ ";
$net2ftp_messages["Date from:"] = "Äàòà ç:";
$net2ftp_messages["to:"] = "äî:";
$net2ftp_messages["Empty logs"] = "Î÷èñòèòè ëîãè";
$net2ftp_messages["View logs"] = "Ïåðåãëÿä ëîã³â";
$net2ftp_messages["Go"] = "Âïåðåä";
$net2ftp_messages["Setup MySQL tables"] = "Íàëàøòóâàòè òàáëèö³ MySQL";
$net2ftp_messages["Create the MySQL database tables"] = "Ñòâîðèòè òàáëèö³ â áàç³ äàíèõ MySQL";

} // end admin

// -------------------------------------------------------------------------
// Admin_createtables module
if ($net2ftp_globals["state"] == "admin_createtables") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_createtables.inc.php
$net2ftp_messages["Admin functions"] = "Ôóíêö³¿ àäì³í³ñòðàòîðà";
$net2ftp_messages["The handle of file %1\$s could not be opened."] = "Íå âäàëîñÿ âiäêðèòè ïîêàæ÷èê äëÿ ôàéëà %1\$s";
$net2ftp_messages["The file %1\$s could not be opened."] = "Ôàéë %1\$s íå ìîæå áóòè â³äêðèòèé.";
$net2ftp_messages["The handle of file %1\$s could not be closed."] = "Íå âäàëîñÿ çàêðèòè ïîêàæ÷èê íà ôàéë %1\$s";
$net2ftp_messages["The connection to the server <b>%1\$s</b> could not be set up. Please check the database settings you've entered."] = "Íå âäàºòüñÿ ç'ºäíàòèñÿ ç ñåðâåðîì <b>%1\$s</b>. Áóäü ëàñêà, ïåðåâ³ðòå ââåäåí³ ïàðàìåòðè ç'ºäíàííÿ.";
$net2ftp_messages["Unable to select the database <b>%1\$s</b>."] = "Íå âäàºòüñÿ âèáðàòè áàçó äàíèõ <b>%1\$s</b>.";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> could not be executed."] = "SQL-çàïèò <b>%1\$s</b> íå ìîæå áóòè âèêîíàíèé.";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> was executed successfully."] = "SQL-çàïèò <b>%1\$s</b> áóë óñïiøíî âèêîíàíèé.";

// /skins/[skin]/admin_createtables1.template.php
$net2ftp_messages["Please enter your MySQL settings:"] = "Áóäü ëàñêà, âêàæ³òü ïàðàìåòðè ðàáîòè ç MySQL:";
$net2ftp_messages["MySQL username"] = "²ì'ÿ êîðèñòóâà÷à MySQL";
$net2ftp_messages["MySQL password"] = "Ïàðîëü MySQL";
$net2ftp_messages["MySQL database"] = "Áàçà äàíèõ MySQL";
$net2ftp_messages["MySQL server"] = "MySQL server";
$net2ftp_messages["This SQL query is going to be executed:"] = "Áóäå âèêîíàíèé íàñòóïíèé SQL-çàïèò:";
$net2ftp_messages["Execute"] = "Âèêîíàòè";

// /skins/[skin]/admin_createtables2.template.php
$net2ftp_messages["Settings used:"] = "Âèêîðèñòîâóâàí³ íàëàøòóâàííÿ:";
$net2ftp_messages["MySQL password length"] = "Äîâæèíà ïàðîëÿ MySQL";
$net2ftp_messages["Results:"] = "Ðåçóëüòàòè:";

} // end admin_createtables


// -------------------------------------------------------------------------
// Admin_viewlogs module
if ($net2ftp_globals["state"] == "admin_viewlogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_viewlogs.inc.php
$net2ftp_messages["Admin functions"] = "Ôóíêö³¿ àäì³í³ñòðàòîðà";
$net2ftp_messages["Unable to execute the SQL query <b>%1\$s</b>."] = "Íå âäàëîñÿ âèêîíàòè SQL çàïèò <b>%1\$s</b>.";
$net2ftp_messages["No data"] = "Íåìàº äàíèõ";

} // end admin_viewlogs


// -------------------------------------------------------------------------
// Admin_emptylogs module
if ($net2ftp_globals["state"] == "admin_emptylogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_emptylogs.inc.php
$net2ftp_messages["Admin functions"] = "Ôóíêö³¿ àäì³í³ñòðàòîðà";
$net2ftp_messages["The table <b>%1\$s</b> was emptied successfully."] = "Òàáëèöÿ <b>%1\$s</b> óñïiøíî î÷èùåíà.";
$net2ftp_messages["The table <b>%1\$s</b> could not be emptied."] = "Òàáëèöÿ <b>%1\$s</b> íå ìîæå áóòè î÷èùåíà.";
$net2ftp_messages["The table <b>%1\$s</b> was optimized successfully."] = "Òàáëèöÿ <b>%1\$s</b> óñïiøíî îïòèì³çîâàíà.";
$net2ftp_messages["The table <b>%1\$s</b> could not be optimized."] = "Òàáëèöÿ <b>%1\$s</b> íå ìîæå áóòè îïòèì³çîâàíà.";

} // end admin_emptylogs


// -------------------------------------------------------------------------
// Advanced module
if ($net2ftp_globals["state"] == "advanced") {
// -------------------------------------------------------------------------

// /modules/advanced/advanced.inc.php
$net2ftp_messages["Advanced functions"] = "Ðîçøèðåí³ ôóíêö³¿";

// /skins/[skin]/advanced1.template.php
$net2ftp_messages["Go"] = "Âïåðåä";
$net2ftp_messages["Disabled"] = "Â³äêëþ÷åíî";
$net2ftp_messages["Advanced FTP functions"] = "Äîäàòêîâ³ FTP ôóíêö³¿";
$net2ftp_messages["Send arbitrary FTP commands to the FTP server"] = "Â³äïðàâèòè äîâ³ëüí³ FTP êîìàíäè íà FTP ñåðâåð";
$net2ftp_messages["This function is available on PHP 5 only"] = "Öÿ ôóíêöiÿ äîñòóïíà òiëüêè ç PHP 5";
$net2ftp_messages["Troubleshooting functions"] = "Ôóíêö³¿ äëÿ óñóíåííÿ ïðîáëåì";
$net2ftp_messages["Troubleshoot net2ftp on this webserver"] = "Âèð³øåííÿ ïðîáëåì net2ftp íà öüîìó âåá-ñåðâåði";
$net2ftp_messages["Troubleshoot an FTP server"] = "Âèð³øåííÿ ïðîáëåì FTP-ñåðâåðà";
$net2ftp_messages["Test the net2ftp list parsing rules"] = "Ïåðåâ³ðèòè ïðàâèëà ðîçáîðó ñïèñêó net2ftp";
$net2ftp_messages["Translation functions"] = "Ôóíêö³¿ ïåðåêëàäó";
$net2ftp_messages["Introduction to the translation functions"] = "Ïî÷àòêîâà ³íôîðìàö³ÿ ïðî ôóíêö³ÿõ ïåðåêëàäó";
$net2ftp_messages["Extract messages to translate from code files"] = "Extract messages to translate from code files";
$net2ftp_messages["Check if there are new or obsolete messages"] = "Ïåðåâ³ðèòè íàâí³ñòü íàÿâíèõ àáî çàñòàð³ëèõ ïîâ³äîìëåíü";

$net2ftp_messages["Beta functions"] = "Áåòà-ôóíêö³¿";
$net2ftp_messages["Send a site command to the FTP server"] = "Â³äïðàâèòè êîìàíäó ñàéòó íà  FTP ñåðâåð";
$net2ftp_messages["Apache: password-protect a directory, create custom error pages"] = "Apache: çàõèñòèòè ïàïêó ïàðîëåì, ñòâîðèòè ïåðñîíàëüí³ ñòîð³íêè ïîìèëîê";
$net2ftp_messages["MySQL: execute an SQL query"] = "MySQL: âèêîíàòè SQL-çàïèò";


// advanced()
$net2ftp_messages["The site command functions are not available on this webserver."] = "Êîìàíäí³ ôóíêö³¿ öüîãî ñàéòó íåäîñòóïí³ íà âåá-ñåðâåði.";
$net2ftp_messages["The Apache functions are not available on this webserver."] = "Ôóíêö³¿ Apache íåäîñòóïí³ íà öüîìó âåá-ñåðâåði.";
$net2ftp_messages["The MySQL functions are not available on this webserver."] = "Ôóíêö³¿ MySQL íåäîñòóïí³ íà öüîìó âåá-ñåðâåði.";
$net2ftp_messages["Unexpected state2 string. Exiting."] = "Íåñïîä³âàíèé çì³ñò ðÿäêà 2. Çàâåðøåííÿ.";

} // end advanced


// -------------------------------------------------------------------------
// Advanced_ftpserver module
if ($net2ftp_globals["state"] == "advanced_ftpserver") {
// -------------------------------------------------------------------------

// /modules/advanced_ftpserver/advanced_ftpserver.inc.php
$net2ftp_messages["Troubleshoot an FTP server"] = "Âèð³øåííÿ ïðîáëåì FTP-ñåðâåðà";

// /skins/[skin]/advanced_ftpserver1.template.php
$net2ftp_messages["Connection settings:"] = "Ïàðàìåòðè ç'ºäíàííÿ:";
$net2ftp_messages["FTP server"] = "FTP-ñåðâåð";
$net2ftp_messages["FTP server port"] = "Ïîðò FTP-ñåðâåðà";
$net2ftp_messages["Username"] = "Ëîãií";
$net2ftp_messages["Password"] = "Ïàðîëü";
$net2ftp_messages["Password length"] = "Äîâæèíà ïàðîëÿ";
$net2ftp_messages["Passive mode"] = "Ïàñèâíèé ðåæèì";
$net2ftp_messages["Directory"] = "Ïàïêà";
$net2ftp_messages["Printing the result"] = "Printing the result";

// /skins/[skin]/advanced_ftpserver2.template.php
$net2ftp_messages["Connecting to the FTP server: "] = "Ç'ºäíàííÿ ç FTP-ñåðâåðîì: ";
$net2ftp_messages["Logging into the FTP server: "] = "Âõiä íà FTP-ñåðâåð: ";
$net2ftp_messages["Setting the passive mode: "] = "Ïåðåõ³ä íà ïàñèâíèé ðåæèì: ";
$net2ftp_messages["Getting the FTP server system type: "] = "Âèçíà÷àºòüñÿ òèï ñèñòåìè FTP-ñåðâåðà: ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "Ïåðåõ³ä â ïàïêó %1\$s: ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "Ïàïêà FTP-ñåðâåðà: %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "Îòðèìàííÿ ñïèñêó ïàïîê òà ôàéëiâ: ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "Ïîâòîðíà ñïðîáà îäåðæàííÿ ñïèñêà: ";
$net2ftp_messages["Closing the connection: "] = "Çàêðèòòÿ ç'ºäíàííÿ: ";
$net2ftp_messages["Raw list of directories and files:"] = "Ñïèñîê ïàïîê òà ôàéëiâ:";
$net2ftp_messages["Parsed list of directories and files:"] = "Îáðîáëåíèé ñïèñîê ïàïîê òà ôàéëiâ:";

$net2ftp_messages["OK"] = "OK";
$net2ftp_messages["not OK"] = "íå OK";

} // end advanced_ftpserver


// -------------------------------------------------------------------------
// Advanced_parsing module
if ($net2ftp_globals["state"] == "advanced_parsing") {
// -------------------------------------------------------------------------

$net2ftp_messages["Test the net2ftp list parsing rules"] = "Ïåðåâ³ðèòè ïðàâèëà ðîçáîðó ñïèñêó net2ftp";
$net2ftp_messages["Sample input"] = "Ïðèêëàä âõ³äíèõ äàíèõ";
$net2ftp_messages["Parsed output"] = "Îáðîáëåí³ âõ³äí³ äàí³";

} // end advanced_parsing


// -------------------------------------------------------------------------
// Advanced_webserver module
if ($net2ftp_globals["state"] == "advanced_webserver") {
// -------------------------------------------------------------------------

$net2ftp_messages["Troubleshoot your net2ftp installation"] = "Âèð³øåííÿ ïðîáëåì âñòàíîâëåííÿ net2ftp";
$net2ftp_messages["Printing the result"] = "Printing the result";

$net2ftp_messages["Checking if the FTP module of PHP is installed: "] = "Ïåðåâiðêà âñòàíîâëåííÿ ìîäóëÿ FTP âiä PHP: ";
$net2ftp_messages["yes"] = "òàê";
$net2ftp_messages["no - please install it!"] = "í³ - áóäü ëàñêà, âñòàíîâ³òü éîãî!";

$net2ftp_messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "Ïåðåâ³ðêà äîçâîë³â ïàïêè íà âåá-ñåðâåð³: íåâåëèêèé ôàéë ìîæå áóòè çàïèñàíèé ó ïàïêó /temp òà ïîò³ì âèäàëåíèé.";
$net2ftp_messages["Creating filename: "] = "²ì'ÿ ôàéëà äëÿ ñòâîðåííÿ: ";
$net2ftp_messages["OK. Filename: %1\$s"] = "OK. ²ì'ÿ ôàéëà: %1\$s";
$net2ftp_messages["not OK"] = "íå OK";
$net2ftp_messages["OK"] = "OK";
$net2ftp_messages["not OK. Check the permissions of the %1\$s directory"] = "íå OK. Ïåðåâiðòå äîçâîëè ïàïêè %1\$s";
$net2ftp_messages["Opening the file in write mode: "] = "Â³äêðèòòÿ ôàéëà â ðåæèì³ äëÿ çàïèñó: ";
$net2ftp_messages["Writing some text to the file: "] = "Çàïèñ òåêñòó â ôàéë: ";
$net2ftp_messages["Closing the file: "] = "Çàêðèòòÿ ôàéëó: ";
$net2ftp_messages["Deleting the file: "] = "Âèäàëåííÿ ôàéëó: ";

$net2ftp_messages["Testing the FTP functions"] = "Òåñòóâàííÿ ôóíêö³é FTP";
$net2ftp_messages["Connecting to a test FTP server: "] = "Ï³äêëþ÷åííÿ äî òåñòîâîãî FTP ñåðâåðó: ";
$net2ftp_messages["Connecting to the FTP server: "] = "Ç'ºäíàííÿ ç FTP-ñåðâåðîì: ";
$net2ftp_messages["Logging into the FTP server: "] = "Âõiä íà FTP-ñåðâåð: ";
$net2ftp_messages["Setting the passive mode: "] = "Ïåðåõ³ä íà ïàñèâíèé ðåæèì: ";
$net2ftp_messages["Getting the FTP server system type: "] = "Âèçíà÷àºòüñÿ òèï ñèñòåìè FTP-ñåðâåðà: ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "Ïåðåõ³ä â ïàïêó %1\$s: ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "Ïàïêà FTP-ñåðâåðà: %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "Îòðèìàííÿ ñïèñêó ïàïîê òà ôàéëiâ: ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "Ïîâòîðíà ñïðîáà îäåðæàííÿ ñïèñêà: ";
$net2ftp_messages["Closing the connection: "] = "Çàêðèòòÿ ç'ºäíàííÿ: ";
$net2ftp_messages["Raw list of directories and files:"] = "Ñïèñîê ïàïîê òà ôàéëiâ:";
$net2ftp_messages["Parsed list of directories and files:"] = "Îáðîáëåíèé ñïèñîê ïàïîê òà ôàéëiâ:";
$net2ftp_messages["OK"] = "OK";
$net2ftp_messages["not OK"] = "íå OK";

} // end advanced_webserver


// -------------------------------------------------------------------------
// Bookmark module
if ($net2ftp_globals["state"] == "bookmark") {
// -------------------------------------------------------------------------

$net2ftp_messages["Drag and drop one of the links below to the bookmarks bar"] = "Drag and drop one of the links below to the bookmarks bar";
$net2ftp_messages["Right-click on one of the links below and choose \"Add to Favorites...\""] = "Right-click on one of the links below and choose \"Add to Favorites...\"";
$net2ftp_messages["Right-click on one the links below and choose \"Add Link to Bookmarks...\""] = "Right-click on one the links below and choose \"Add Link to Bookmarks...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark link...\""] = "Right-click on one of the links below and choose \"Bookmark link...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark This Link...\""] = "Right-click on one of the links below and choose \"Bookmark This Link...\"";
$net2ftp_messages["One click access (net2ftp won't ask for a password - less safe)"] = "One click access (net2ftp won't ask for a password - less safe)";
$net2ftp_messages["Two click access (net2ftp will ask for a password - safer)"] = "Two click access (net2ftp will ask for a password - safer)";
$net2ftp_messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] = "Ïðèì³òêà: êîëè Âè áóäåòå âèêîðèñòîâóâàòè çàêëàäêó, ñïëèâàþ÷å â³êíî çàïèòàº ó Âàñ ³ì'ÿ òà ïàðîëü.";

} // end bookmark


// -------------------------------------------------------------------------
// Browse module
if ($net2ftp_globals["state"] == "browse") {
// -------------------------------------------------------------------------

// /modules/browse/browse.inc.php
$net2ftp_messages["Choose a directory"] = "Âèáåðiòü ïàïêó";
$net2ftp_messages["Please wait..."] = "Áóäü ëàñêà, çà÷åêàéòå...";

// browse()
$net2ftp_messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "Ïàïêè ç ³ìåíàìè, ùî ì³ñòÿòü \' íå ìîæóòü êîðåêòíî â³äîáðàæàòèñÿ. ¯õ ìîæíà ò³ëüêè âèäàëèòè. Áóäü ëàñêà, ïîâåðí³òüñÿ òà âèáåð³òü ³íøó ïàïêó.";

$net2ftp_messages["Daily limit reached: you will not be able to transfer data"] = "Äîñÿãíóòü äîáîâèé ë³ì³ò: Âè íå ìîæåòå á³ëüøå ïåðåäàâàòè äàí³";
$net2ftp_messages["In order to guarantee the fair use of the web server for everyone, the data transfer volume and script execution time are limited per user, and per day. Once this limit is reached, you can still browse the FTP server but not transfer data to/from it."] = "Ùîá ãàðàíòóâàòè ð³âíó äîñòóïí³ñòü öüîãî ñåðâåðà äëÿ êîæíîãî êîðèñòóâà÷à, íàêëàäàºòüñÿ îáìåæåííÿ íà îáñÿã ïåðåäàíèõ äàíèõ òà ÷àñ âèêîíàííÿ ñêðèïò³â äëÿ êîðèñòóâà÷à â äåíü. ßê ò³ëüêè öåé ë³ì³ò ïåðåâèùåíèé, Âè ìîæåòå ïåðåãëÿäàòè ïàïêè, àëå íå ìîæåòå çàâàíòàæóâàòè ôàéëè.";
$net2ftp_messages["If you need unlimited usage, please install net2ftp on your own web server."] = "ßêùî Âàì íåîáõ³äí³ íåîáìåæåí³ ðåñóðñè, áóäü ëàñêà âñòàíîâ³òü net2ftp íà Âàø âëàñíèé ftp ñåðâåð.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$net2ftp_messages["New dir"] = "Íîâà ïàïêà";
$net2ftp_messages["New file"] = "Íîâèé ôàéë";
$net2ftp_messages["HTML templates"] = "HTML templates";
$net2ftp_messages["Upload"] = "Çàâàíòàæèòè íà ñåðâ";
$net2ftp_messages["Java Upload"] = "Çàâàíòàæèòè Java";
$net2ftp_messages["Flash Upload"] = "Çàâàíòàæèòè Flash";
$net2ftp_messages["Install"] = "Âñòàíîâèòè";
$net2ftp_messages["Advanced"] = "Îïö³¿";
$net2ftp_messages["Copy"] = "Êîï³ð.";
$net2ftp_messages["Move"] = "Ïåðåì³ñò.";
$net2ftp_messages["Delete"] = "Âèäàëèòè";
$net2ftp_messages["Rename"] = "Ïåðåéì.";
$net2ftp_messages["Chmod"] = "Chmod";
$net2ftp_messages["Download"] = "Çàâàíòàæèòè íà êîìï";
$net2ftp_messages["Unzip"] = "Ðîçïàêóâàòè";
$net2ftp_messages["Zip"] = "Àðõ³âóâàòè";
$net2ftp_messages["Size"] = "Ðîçì³ð";
$net2ftp_messages["Search"] = "Ïîøóê";
$net2ftp_messages["Go to the parent directory"] = "Ïåðåéòè íà óðîâåíü âèùå";
$net2ftp_messages["Go"] = "Âïåðåä";
$net2ftp_messages["Transform selected entries: "] = "Ïåðåòâîðèòè âèáðàíîãî: ";
$net2ftp_messages["Transform selected entry: "] = "Ïåðåòâîðèòè âèáðàíîãî: ";
$net2ftp_messages["Make a new subdirectory in directory %1\$s"] = "Ñòâîðèòè ï³äïàïêó â ïàïö³ %1\$s";
$net2ftp_messages["Create a new file in directory %1\$s"] = "Ñòâîðèòè ôàéë â ïàïö³ %1\$s";
$net2ftp_messages["Create a website easily using ready-made templates"] = "Ñòâîðèòè ñàéò  âèêîðèñòîâóþ÷è ãîòîâ³ øàáëîíè";
$net2ftp_messages["Upload new files in directory %1\$s"] = "Çàâàíòàæèòè íîâi ôàéëè â ïàïêó %1\$s";
$net2ftp_messages["Upload directories and files using a Java applet"] = "Çàâàíòàæèòè ôàéëè òà äèðåêòîði¿ âèêîðèñòîâóþ÷è Java àïïëåò";
$net2ftp_messages["Upload files using a Flash applet"] = "Çàâàíòàæèòè ôàéëè íà ñåðâåð, âèêîðèñòîâóþ÷è Flash àïïëåò";
$net2ftp_messages["Install software packages (requires PHP on web server)"] = "Âñòàíîâèòè ïàêåòè (âèìàãàº íàÿâíîñò³ PHP íà âåá-ñåðâåði)";
$net2ftp_messages["Go to the advanced functions"] = "Ïåðåéòè â äîä. ôóíêö³¿";
$net2ftp_messages["Copy the selected entries"] = "Êîï³þâàòè âèáðàíi ïàïêè";
$net2ftp_messages["Move the selected entries"] = "Ïåðåì³ñòèòè âèáðàíi ïàïêè";
$net2ftp_messages["Delete the selected entries"] = "Âèäàëèòè âèáðàíi ïàïêè";
$net2ftp_messages["Rename the selected entries"] = "Ïåðåéìåíóâàòè âèáðàíîãî";
$net2ftp_messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "Chmod âèáðàíîãî (ðàáîòàåò íà Unix/Linux/BSD ñåðâåðàõ)";
$net2ftp_messages["Download a zip file containing all selected entries"] = "Çàâàíòàæèòè íà êîìï zip-ôàéë, ÿê³é ì³ñòèòü âèáðàíi ôàéëè";
$net2ftp_messages["Unzip the selected archives on the FTP server"] = "Ðîçïàêóâàòè âèáðàíi àðõ³âè íà FTP ñåðâåð";
$net2ftp_messages["Zip the selected entries to save or email them"] = "Ñòèñíóòè âèáðàíîãî òà â³äïðàâèòè ïî email";
$net2ftp_messages["Calculate the size of the selected entries"] = "Îá÷èñëèòè ðîçì³ð âèáðàííîãî";
$net2ftp_messages["Find files which contain a particular word"] = "Çíàéòè ôàéëè, ùî ì³ñòÿòü ÷àñòèíó ñëîâà";
$net2ftp_messages["Click to sort by %1\$s in descending order"] = "Íàòèñí³òü äëÿ ñîðòóâàííÿ %1\$s ó ïîðÿäêó çðîñòàííÿ";
$net2ftp_messages["Click to sort by %1\$s in ascending order"] = "Íàòèñí³òü äëÿ ñîðòóâàííÿ %1\$s ó ïîðÿäêó óáóâàííÿ";
$net2ftp_messages["Ascending order"] = "Óáóâàííÿ";
$net2ftp_messages["Descending order"] = "Çðîñòàííÿ";
$net2ftp_messages["Upload files"] = "Çàâàíòàæèòè ôàéëè íà ñåðâåð";
$net2ftp_messages["Up"] = "Íàãîðó";
$net2ftp_messages["Click to check or uncheck all rows"] = "Íàòèñí³òü äëÿ âèáîðó àáî ñêàñóâàííÿ âèáîðó âñ³õ";
$net2ftp_messages["All"] = "Âñi";
$net2ftp_messages["Name"] = "²ì'ÿ";
$net2ftp_messages["Type"] = "Òèï";
//$net2ftp_messages["Size"] = "Size";
$net2ftp_messages["Owner"] = "Êîðèñòóâà÷";
$net2ftp_messages["Group"] = "Ãðóïà";
$net2ftp_messages["Perms"] = "Äîçâîëè";
$net2ftp_messages["Mod Time"] = "×àñ";
$net2ftp_messages["Actions"] = "Ä³¿";
$net2ftp_messages["Select the directory %1\$s"] = "Âèáðàòè äèðåêòîðiþ %1\$s";
$net2ftp_messages["Select the file %1\$s"] = "Âèáðàòè ôàéë %1\$s";
$net2ftp_messages["Select the symlink %1\$s"] = "Âèáðàòè symlink %1\$s";
$net2ftp_messages["Go to the subdirectory %1\$s"] = "Ïåðåéòè â ï³ääèðåêòîð³þ %1\$s";
$net2ftp_messages["Download the file %1\$s"] = "Çàâàíòàæèòè íà êîìï ôàéë%1\$s";
$net2ftp_messages["Follow symlink %1\$s"] = "Ñë³äóâàòè symlink'ó %1\$s";
$net2ftp_messages["View"] = "Ïîêàç.";
$net2ftp_messages["Edit"] = "Ðåäàêò.";
$net2ftp_messages["Update"] = "Îíîâèòè";
$net2ftp_messages["Open"] = "Â³äêðèòè";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "Ïåðåãëÿíóòè âèõ³äíèé êîä %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "Ðåäàãóâàòè âèõ³äíèé êîä ôàéëà %1\$s";
$net2ftp_messages["Upload a new version of the file %1\$s and merge the changes"] = "Çàâàíòàæèòè íîâó âåðñ³þ ôàéëà 1\$s òà çàñòîñóâàòè çì³íè";
$net2ftp_messages["View image %1\$s"] = "Ïåðåãëÿíóòè ìàëþíîê %1\$s";
$net2ftp_messages["View the file %1\$s from your HTTP web server"] = "Ïåðåãëÿíóòè ôàéë %1\$s ç âàøîãî HTTP-ñåðâåðà";
$net2ftp_messages["(Note: This link may not work if you don't have your own domain name.)"] = "(Ïðèì³òêà: Ïîñèëàííÿ ìîæå íå ïðàöþâàòè, ÿêùî ó âàñ íåìàº äîìåííîãî ³ìåí³.)";
$net2ftp_messages["This folder is empty"] = "Ïàïêà ïóñòà";

// printSeparatorRow()
$net2ftp_messages["Directories"] = "Ïàïêè";
$net2ftp_messages["Files"] = "Ôàéëè";
$net2ftp_messages["Symlinks"] = "Ïîñèëàííÿ";
$net2ftp_messages["Unrecognized FTP output"] = "Íåâ³äîìèé âèõ³ä FTP";
$net2ftp_messages["Number"] = "Íîìåð";
$net2ftp_messages["Size"] = "Ðîçì³ð";
$net2ftp_messages["Skipped"] = "Ïðîïóùåíî";
$net2ftp_messages["Data transferred from this IP address today"] = "Îá'ºì äàíèõ, ïåðåäàíèé ç ö³º¿ ²P àäðåñè çà ñüîãîäí³";
$net2ftp_messages["Data transferred to this FTP server today"] = "Îá'ºì äàíèõ ïåðåäàíèõ öüîìó FTP ñåðâåðîâ³ ñüîãîäí³";

// printLocationActions()
$net2ftp_messages["Language:"] = "Ìîâà:";
$net2ftp_messages["Skin:"] = "Òåìà:";
$net2ftp_messages["View mode:"] = "Ðåæèì ïåðåãëÿäó:";
$net2ftp_messages["Directory Tree"] = "Äåðåâî ïàïîê";

// ftp2http()
$net2ftp_messages["Execute %1\$s in a new window"] = "Âèêîíàòè %1\$s â íîâîìó âiêíi";
$net2ftp_messages["This file is not accessible from the web"] = "Öåé ôàéë íå äîñòóïíèé ç web-³íòåðôåéñó";

// printDirectorySelect()
$net2ftp_messages["Double-click to go to a subdirectory:"] = "Íàòèñí³òü äâ³÷³ äëÿ ïåðåõîäó â ï³äïàïêó:";
$net2ftp_messages["Choose"] = "Âèá³ð";
$net2ftp_messages["Up"] = "Íàãîðó";

} // end browse


// -------------------------------------------------------------------------
// Calculate size module
if ($net2ftp_globals["state"] == "calculatesize") {
// -------------------------------------------------------------------------
$net2ftp_messages["Size of selected directories and files"] = "Ðîçì³ð âèáðàíèõ ïàïîê òà ôàéëiâ";
$net2ftp_messages["The total size taken by the selected directories and files is:"] = "Çàãàëüíèé ðîçì³ð ôàéëiâ òà ïàïîê:";
$net2ftp_messages["The number of files which were skipped is:"] = "Ê³ëüê³ñòü ôàéëiâ, ÿê³ áóëè ïðîïóùåí³:";

} // end calculatesize


// -------------------------------------------------------------------------
// Chmod module
if ($net2ftp_globals["state"] == "chmod") {
// -------------------------------------------------------------------------
$net2ftp_messages["Chmod directories and files"] = "Chmod íà ïàïêè òà ôàéëè";
$net2ftp_messages["Set all permissions"] = "Çì³íèòè âñ³ ïðàâà";
$net2ftp_messages["Read"] = "×èòàííÿ";
$net2ftp_messages["Write"] = "Çàïèñ";
$net2ftp_messages["Execute"] = "Âèêîíàòè";
$net2ftp_messages["Owner"] = "Êîðèñòóâà÷";
$net2ftp_messages["Group"] = "Ãðóïà";
$net2ftp_messages["Everyone"] = "Âñi";
$net2ftp_messages["To set all permissions to the same values, enter those permissions and click on the button \"Set all permissions\""] = "Äëÿ âèáîðó îäíàêîâèõ äîçâîë³â, ââåä³òü ¿õíº çíà÷åííÿ íèæ÷å òà íàòèñí³òü íà êíîïêó \"Âèáðàòè äîçâîëè\"";
$net2ftp_messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Âèáðàòè äîçâîëè äëÿ ïàïêè <b>%1\$s</b>: ";
$net2ftp_messages["Set the permissions of file <b>%1\$s</b> to: "] = "Âèáðàòè äîçâîëè äëÿ ôàéëà <b>%1\$s</b>: ";
$net2ftp_messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Âèáðàòè äîçâîëè äëÿ ñ³ìë³íêà <b>%1\$s</b>: ";
$net2ftp_messages["Chmod value"] = "Çíà÷åííÿ Chmod";
$net2ftp_messages["Chmod also the subdirectories within this directory"] = "Chmod òàêîæ íà ï³äïàïêè âñåðåäèí³ ö³º¿ ïàïêè";
$net2ftp_messages["Chmod also the files within this directory"] = "Chmod òàêîæ íà ôàéëè âñåðåäèí³ ö³º¿ ïàïêè";
$net2ftp_messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "Chmod <b>%1\$s</b> âèõîäèòü ç ä³àïàçîíó 000-777. Ñïðîáóéòå ùå ðàç.";

} // end chmod


// -------------------------------------------------------------------------
// Clear cookies module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// Copy/Move/Delete module
if ($net2ftp_globals["state"] == "copymovedelete") {
// -------------------------------------------------------------------------
$net2ftp_messages["Choose a directory"] = "Âèáåðiòü ïàïêó";
$net2ftp_messages["Copy directories and files"] = "Êîï³þâàòè ïàïêè òà ôàéëè";
$net2ftp_messages["Move directories and files"] = "Ïåðåì³ñòèòè ïàïêè òà ôàéëè";
$net2ftp_messages["Delete directories and files"] = "Âèäàëèòè ïàïêè òà ôàéëè";
$net2ftp_messages["Are you sure you want to delete these directories and files?"] = "Âè ä³éñíî áàæàºòå âèäàëèòè ö³ ôàéëè òà ïàïêè?";
$net2ftp_messages["All the subdirectories and files of the selected directories will also be deleted!"] = "Âñi ï³äïàïêè òà ôàéëè â çàçíà÷åíèõ ïàïêàõ áóäóò âèäàëåí³!";
$net2ftp_messages["Set all targetdirectories"] = "Âèáðàòè âñ³ ïàïêè";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Ùîá çàäàòè ãîëîâíó ïàïêó, ââåä³òü ¿¿ íàçâó â ïîëå âèùå òà âèáåð³òü ïóíêò \"Âèáðàòè âñ³ ïàïêè\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "Ïðèì³òêà: ïàïêà ïîâèííà âæå ³ñíóâàòè.";
$net2ftp_messages["Different target FTP server:"] = "²íøèé FTP-ñåðâåð:";
$net2ftp_messages["Username"] = "Ëîãií";
$net2ftp_messages["Password"] = "Ïàðîëü";
$net2ftp_messages["Leave empty if you want to copy the files to the same FTP server."] = "Çàëèø³òü ïîðîæí³ì, ÿêùî âè áàæàºòå ñêîï³þâàòè ôàéëè â òó æ ïàïêó FTP-ñåðâåðà.";
$net2ftp_messages["If you want to copy the files to another FTP server, enter your login data."] = "ßêùî âè áàæàºòå â³äêðèòè ôàéëè íà ³íøîìó FTP-ñåðâåð³, òî ââåä³òü äàí³ äëÿ âõîäó.";
$net2ftp_messages["Leave empty if you want to move the files to the same FTP server."] = "Çàëèø³òü ïîðîæí³ì, ÿêùî âè áàæàºòå ïåðåì³ñòèòè ôàéëè â òó æ ïàïêó FTP-ñåðâåðà.";
$net2ftp_messages["If you want to move the files to another FTP server, enter your login data."] = "ßêùî âè áàæàºòå ïåðåì³ñòèòè ôàéëè íà ³íøèé FTP-ñåðâåð, óâåä³òü äàí³ äëÿ âõîäó.";
$net2ftp_messages["Copy directory <b>%1\$s</b> to:"] = "Êîï³þâàòè ïàïêó <b>%1\$s</b> â:";
$net2ftp_messages["Move directory <b>%1\$s</b> to:"] = "Ïåðåì³ñòèòè ïàïêó <b>%1\$s</b> â:";
$net2ftp_messages["Directory <b>%1\$s</b>"] = "Ïàïêà <b>%1\$s</b>";
$net2ftp_messages["Copy file <b>%1\$s</b> to:"] = "Êîï³þâàòè ôàéë <b>%1\$s</b> â:";
$net2ftp_messages["Move file <b>%1\$s</b> to:"] = "Ïåðåì³ñòèòè ôàéë <b>%1\$s</b> â:";
$net2ftp_messages["File <b>%1\$s</b>"] = "Ôàéë <b>%1\$s</b>";
$net2ftp_messages["Copy symlink <b>%1\$s</b> to:"] = "Êîï³þâàòè ñèìëèíê <b>%1\$s</b> â:";
$net2ftp_messages["Move symlink <b>%1\$s</b> to:"] = "Ïåðåì³ñòèòè ñèìëèíê <b>%1\$s</b> â:";
$net2ftp_messages["Symlink <b>%1\$s</b>"] = "Ñ³ìë³íê <b>%1\$s</b>";
$net2ftp_messages["Target directory:"] = "Ïàïêà ïðèçíà÷åííÿ:";
$net2ftp_messages["Target name:"] = "²ì'ÿ ïðèçíà÷åííÿ:";
$net2ftp_messages["Processing the entries:"] = "Ïåðåãëÿä âì³ñòó:";

} // end copymovedelete


// -------------------------------------------------------------------------
// Download file module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// EasyWebsite module
if ($net2ftp_globals["state"] == "easyWebsite") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create a website in 4 easy steps"] = "Cîçäàéòå ñàéò çà 4 êðîêè";
$net2ftp_messages["Template overview"] = "Ïåðåãëÿä ùàáëîíó";
$net2ftp_messages["Template details"] = "Äåòàëi øàáëîíà";
$net2ftp_messages["Files are copied"] = "Ñêîï³éîâàí³ ôàéëè";
$net2ftp_messages["Edit your pages"] = "Ðåäàãóâàòè ñòîð³íêè";

// Screen 1 - printTemplateOverview
$net2ftp_messages["Click on the image to view the details of a template."] = "Íàòèñí³òü íà çîáðàæåííÿ ùîá ïîäèâèòèñÿ ïîäðîáèö³ ïðî øàáëîí.";
$net2ftp_messages["Back to the Browse screen"] = "Íàçàä, äî ñòîð³íêè ïåðåãëÿäó";
$net2ftp_messages["Template"] = "Øàáëîí";
$net2ftp_messages["Copyright"] = "Àâòîðñüêå ïðàâî";
$net2ftp_messages["Click on the image to view the details of this template"] = "Íàòèñí³òü íà çîáðàæåííÿ ùîá ïîäèâèòèñÿ ïîäðîáèö³ ïðî øàáëîí";

// Screen 2 - printTemplateDetails
$net2ftp_messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "Ôàéëè øàáëîíà áóäóòü ñêîï³éîâàí³ íà Âàø FTP-ñåðâåð. ²ñíóþ÷³ ôàéëè ç òàêèìè æ ³ìåíàìè áóäóòü çàì³íåí³ íîâèìè.  ×è õî÷åòå Âè ïðîäîâæèòè?";
$net2ftp_messages["Install template to directory: "] = "Âñòàíîâèòè øàáëîí â äèðåêòîðiþ: ";
$net2ftp_messages["Install"] = "Âñòàíîâèòè";
$net2ftp_messages["Size"] = "Ðîçì³ð";
$net2ftp_messages["Preview page"] = "Ïåðåãëÿä ñòîð³íêè";
$net2ftp_messages["opens in a new window"] = "â³äêðèºòüñÿ â íîâîìó â³êí³";

// Screen 3
$net2ftp_messages["Please wait while the template files are being transferred to your server: "] = "Áóäü ëàñêà, äî÷åêàéòåñÿ çàê³í÷åííÿ ïåðåíîñó ôàéë³â íà ñåðâåð: ";
$net2ftp_messages["Done."] = "Çàâåðøåíî.";
$net2ftp_messages["Continue"] = "Ïðîäîâæèòè";

// Screen 4 - printEasyAdminPanel
$net2ftp_messages["Edit page"] = "Ðåäàãóâàííÿ";
$net2ftp_messages["Browse the FTP server"] = "Ïåðåãëÿä  FTP ñåðâåðà";
$net2ftp_messages["Add this link to your favorites to return to this page later on!"] = "Äîäàéòå öå ïîñèëàííÿ â çàêëàäêè ùîá ïîâåðíóòèñÿ ñþäè ï³çí³øå!";
$net2ftp_messages["Edit website at %1\$s"] = "Ðåäàãóâàòè ñàéò %1\$s";
$net2ftp_messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: êëàöí³òü ïðàâîþ êíîïêîþ íà ïîñèëàíí³ òà âèáåð³òü \"Äîäàòè â Îáðàíå...\"";
$net2ftp_messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: êëàöí³òü ïðàâîþ êíîïêîþ íà ïîñèëàííÿ òà âèáåð³òü \"Bookmark This Link...\"";

// ftp_copy_local2ftp
$net2ftp_messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "ÓÂÀÃÀ: íåìîæëèâî ñòâîðèòè ï³äïàïêó <b>%1\$s</b>. Ìîæëèâî, âîíà âæå iñíóº. Ïðîäîâæåííÿ...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "Ñòâîðåíî ïiäïàïêó <b>%1\$s</b>";
$net2ftp_messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "ÓÂÀÃÀ: íå âäàëîñÿ ñêîïiþâàòè ôàéë <b>%1\$s</b>. Ïðîäîâæåííÿ...";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "Copied file <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// Edit module
if ($net2ftp_globals["state"] == "edit") {
// -------------------------------------------------------------------------

// /modules/edit/edit.inc.php
$net2ftp_messages["Unable to open the template file"] = "Íå âäàëîñÿ âiäêðèòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["Unable to read the template file"] = "Íå âäàëîñÿ ïðî÷èòàòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["Please specify a filename"] = "Âêàæ³òü iì'ÿ ôàéëà";
$net2ftp_messages["Status: This file has not yet been saved"] = "Ñòàí: ôàéë íå çáåðåæåíèé";
$net2ftp_messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Ñòàí: çáåðåæåíî â <b>%1\$s</b> â ðåæèì³ %2\$s";
$net2ftp_messages["Status: <b>This file could not be saved</b>"] = "Ñòàí: <b>öåé ôàéë íå ìîæå áóòè çáåðåæåíèé</b>";
$net2ftp_messages["Not yet saved"] = "Not yet saved";
$net2ftp_messages["Could not be saved"] = "Could not be saved";
$net2ftp_messages["Saved at %1\$s"] = "Saved at %1\$s";

// /skins/[skin]/edit.template.php
$net2ftp_messages["Directory: "] = "Ïàïêà: ";
$net2ftp_messages["File: "] = "Ôàéë: ";
$net2ftp_messages["New file name: "] = "Íîâå iì'ÿ ôàéëà: ";
$net2ftp_messages["Character encoding: "] = "Êîäóâàííÿ ñèìâîë³â: ";
$net2ftp_messages["Note: changing the textarea type will save the changes"] = "Ïðèì³òêà: çì³íà òåêñòó çáåðåæå çì³íè";
$net2ftp_messages["Copy up"] = "Ñêîï³þâàòè íàãîðó";
$net2ftp_messages["Copy down"] = "Ñêîï³þâàòè âíèç";

} // end if edit


// -------------------------------------------------------------------------
// Find string module
if ($net2ftp_globals["state"] == "findstring") {
// -------------------------------------------------------------------------

// /modules/findstring/findstring.inc.php 
$net2ftp_messages["Search directories and files"] = "Ïîøóê ïàïîê òà ôàéëiâ";
$net2ftp_messages["Search again"] = "Øóêàòè çíîâó";
$net2ftp_messages["Search results"] = "Ðåçóëüòàòè ïîøóêó";
$net2ftp_messages["Please enter a valid search word or phrase."] = "Ââåä³òü ïðàâèëüíå ñëîâî àáî ôðàçó.";
$net2ftp_messages["Please enter a valid filename."] = "Ââåä³òü ïðàâèëüíå iì'ÿ ôàéëó.";
$net2ftp_messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Áóäü ëàñêà, ââåäiòü ïðàâèëüíó íàçâó â ïîëå \"èç\", íàïðèêëàä, 0.";
$net2ftp_messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Áóäü ëàñêà, ââåäiòü ïðàâèëüíèé ðîçì³ð â ïîëå \"â\", íàïðèêëàä, 500000.";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Áóäü ëàñêà, ââåäiòü ïðàâèëüíó äàòó â ôîðìàòi ã-ì-ä â ïîëå \"èç\".";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Áóäü ëàñêà, ââåäiòü ïðàâèëüíó äàòó â ôîðìàòi ã-ì-ä â ïîëå \"â\".";
$net2ftp_messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "Ñëîâî <b>%1\$s</b> íå áóëî çíàéäåíî.";
$net2ftp_messages["The word <b>%1\$s</b> was found in the following files:"] = "Ñëîâî <b>%1\$s</b> áóëî çíàéäåíî â íàñòóïíèõ ôðàçàõ:";

// /skins/[skin]/findstring1.template.php
$net2ftp_messages["Search for a word or phrase"] = "Ïîøóê ñëîâà àáî ôðàçè";
$net2ftp_messages["Case sensitive search"] = "Â³ä÷óòíî äî ðåã³ñòðó";
$net2ftp_messages["Restrict the search to:"] = "Çàáîðîíèòè ïîøóê:";
$net2ftp_messages["files with a filename like"] = "iì'ÿ ôàéëà ÿê";
$net2ftp_messages["(wildcard character is *)"] = "(ñèìâîë *)";
$net2ftp_messages["files with a size"] = "ôàéëè ç ðîçì³ðîì";
$net2ftp_messages["files which were last modified"] = "ôàéëè, çì³íåí³";
$net2ftp_messages["from"] = "âiä";
$net2ftp_messages["to"] = "äî";

$net2ftp_messages["Directory"] = "Ïàïêà";
$net2ftp_messages["File"] = "Ôàéë";
$net2ftp_messages["Line"] = "Ðÿäîê";
$net2ftp_messages["Action"] = "Ä³ÿ";
$net2ftp_messages["View"] = "Ïîêàç.";
$net2ftp_messages["Edit"] = "Ðåäàêò.";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "Ïåðåãëÿíóòè âèõ³äíèé êîä %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "Ðåäàãóâàòè âèõ³äíèé êîä ôàéëà %1\$s";

} // end findstring


// -------------------------------------------------------------------------
// Help module
// -------------------------------------------------------------------------
// No messages yet


// -------------------------------------------------------------------------
// Install size module
if ($net2ftp_globals["state"] == "install") {
// -------------------------------------------------------------------------

// /modules/install/install.inc.php
$net2ftp_messages["Install software packages"] = "Âñòàíîâèòè ïàêåòè ÏÎ";
$net2ftp_messages["Unable to open the template file"] = "Íå âäàëîñÿ âiäêðèòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["Unable to read the template file"] = "Íå âäàëîñÿ ïðî÷èòàòè òèì÷àñîâèé ôàéë";
$net2ftp_messages["Unable to get the list of packages"] = "Íå âäàºòüñÿ îäåðæàòè ñïèñîê ïàêåò³â";

// /skins/blue/install1.template.php
$net2ftp_messages["The net2ftp installer script has been copied to the FTP server."] = "Ñêðèïò âñòàíîâëåííÿ net2ftp áóâ ñêîï³éîâàíèé íà FTP ñåðâåð.";
$net2ftp_messages["This script runs on your web server and requires PHP to be installed."] = "Öåé ñêðèïò âèêîíóºòüñÿ íà Âàøîìó ñåðâåð³ òà âèìàãàº íàâí³ñòü PHP.";
$net2ftp_messages["In order to run it, click on the link below."] = "Äëÿ çàïóñêó íàòèñí³òü ïîñèëàííÿ íèæ÷å";
$net2ftp_messages["net2ftp has tried to determine the directory mapping between the FTP server and the web server."] = "net2ftp ñïðîáóâàâ âèçíà÷èòè çâ'ÿçîê äèðåêòîð³é ì³æ FTP òà âåá-ñåðâåðîì.";
$net2ftp_messages["Should this link not be correct, enter the URL manually in your web browser."] = "Should this link not be correct, enter the URL manually in your web browser.";

} // end install


// -------------------------------------------------------------------------
// Java upload module
if ($net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload directories and files using a Java applet"] = "Çàâàíòàæèòè ôàéëè òà äèðåêòîði¿ âèêîðèñòîâóþ÷è Java àïïëåò";
$net2ftp_messages["Your browser does not support applets, or you have disabled applets in your browser settings."] = "Your browser does not support applets, or you have disabled applets in your browser settings.";
$net2ftp_messages["To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now."] = "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.";
$net2ftp_messages["The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment)."] = "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).";
$net2ftp_messages["Alternatively, use net2ftp's normal upload or upload-and-unzip functionality."] = "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.";

} // end jupload



// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login") {
// -------------------------------------------------------------------------
$net2ftp_messages["Login!"] = "Óâ³éòè!";
$net2ftp_messages["Once you are logged in, you will be able to:"] = "Êîëè Âè çä³éñíèòå âõ³ä, Âè çìîæåòå:";
$net2ftp_messages["Navigate the FTP server"] = "Ïåðåãëÿäàòè ïàïêè òà ôàéëè íà FTP-ñåðâåð³";
$net2ftp_messages["Once you have logged in, you can browse from directory to directory and see all the subdirectories and files."] = "Êîëè Âè çä³éñíèòå âõ³ä, Âè çìîæåòå ïåðåõîäèòè â³ä ïàïêè äî ïàïêè òà ïåðåãëÿäàòè óñ³ ôàéëè òà ï³äïàïêè.";
$net2ftp_messages["Upload files"] = "Çàâàíòàæèòè ôàéëè íà ñåðâåð";
$net2ftp_messages["There are 3 different ways to upload files: the standard upload form, the upload-and-unzip functionality, and the Java Applet."] = "ª 3 ñïîñîáè çàâàíòàæèòè ôàéëè: ñòàíäàðòíà ôîðìà çàâàíòàæåííÿ, ôóíêö³ÿ upload-and-unz³p (çàâàíòàæèòè òà ðîçïàêóâàòè) òà ç äîïîìîãîþ Java-àïïëåòà.";
$net2ftp_messages["Download files"] = "Çàâàíòàæèòè ôàéëè íà êîìï";
$net2ftp_messages["Click on a filename to quickly download one file.<br />Select multiple files and click on Download; the selected files will be downloaded in a zip archive."] = "Íàòèñí³òü íà ³ì'ÿ ôàéëó ùîá øâèäêî çàâàíòàæèòè îäèí ôàéë<br />Âèáåð³òü òðîõè ôàéë³â òà íàòèñí³òü Çàâàíòàæèòè íà êîìï - âèáðàí³ ôàéëè áóäóòü ñêà÷àí³ ÿê z³p-àðõ³â.";
$net2ftp_messages["Zip files"] = "Çàïàêóâàòè ôàéëè";
$net2ftp_messages["... and save the zip archive on the FTP server, or email it to someone."] = "... òà çáåðåãòè àðõ³â íà ñåðâåð³ àáî â³äïðàâèòè ïîøòîþ.";
$net2ftp_messages["Unzip files"] = "Ðîçïàêóâàòè ôàéëè";
$net2ftp_messages["Different formats are supported: .zip, .tar, .tgz and .gz."] = "Ï³äòðèìóþòüñÿ ð³çí³ ôîðìàòè: .zip, .tar, .tgz òà .gz.";
$net2ftp_messages["Install software"] = "Âñòàíîâèòè ÏÎ";
$net2ftp_messages["Choose from a list of popular applications (PHP required)."] = "Âèáðàòè ç³ ñïèñêó ïîïóëÿðíèõ äîäàòê³â (ïîòð³áíî PHP).";
$net2ftp_messages["Copy, move and delete"] = "Êîï³þâàòè, ïåðåì³ùàòè òà âèäàëÿòè";
$net2ftp_messages["Directories are handled recursively, meaning that their content (subdirectories and files) will also be copied, moved or deleted."] = "Ïàïêè îáðîáëÿþòüñÿ ðåêóðñèâíî, ùî îçíà÷àº, ùî âñ³ ï³äïàïêè òà ôàéëè â íèõ òàêîæ áóäóòü ñêîï³éîâàí³, ïåðåì³ùåí³ àáî âèäàëåí³.";
$net2ftp_messages["Copy or move to a 2nd FTP server"] = "Ñêîï³þâàòè àáî ïåðåì³ñòèòè íà äðóãèé FTP-ñåðâåð";
$net2ftp_messages["Handy to import files to your FTP server, or to export files from your FTP server to another FTP server."] = "Çðó÷íî äëÿ òîãî, ùîá ³ìïîðòóâàòè ôàéëè íà FTP-ñåðâåð àáî â³äïðàâèòè ôàéëâ ç Âàøîãî FTP-ñåðâåðà íà ³íøèé FTP-ñåðâåð.";
$net2ftp_messages["Rename and chmod"] = "Ïåðåéìåíîâóâàòè òà çì³íþâàòè ïðàâà äîñòóïó";
$net2ftp_messages["Chmod handles directories recursively."] = "Âèêîíàòè chmod ðåêóðñèâíî.";
$net2ftp_messages["View code with syntax highlighting"] = "Ïåðåãëÿä êîäó ç ï³äñâ³÷óâàííÿì ñèíòàêñèñó";
$net2ftp_messages["PHP functions are linked to the documentation on php.net."] = "PHP ôóíêö³¿ çàçíà÷åí³ íà ñàéò³ php.net.";
$net2ftp_messages["Plain text editor"] = "Òåêñòîâèé ðåäàêòîð";
$net2ftp_messages["Edit text right from your browser; every time you save the changes the new file is transferred to the FTP server."] = "Ðåäàãóâàòè òåêñò ïðÿìî â áðàóçåð³. Ùîðàç, êîëè Âè çáåð³ãàºòå çì³íè, âîíè êîï³þþòüñÿ íà FTP-ñåðâåð.";
$net2ftp_messages["HTML editors"] = "HTML ðåäàêòîð";
$net2ftp_messages["Edit HTML a What-You-See-Is-What-You-Get (WYSIWYG) form; there are 2 different editors to choose from."] = "Ðåäàãóâàòè HTML ðåäàêòîðîì WYS²WYG. Ìîæíà âèáðàòè îäèí ³ç äâîõ ðåäàêòîð³â.";
$net2ftp_messages["Code editor"] = "Ðåäàêòîð êîäó";
$net2ftp_messages["Edit HTML and PHP in an editor with syntax highlighting."] = "Ðåäàãóâàòè HTML òà PHP ç ï³äñâ³÷óâàííÿì ñèíòàêñèñó.";
$net2ftp_messages["Search for words or phrases"] = "Øóêàòè ñëîâà òà ôðàçè";
$net2ftp_messages["Filter out files based on the filename, last modification time and filesize."] = "Ô³ëüòðóâàòè ôàéëè ïî ³ìåí³, çì³íè ÷àñó òà ðîçì³ðîâ³.";
$net2ftp_messages["Calculate size"] = "Ï³äðàõóâàòè ðîçì³ð";
$net2ftp_messages["Calculate the size of directories and files."] = "Ï³äðàõóâàòè ðîçì³ð äèðåêòîð³é òà ôàéë³â.";

$net2ftp_messages["FTP server"] = "FTP-ñåðâåð";
$net2ftp_messages["Example"] = "Ïðèêëàä";
$net2ftp_messages["Port"] = "Ïîðò";
$net2ftp_messages["Protocol"] = "Protocol";
$net2ftp_messages["Username"] = "Ëîãií";
$net2ftp_messages["Password"] = "Ïàðîëü";
$net2ftp_messages["Anonymous"] = "Àíîí³ìíî";
$net2ftp_messages["Passive mode"] = "Ïàñèâíèé ðåæèì";
$net2ftp_messages["Initial directory"] = "Ïàïêà";
$net2ftp_messages["Language"] = "Ìîâà";
$net2ftp_messages["Skin"] = "Îôîðìëåííÿ";
$net2ftp_messages["FTP mode"] = "Ðåæèì ðàáîòè FTP";
$net2ftp_messages["Automatic"] = "Àâòîìàòè÷íèé";
$net2ftp_messages["Login"] = "Âõiä";
$net2ftp_messages["Clear cookies"] = "Î÷èñòèòè êóê³";
$net2ftp_messages["Admin"] = "Àäìiíiñòðàòîð";
$net2ftp_messages["Please enter an FTP server."] = "Áóäü ëàñêà, ââåäiòü FTP ñåðâåð.";
$net2ftp_messages["Please enter a username."] = "Áóäü ëàñêà, ââåäiòü iì'ÿ êîðèñòóâà÷à.";
$net2ftp_messages["Please enter a password."] = "Áóäü ëàñêà, ââåäiòü ïàðîëü.";

} // end login


// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login_small") {
// -------------------------------------------------------------------------

$net2ftp_messages["Please enter your Administrator username and password."] = "Áóäü ëàñêà, ââåäiòü ëîãií òà ïàðîëü àäì³í³ñòðàòîðà.";
$net2ftp_messages["Please enter your username and password for FTP server <b>%1\$s</b>."] = "Áóäü ëàñêà, ââåäiòü ëîãií òà ïàðîëü äî FTP ñåðâåðó <b>%1\$s</b>.";
$net2ftp_messages["Username"] = "Ëîãií";
$net2ftp_messages["Your session has expired; please enter your password for FTP server <b>%1\$s</b> to continue."] = "×àñ ä³¿ ñåñ³¿ ìèíóâ; áóäü ëàñêà, óâåä³òü Âàø ïàðîëü äî FTP ñåðâåðà <b>%1\$s</b> ùîá ïðîäîâæèòè.";
$net2ftp_messages["Your IP address has changed; please enter your password for FTP server <b>%1\$s</b> to continue."] = "Âàø IP àäðåñà çì³íèëàñÿ; áóäü ëàñêà, ââåäiòü Âàø ïàðîëü âiä FTP ñåðâåðà <b>%1\$s</b> ùîá ïðîäîâæèòè.";
$net2ftp_messages["Password"] = "Ïàðîëü";
$net2ftp_messages["Login"] = "Âõiä";
$net2ftp_messages["Continue"] = "Ïðîäîâæèòè";

} // end login_small


// -------------------------------------------------------------------------
// Logout module
if ($net2ftp_globals["state"] == "logout") {
// -------------------------------------------------------------------------

// logout.inc.php
$net2ftp_messages["Login page"] = "Ñòîðiíêà âõîäó";

// logout.template.php
$net2ftp_messages["You have logged out from the FTP server. To log back in, <a href=\"%1\$s\" title=\"Login page (accesskey l)\" accesskey=\"l\">follow this link</a>."] = "Âè âèéøëè ç FTP ñåðâåðà. Ùîá çàéòè íàçàä, <a href=\"%1\$s\" title=\"Login page (accesskey l)\" accesskey=\"l\">íàòèñí³òü íà öå ïîñèëàííÿ</a>.";
$net2ftp_messages["Note: other users of this computer could click on the browser's Back button and access the FTP server."] = "Óâàãà: ³íø³ êîðèñòóâà÷³ öüîãî êîìï'þòåðà ìîæóòü íàòèñíóòè íà êíîïêó \"íàçàä\" òà îäåðæàòè äîñòóï äî FTP ñåðâåðà.";
$net2ftp_messages["To prevent this, you must close all browser windows."] = "Ùîá çàïîá³ãòè öüîìó, çàêðèéòå óñ³ â³êíà áðàóçåðà.";
$net2ftp_messages["Close"] = "Çàêðèòè";
$net2ftp_messages["Click here to close this window"] = "Íàòèñí³òü òóò, ùîá çàêðèòè â³êíî";

} // end logout


// -------------------------------------------------------------------------
// New directory module
if ($net2ftp_globals["state"] == "newdir") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create new directories"] = "Ñòâîðèòè íîâi ïàïêè";
$net2ftp_messages["The new directories will be created in <b>%1\$s</b>."] = "Íîâ³ ïàïêè áóäóò ñòâîðåí³ â <b>%1\$s</b>.";
$net2ftp_messages["New directory name:"] = "Íîâå iì'ÿ ïàïêè:";
$net2ftp_messages["Directory <b>%1\$s</b> was successfully created."] = "Ïàïêà <b>%1\$s</b> áóëà óñïiøíî ñòâîðåíà.";
$net2ftp_messages["Directory <b>%1\$s</b> could not be created."] = "Äèðåêòîðiÿ <b>%1\$s</b> íå ìîæå áóòè ñòâîðåíà.";

} // end newdir


// -------------------------------------------------------------------------
// Raw module
if ($net2ftp_globals["state"] == "raw") {
// -------------------------------------------------------------------------

// /modules/raw/raw.inc.php
$net2ftp_messages["Send arbitrary FTP commands"] = "Âiäïðàâëåííÿ âèïàäêîâî¿ FTP êîìàíäè";


// /skins/[skin]/raw1.template.php
$net2ftp_messages["List of commands:"] = "Ñïèñîê êîìàíä:";
$net2ftp_messages["FTP server response:"] = "Â³äïîâ³äü FTP ñåðâåðà:";

} // end raw


// -------------------------------------------------------------------------
// Rename module
if ($net2ftp_globals["state"] == "rename") {
// -------------------------------------------------------------------------
$net2ftp_messages["Rename directories and files"] = "Ïåðåéìåíóâàòè ïàïêè òà ôàéëè";
$net2ftp_messages["Old name: "] = "Ñòàðå iì'ÿ: ";
$net2ftp_messages["New name: "] = "Íîâå iì'ÿ: ";
$net2ftp_messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "²ì'ÿ íå ìîæå ì³ñòèòè êðàïîê. Íå áóëî ïåðåéìåíîâàíî â <b>%1\$s</b>";
$net2ftp_messages["The new name may not contain any banned keywords. This entry was not renamed to <b>%1\$s</b>"] = "²ì'ÿ íå ìîæå ì³ñòèòè çàáîðîíåí³ ñëîâà. Ôàéë íå áóâ ïåðåéìåíîâàíèé ó <b>%1\$s</b>";
$net2ftp_messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> áóëî óñïiøíî ïåðåèìåíîâàíî â <b>%2\$s</b>";
$net2ftp_messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> íå âäàëîñÿ ïåðåéìåíóâàòè â <b>%2\$s</b>";

} // end rename


// -------------------------------------------------------------------------
// Unzip module
if ($net2ftp_globals["state"] == "unzip") {
// -------------------------------------------------------------------------

// /modules/unzip/unzip.inc.php
$net2ftp_messages["Unzip archives"] = "Ðàñïîêàâàòü àðõ³âè";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "Îòðèìàííÿ àðõiâó %1\$s of %2\$s ç FTP ñåðâåðà";
$net2ftp_messages["Unable to get the archive <b>%1\$s</b> from the FTP server"] = "Íå âäàëîñÿ îäåðæàòè àðõiâ <b>%1\$s</b> ç FTP ñåðâåðà";

// /skins/[skin]/unzip1.template.php
$net2ftp_messages["Set all targetdirectories"] = "Âèáðàòè âñ³ ïàïêè";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "Ùîá çàäàòè ãîëîâíó ïàïêó, ââåä³òü ¿¿ íàçâó â ïîëå âèùå òà âèáåð³òü ïóíêò \"Âèáðàòè âñ³ ïàïêè\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "Ïðèì³òêà: ïàïêà ïîâèííà âæå ³ñíóâàòè.";
$net2ftp_messages["Unzip archive <b>%1\$s</b> to:"] = "Ðîçïàêóâàòè àðõiâ <b>%1\$s</b> to:";
$net2ftp_messages["Target directory:"] = "Ïàïêà ïðèçíà÷åííÿ:";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "Âèêîðèñòîâóâàòè ³ìåíà ïàïîê (ñòâîðþâàòè ï³äïàïêè àâòîìàòè÷íî)";

} // end unzip


// -------------------------------------------------------------------------
// Upload module
if ($net2ftp_globals["state"] == "upload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload to directory:"] = "Çàâàíòàæèòè â ïàïêó:";
$net2ftp_messages["Files"] = "Ôàéëè";
$net2ftp_messages["Archives"] = "Àðõiâè";
$net2ftp_messages["Files entered here will be transferred to the FTP server."] = "Ôàéëè, ââåäåí³ òóò áóäóòü ïåðåì³ùåí³ íà FTP-ñåðâåð.";
$net2ftp_messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Àðõ³âè ââåäåí³ òóò áóäóòü ðîçïàêîâàí³ òà ôàéëè áóäóòü ïåðåì³ùåí³ íà FTP-ñåðâåð.";
$net2ftp_messages["Add another"] = "Äîäàòè ³íøèé";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "Âèêîðèñòîâóâàòè ³ìåíà ïàïîê (ñòâîðþâàòè ï³äïàïêè àâòîìàòè÷íî)";

$net2ftp_messages["Choose a directory"] = "Âèáåðiòü ïàïêó";
$net2ftp_messages["Please wait..."] = "Áóäü ëàñêà, çà÷åêàéòå...";
$net2ftp_messages["Uploading... please wait..."] = "Çàâàíòàæåííÿ... çà÷åêàéòå...";
$net2ftp_messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "ßêùî çàêà÷óâàííÿ çàéìàº á³ëüø <b>%1\$s ñåêóíä<\/b>, ñïðîáóéòå çàâàíòàæèòè ìåíøå àáî ìåíø³ ôàéëè.";
$net2ftp_messages["This window will close automatically in a few seconds."] = "Öå â³êíî àâòîìàòè÷íî çàêðèºòüñÿ ÷åðåç ê³ëüêà ñåêóíä.";
$net2ftp_messages["Close window now"] = "Çàêðèòè â³êíî çàðàç";

$net2ftp_messages["Upload files and archives"] = "Çàâàíòàæèòè ôàéëè òà ïàïêè";
$net2ftp_messages["Upload results"] = "Ðåçóëüòàòè çàêà÷óâàííÿ";
$net2ftp_messages["Checking files:"] = "Ïåðåâiðêà ôàéëiâ:";
$net2ftp_messages["Transferring files to the FTP server:"] = "Ïåðåìiùåííÿ ôàéëiâ íà FTP-ñåðâåð:";
$net2ftp_messages["Decompressing archives and transferring files to the FTP server:"] = "Ðîçïàêóâàííÿ òà ïåðåì³ùåííÿ ôàéëiâ íà ñåðâåð:";
$net2ftp_messages["Upload more files and archives"] = "Çàâàíòàæèòè ³íø³ ôàéëè òà àðõ³âè";

} // end upload


// -------------------------------------------------------------------------
// Messages which are shared by upload and jupload
if ($net2ftp_globals["state"] == "upload" || $net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Restrictions:"] = "Îáìåæåííÿ:";
$net2ftp_messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s</b> and by PHP to <b>%2\$s</b>"] = "Ìàêñèìàëüíèé ðîçì³ð îäíîãî ôàéëó îáìåæåíèé net2ftp äî <b>%1\$s</b> òà PHP äî <b>%2\$s</b>";
$net2ftp_messages["The maximum execution time is <b>%1\$s seconds</b>"] = "Ìàêñèìàëüíèé ÷àñ âèêîíàííÿ <b>%1\$s ñåêóíä</b>";
$net2ftp_messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "Ðåæèì ïåðåäà÷³ FTP (ASC²² àáî B²NARY) áóäå àâòîìàòè÷íî âèçíà÷åíèé, çàñíîâàíèé íà ðîçøèðåíí³";
$net2ftp_messages["If the destination file already exists, it will be overwritten"] = "ßêùî ôàéë âæå iñíóº, âií áóäå ïåðåçàïèñàíèé";

} // end upload or jupload


// -------------------------------------------------------------------------
// View module
if ($net2ftp_globals["state"] == "view") {
// -------------------------------------------------------------------------

// /modules/view/view.inc.php
$net2ftp_messages["View file %1\$s"] = "Ïåðåãëÿä ôàéëó %1\$s";
$net2ftp_messages["View image %1\$s"] = "Ïåðåãëÿíóòè ìàëþíîê %1\$s";
$net2ftp_messages["View Macromedia ShockWave Flash movie %1\$s"] = "Ïåðåãëÿíóòè ðîëèê Macromedia ShockWave Flash %1\$s";
$net2ftp_messages["Image"] = "Çîáðàæåííÿ";

// /skins/[skin]/view1.template.php
$net2ftp_messages["Syntax highlighting powered by <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>"] = "Ï³äñâ³÷óâàííÿ ñèíòàêñèñó ðåàë³çîâàíå <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>";
$net2ftp_messages["To save the image, right-click on it and choose 'Save picture as...'"] = "Äëÿ çáåðåæåííÿ íàòèñí³òü ïðàâó êëàâ³øó ìèø³ òà âèáåð³òü 'Save picture as...'";

} // end view


// -------------------------------------------------------------------------
// Zip module
if ($net2ftp_globals["state"] == "zip") {
// -------------------------------------------------------------------------

// /modules/zip/zip.inc.php
$net2ftp_messages["Zip entries"] = "Âìiñò Zip";

// /skins/[skin]/zip1.template.php
$net2ftp_messages["Save the zip file on the FTP server as:"] = "Çáåðåãòè zip-ôàéë íà FTP-ñåðâåði ÿê:";
$net2ftp_messages["Email the zip file in attachment to:"] = "Email zip-ôàéë ïðèêð³ïëåíèì:";
$net2ftp_messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Çàìåòüòå, ÷òî îòïðàâêà ôàéëiâ íå àíîíèìíà: âàø IP-àäðåñà òàê æå ÿê òà âðåìÿ â³äïðàâëåíèéèÿ áóäå äîáàâëåí â email.";
$net2ftp_messages["Some additional comments to add in the email:"] = "Êîìåíòàði äî email:";

$net2ftp_messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "Âè íå ââåëè iì'ÿ ôàéëà äëÿ zip. Ïîâåðíiòüñÿ íàçàä òà ââåäiòü iì'ÿ ôàéëà.";
$net2ftp_messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "Email àäðåñà, ÿêó âè ââåëè (%1\$s) íåïðàâèëüíà.<br />Áóäü ëàñêà, ââåäiòü àäðåñó â ôîðìàòi <b>iì'ÿ_êîðñòóâà÷à@äîìåí.uà</b>";

} // end zip

?>