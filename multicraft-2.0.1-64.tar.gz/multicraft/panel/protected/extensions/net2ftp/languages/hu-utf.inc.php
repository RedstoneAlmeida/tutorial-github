<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2013 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------

//   -------------------------------------------------------------------------------
//  | For credits, see the credits.txt file                                         |
//   -------------------------------------------------------------------------------
//  |                                                                               |
//  |                              INSTRUCTIONS                                     |
//  |                                                                               |
//  |  The messages to translate are listed below.                                  |
//  |  The structure of each line is like this:                                     |
//  |     $message["Hello world!"] = "Hello world!";                                |
//  |                                                                               |
//  |  Keep the text between square brackets [] as it is.                           |
//  |  Translate the 2nd part, keeping the same punctuation and HTML tags.          |
//  |                                                                               |
//  |  The English message, for example                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is written in PHP!";    |
//  |  should become after translation:                                             |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp est ecrit en PHP!";     |
//  |     $message["net2ftp is written in PHP!"] = "net2ftp is geschreven in PHP!"; |
//  |                                                                               |
//  |  Note that the variable starts with a dollar sign $, that the value is        |
//  |  enclosed in double quotes " and that the line ends with a semi-colon ;       |
//  |  Be careful when editing this file, do not erase those special characters.    |
//  |                                                                               |
//  |  Some messages also contain one or more variables which start with a percent  |
//  |  sign, for example %1\$s or %2\$s. The English message, for example           |
//  |     $messages[...] = ["The file %1\$s was copied to %2\$s "]                  |
//  |  should becomes after translation:                                            |
//  |     $messages[...] = ["Le fichier %1\$s a été copié vers %2\$s "]             |
//  |                                                                               |
//  |  When a real percent sign % is needed in the text it is entered as %%         |
//  |  otherwise it is interpreted as a variable. So no, it's not a mistake.        |
//  |                                                                               |
//  |  Between the messages to translate there is additional PHP code, for example: |
//  |      if ($net2ftp_globals["state2"] == "rename") {           // <-- PHP code  |
//  |          $net2ftp_messages["Rename file"] = "Rename file";   // <-- message   |
//  |      }                                                       // <-- PHP code  |
//  |  This code is needed to load the messages only when they are actually needed. |
//  |  There is no need to change or delete any of that PHP code; translate only    |
//  |  the message.                                                                 |
//  |                                                                               |
//  |  Thanks in advance to all the translators!                                    |
//  |  David.                                                                       |
//  |                                                                               |
//   -------------------------------------------------------------------------------


// -------------------------------------------------------------------------
// Language settings
// -------------------------------------------------------------------------

// HTML lang attribute
$net2ftp_messages["en"] = "hu";

// HTML dir attribute: left-to-right (LTR) or right-to-left (RTL)
$net2ftp_messages["ltr"] = "ltr";

// CSS style: align left or right (use in combination with LTR or RTL)
$net2ftp_messages["left"] = "bal";
$net2ftp_messages["right"] = "jobb";

// Encoding
$net2ftp_messages["iso-8859-1"] = "UTF-8";


// -------------------------------------------------------------------------
// Status messages
// -------------------------------------------------------------------------

// When translating these messages, keep in mind that the text should not be too long
// It should fit in the status textbox

$net2ftp_messages["Connecting to the FTP server"] = "KapcsolÃ³dÃ¡s FTP szerverhez";
$net2ftp_messages["Logging into the FTP server"] = "KilÃ©pÃ©s az FTP szerverbÃµl";
$net2ftp_messages["Setting the passive mode"] = "PasszÃ­v mÃ³d beÃ¡llÃ­tÃ¡sa";
$net2ftp_messages["Getting the FTP system type"] = "Megismeri az FTP-rendszer tÃ­pusÃ¡t";
$net2ftp_messages["Changing the directory"] = "KÃ¶nyvtÃ¡r mÃ³dosÃ­tÃ¡sa";
$net2ftp_messages["Getting the current directory"] = "Megismeri az aktuÃ¡lis kÃ¶nyvtÃ¡rat";
$net2ftp_messages["Getting the list of directories and files"] = "Megismeri akÃ¶nyvtÃ¡rak  listÃ¡jÃ¡t Ã©s  a fÃ¡jlokat";
$net2ftp_messages["Parsing the list of directories and files"] = "Elemzi a kÃ¶nyvtÃ¡rak listÃ¡jÃ¡t Ã©s a fÃ¡jlokat";
$net2ftp_messages["Logging out of the FTP server"] = "KilÃ©pÃ©s az FTP szerverbÃµl";
$net2ftp_messages["Getting the list of directories and files"] = "Megismeri akÃ¶nyvtÃ¡rak  listÃ¡jÃ¡t Ã©s  a fÃ¡jlokat";
$net2ftp_messages["Printing the list of directories and files"] = "Nyomtatja a kÃ¶nyvtÃ¡rak listÃ¡jÃ¡t Ã©s a fÃ¡jlokat";
$net2ftp_messages["Processing the entries"] = "FeldolgozÃ³ bejegyzÃ©sek";
$net2ftp_messages["Processing entry %1\$s"] = "FeldolgozÃ¡s bejegyzÃ©s %1\$s";
$net2ftp_messages["Checking files"] = "FÃ¡jlok ellenÃµrzÃ©se";
$net2ftp_messages["Transferring files to the FTP server"] = "FÃ¡jlok Ã¡tvitele az FTP szerverre";
$net2ftp_messages["Decompressing archives and transferring files"] = "KicsomagolÃ¡skor arhÃ­v Ã©s fÃ¡jlok Ã¡tvitele";
$net2ftp_messages["Searching the files..."] = "FÃ¡jlok keresÃ©se...";
$net2ftp_messages["Uploading new file"] = "Ãj fÃ¡jl feltÃ¶ltÃ©se";
$net2ftp_messages["Reading the file"] = "Olvasni a fÃ¡jlt";
$net2ftp_messages["Parsing the file"] = "Feldongozni a fÃ¡jlt";
$net2ftp_messages["Reading the new file"] = "Olvasni az Ãºj fÃ¡jlt";
$net2ftp_messages["Reading the old file"] = "Olvasni a rÃ©gi fÃ¡jlt";
$net2ftp_messages["Comparing the 2 files"] = "ÃsszehasonlÃ­tani 2 fÃ¡jlt";
$net2ftp_messages["Printing the comparison"] = "Printing the comparison";
$net2ftp_messages["Sending FTP command %1\$s of %2\$s"] = "KÃ¼ldÃ©s FTP parancs %1\$s of %2\$s";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "ArhÃ­v kinyerÃ©se  %1\$s kÃ¶zÃ¼l %2\$s az FTP szerveren";
$net2ftp_messages["Creating a temporary directory on the FTP server"] = "LÃ©trehozÃ¡sa egy ideiglenes kÃ¶nyvtÃ¡rba az FTP szerveren";
$net2ftp_messages["Setting the permissions of the temporary directory"] = "EngedÃ©lyeinek beÃ¡llÃ­tÃ¡sÃ¡t az ideiglenes kÃ¶nyvtÃ¡r";
$net2ftp_messages["Copying the net2ftp installer script to the FTP server"] = "MÃ¡solÃ¡s a net2ftp telepÃ­tÃµ script az FTP szerverre";
$net2ftp_messages["Script finished in %1\$s seconds"] = "A script fejezÃµdÃ¶tt %1\$s mÃ¡sodpercen belÃ¼l";
$net2ftp_messages["Script halted"] = "A script megÃ¡llt";

// Used on various screens
$net2ftp_messages["Please wait..."] = "KÃ©rem vÃ¡rjon...";


// -------------------------------------------------------------------------
// index.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unexpected state string: %1\$s. Exiting."] = "A string vÃ¡ralanul: %1\$s. KilÃ©pett.";
$net2ftp_messages["This beta function is not activated on this server."] = "Ez a bÃ©ta funkciÃ³ nem aktÃ­v ezen a szerveren.";
$net2ftp_messages["This function has been disabled by the Administrator of this website."] = "Ez a funkciÃ³ le van tiltva a rendszergazda Ã¡ltal az ezen a weboldalon.";


// -------------------------------------------------------------------------
// /includes/browse.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["The directory <b>%1\$s</b> does not exist or could not be selected, so the directory <b>%2\$s</b> is shown instead."] = "A kÃ¶nyvtÃ¡r <b>%1\$s</b> nem lÃ©tezik, vagy nem lehet kivÃ¡lasztani, ezÃ©rt a kÃ¶nyvtÃ¡r <b>%2\$s</b> jelenik meg helyette.";
$net2ftp_messages["Your root directory <b>%1\$s</b> does not exist or could not be selected."] = "A gyÃ¶kÃ©r kÃ¶nyvtÃ¡rban <b>%1\$s</b> nem lÃ©tezik, vagy nem lehet kivÃ¡lasztani.";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected - you may not have sufficient rights to view this directory, or it may not exist."] = "A kÃ¶nyvtÃ¡r <b>%1\$s</b> nem lehet kivÃ¡lasztani - lehet, hogy nem rendelkezik megfelelÃµ jogokkal, hogy megtekinthesse ezt a kÃ¶nyvtÃ¡rat, vagy nem is lÃ©tezik.";
$net2ftp_messages["Entries which contain banned keywords can't be managed using net2ftp. This is to avoid Paypal or Ebay scams from being uploaded through net2ftp."] = "BejegyzÃ©seket tartalmazÃ³ tiltott kulcsszavak nem lehet felhasznÃ¡lÃ¡sÃ¡val net2ftp. Ennek cÃ©lja, hogy elkerÃ¼ljÃ©k, vagy Ebay Paypal csalÃ¡sok attÃ³l, hogy feltÃ¶ltÃ¶tt keresztÃ¼l net2ftp.";
$net2ftp_messages["Files which are too big can't be downloaded, uploaded, copied, moved, searched, zipped, unzipped, viewed or edited; they can only be renamed, chmodded or deleted."] = "FÃ¡jlok, amelyek tÃºl nagy, nem lehet letÃ¶lteni, feltÃ¶ltÃ¶tt, mÃ¡solhatÃ³k, mozgathatÃ³k, kereshetÃµ, tÃ¶mÃ¶rÃ­tett, cipzÃ¡rat kinyitni, megtekintett vagy szerkesztett, csak akkor lehet Ã¡tnevezni, chmodded vagy tÃ¶rÃ¶lni.";
$net2ftp_messages["Execute %1\$s in a new window"] = "VÃ©grehajtaja %1\$s egy Ãºj ablakban";


// -------------------------------------------------------------------------
// /includes/main.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please select at least one directory or file!"] = "KÃ©rjÃ¼k, vÃ¡lasszon legalÃ¡bb egy kÃ¶nyvtÃ¡rat vagy fÃ¡jl!";


// -------------------------------------------------------------------------
// /includes/authorizations.inc.php
// -------------------------------------------------------------------------

// checkAuthorization()
$net2ftp_messages["The FTP server <b>%1\$s</b> is not in the list of allowed FTP servers."] = "Az FTP szerver <b>%1\$s</b> nem szerepel a listÃ¡n engedÃ©lyezett FTP szervereken.";
$net2ftp_messages["The FTP server <b>%1\$s</b> is in the list of banned FTP servers."] = "Az FTP szerver <b>%1\$s</b> van a tilalmi listÃ¡n szereplÃµ FTP-szervereket.";
$net2ftp_messages["The FTP server port %1\$s may not be used."] = "Az FTP szerver portja %1\$s nem lehet felhasznÃ¡lni.";
$net2ftp_messages["Your IP address (%1\$s) is not in the list of allowed IP addresses."] = "Az Ãn IP cÃ­me (%1\$s) nem szerepel a listÃ¡n az engedÃ©lyezett IP-cÃ­mek.";
$net2ftp_messages["Your IP address (%1\$s) is in the list of banned IP addresses."] = "Az Ãn IP cÃ­me (%1\$s) van a tilalmi listÃ¡n szereplÃµ IP-cÃ­mek.";

// isAuthorizedDirectory()
$net2ftp_messages["Table net2ftp_users contains duplicate rows."] = "TÃ¡blÃ¡zat tartalmazza net2ftp_users ismÃ©tlÃµdÃµ sorokban.";

// checkAdminUsernamePassword()
$net2ftp_messages["You did not enter your Administrator username or password."] = "Nem adta meg a rendszergazda felhasznÃ¡lÃ³i nÃ©v vagy jelszÃ³.";
$net2ftp_messages["Wrong username or password. Please try again."] = "Nem vagy bejelentkezve. KÃ©rjÃ¼k, prÃ³bÃ¡lja Ãºjra.";

// -------------------------------------------------------------------------
// /includes/consumption.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to determine your IP address."] = "Nem sikerÃ¼lt meghatÃ¡rozni az IP cÃ­met.";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate rows."] = "TÃ¡blÃ¡zat tartalmazza net2ftp_log_consumption_ipaddress ismÃ©tlÃµdÃµ sorokban.";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate rows."] = "TÃ¡blÃ¡zat tartalmazza net2ftp_log_consumption_ftpserver ismÃ©tlÃµdÃµ sorokban.";
$net2ftp_messages["The variable <b>consumption_ipaddress_datatransfer</b> is not numeric."] = "A vÃ¡ltozÃ³ <b>consumption_ipaddress_datatransfer</b> nem szÃ¡mÃ©rtÃ©k.";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress could not be updated."] = "TÃ¡blÃ¡zat net2ftp_log_consumption_ipaddress nem lehet frissÃ­teni.";
$net2ftp_messages["Table net2ftp_log_consumption_ipaddress contains duplicate entries."] = "TÃ¡blÃ¡zat tartalmazza net2ftp_log_consumption_ipaddress ismÃ©tlÃµdÃµ bejegyzÃ©seket.";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver could not be updated."] = "TÃ¡blÃ¡zat net2ftp_log_consumption_ftpserver nem lehet frissÃ­teni.";
$net2ftp_messages["Table net2ftp_log_consumption_ftpserver contains duplicate entries."] = "TkÃ©pes net2ftp_log_consumption_ftpserver ismÃ©tlÃµdÃµ bejegyzÃ©seket tartalmaz.";
$net2ftp_messages["Table net2ftp_log_access could not be updated."] = "TÃ¡blÃ¡zat net2ftp_log_access nem lehet frissÃ­teni.";
$net2ftp_messages["Table net2ftp_log_access contains duplicate entries."] = "TÃ¡blÃ¡zat tartalmazza net2ftp_log_access ismÃ©tlÃµdÃµ bejegyzÃ©seket.";


// -------------------------------------------------------------------------
// /includes/database.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Unable to connect to the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "Nem sikerÃ¼lt csatlakozni a MySQL adatbÃ¡zishoz. KÃ©rjÃ¼k, ellenÃµrizze a MySQL adatbÃ¡zis beÃ¡llÃ­tÃ¡sait net2ftp konfigurÃ¡ciÃ³s fÃ¡jl settings.inc.php.";
$net2ftp_messages["Unable to select the MySQL database. Please check your MySQL database settings in net2ftp's configuration file settings.inc.php."] = "Nem vÃ¡laszthatja a MySQL adatbÃ¡zisban. KÃ©rjÃ¼k, ellenÃµrizze a MySQL adatbÃ¡zis beÃ¡llÃ­tÃ¡sait net2ftp konfigurÃ¡ciÃ³s fÃ¡jl settings.inc.php.";


// -------------------------------------------------------------------------
// /includes/errorhandling.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["An error has occured"] = "Egy hiba lÃ©pett fel";
$net2ftp_messages["Go back"] = "Menj vissza";
$net2ftp_messages["Go to the login page"] = "Menjen a bejelentkezÃµ oldalra";


// -------------------------------------------------------------------------
// /includes/filesystem.inc.php
// -------------------------------------------------------------------------

// ftp_openconnection()
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/ref.ftp.php\" target=\"_blank\">FTP module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ftp-ssl-connect.php\" target=\"_blank\">FTP and/or OpenSSL modules of PHP</a> is not installed.<br /><br /> The administrator of this website should install these modules. Installation instructions are given on php.net: <a href=\"http://www.php.net/manual/en/ftp.installation.php\" target=\"_blank\">here for FTP</a>, and <a href=\"http://www.php.net/manual/en/openssl.installation.php\" target=\"_blank\">here for OpenSSL</a><br />";
$net2ftp_messages["The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />"] = "The <a href=\"http://www.php.net/manual/en/function.ssh2-sftp.php\" target=\"_blank\">SSH2 module of PHP</a> is not installed.<br /><br /> The administrator of this website should install this module. Installation instructions are given on <a href=\"http://www.php.net/manual/en/ssh2.installation.php\" target=\"_blank\">php.net</a><br />";
$net2ftp_messages["Unable to connect to FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nem lehet kapcsolÃ³dni az FTP szerverre <b>%1\$s</b> a port <b>%2\$s</b>.<br /><br />Biztos vagy benne, hogy ez a cÃ­m az FTP szerver? Ez gyakran eltÃ©r a HTTP (web) szervert. KÃ©rjÃ¼k, lÃ©pjen kapcsolatba az ISP helpdesk vagy a rendszergazda segÃ­tsÃ©gÃ©t.<br />";
$net2ftp_messages["Unable to login to FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nem sikerÃ¼lt bejelentkezni az FTP-kiszolgÃ¡lÃ³ <b>%1\$s</b> a felhasznÃ¡lÃ³neveddel <b>%2\$s</b>.<br /><br />Biztos vagy benne, hogy a felhasznÃ¡lÃ³nÃ©v Ã©s jelszÃ³ helyes? KÃ©rjÃ¼k, lÃ©pjen kapcsolatba az ISP helpdesk vagy a rendszergazda segÃ­tsÃ©gÃ©t.<br />";
$net2ftp_messages["Unable to switch to the passive mode on FTP server <b>%1\$s</b>."] = "Nem sikerÃ¼lt vÃ¡ltani a passzÃ­v mÃ³dban az FTP szerveren <b>%1\$s</b>.";

// ftp_openconnection2()
$net2ftp_messages["Unable to connect to the second (target) FTP server <b>%1\$s</b> on port <b>%2\$s</b>.<br /><br />Are you sure this is the address of the second (target) FTP server? This is often different from that of the HTTP (web) server. Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nem sikerÃ¼lt kapcsolÃ³dni a mÃ¡sodik (cÃ©l) FTP szerver <b>%1\$s</b> a port <b>%2\$s</b>.<br /><br />Biztos vagy benne, hogy ez a cÃ­me a mÃ¡sodik (cÃ©l) FTP szerver? Ez gyakran eltÃ©r a HTTP (web) szervert. KÃ©rjÃ¼k, lÃ©pjen kapcsolatba az ISP helpdesk vagy a rendszergazda segÃ­tsÃ©gÃ©t.<br />";
$net2ftp_messages["Unable to login to the second (target) FTP server <b>%1\$s</b> with username <b>%2\$s</b>.<br /><br />Are you sure your username and password are correct? Please contact your ISP helpdesk or system administrator for help.<br />"] = "Nem sikerÃ¼lt bejelentkezni a mÃ¡sodik (cÃ©l) FTP szerver <b>%1\$s</b> a felhasznÃ¡lÃ³neveddel <b>%2\$s</b>.<br /><br />Biztos vagy benne, hogy a felhasznÃ¡lÃ³nÃ©v Ã©s jelszÃ³ helyes? KÃ©rjÃ¼k, lÃ©pjen kapcsolatba az ISP helpdesk vagy a rendszergazda segÃ­tsÃ©gÃ©t.<br />";
$net2ftp_messages["Unable to switch to the passive mode on the second (target) FTP server <b>%1\$s</b>."] = "Nem sikerÃ¼lt vÃ¡ltani a passzÃ­v mÃ³dban a mÃ¡sodik (cÃ©l) FTP szerver <b>%1\$s</b>.";

// ftp_myrename()
$net2ftp_messages["Unable to rename directory or file <b>%1\$s</b> into <b>%2\$s</b>"] = "Nem sikerÃ¼lt Ã¡tnevezni kÃ¶nyvtÃ¡r vagy fÃ¡jl <b>%1\$s</b> ba <b>%2\$s</b>";

// ftp_mychmod()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>. Note that the CHMOD command is only available on Unix FTP servers, not on Windows FTP servers."] = "Nem lehet vÃ©grehajtani a parancsot site <b>%1\$s</b>. Ne feledje, hogy a chmod parancs csak Unix FTP szerverek, nem pedig a Windows FTP szervereken.";
$net2ftp_messages["Directory <b>%1\$s</b> successfully chmodded to <b>%2\$s</b>"] = "KÃ¶nyvtÃ¡r <b>%1\$s</b> sikeresen chmodded a <b>%2\$s</b>";
$net2ftp_messages["Processing entries within directory <b>%1\$s</b>:"] = "FeldolgozÃ¡s bejegyzÃ©sek belÃ¼l kÃ¶nyvtÃ¡rban <b>%1\$s</b>:";
$net2ftp_messages["File <b>%1\$s</b> was successfully chmodded to <b>%2\$s</b>"] = "FÃ¡jl <b>%1\$s</b> sikeresen chmodded, hogy <b>%2\$s</b>";
$net2ftp_messages["All the selected directories and files have been processed."] = "Az Ã¶sszes kivÃ¡lasztott kÃ¶nyvtÃ¡rak Ã©s fÃ¡jlok kerÃ¼ltek feldolgozÃ¡sra.";

// ftp_rmdir2()
$net2ftp_messages["Unable to delete the directory <b>%1\$s</b>"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni a kÃ¶nyvtÃ¡rat <b>%1\$s</b>";

// ftp_delete2()
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni a fÃ¡jlt<b>%1\$s</b>";

// ftp_newdirectory()
$net2ftp_messages["Unable to create the directory <b>%1\$s</b>"] = "Nem sikerÃ¼lt lÃ©trehozni a kÃ¶nyvtÃ¡rat <b>%1\$s</b>";

// ftp_readfile()
$net2ftp_messages["Unable to create the temporary file"] = "Nem sikerÃ¼lt lÃ©trehozni az ideiglenes fÃ¡jlt";
$net2ftp_messages["Unable to get the file <b>%1\$s</b> from the FTP server and to save it as temporary file <b>%2\$s</b>.<br />Check the permissions of the %3\$s directory.<br />"] = "Nem sikerÃ¼lt beolvasni a fÃ¡jlt <b>%1\$s</b> Az FTP-kiszolgÃ¡lÃ³, Ã©s mentse el az ideiglenes fÃ¡jlt <b>%2\$s</b>.<br />EllenÃµrizze a jogosultsÃ¡gait a %3\$s kÃ¶nyvtÃ¡rat.<br />";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Nem sikerÃ¼lt megnyitni az ideiglenes fÃ¡jlt. EllenÃµrizze a jogosultsÃ¡gait a %1\$s kÃ¶nyvtÃ¡rat.";
$net2ftp_messages["Unable to read the temporary file"] = "Nem sikerÃ¼lt beolvasni az ideiglenes fÃ¡jlt";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "Nem sikerÃ¼lt bezÃ¡rni a kilincset az ideiglenes fÃ¡jl";
$net2ftp_messages["Unable to delete the temporary file"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni az ideiglenes fÃ¡jlt";

// ftp_writefile()
$net2ftp_messages["Unable to create the temporary file. Check the permissions of the %1\$s directory."] = "Nem sikerÃ¼lt lÃ©trehozni az ideiglenes fÃ¡jlt. EllenÃµrizze a jogosultsÃ¡gait a%1\$s kÃ¶nyvtÃ¡rat.";
$net2ftp_messages["Unable to open the temporary file. Check the permissions of the %1\$s directory."] = "Nem sikerÃ¼lt megnyitni az ideiglenes fÃ¡jlt. EllenÃµrizze a jogosultsÃ¡gait a %1\$s kÃ¶nyvtÃ¡rat.";
$net2ftp_messages["Unable to write the string to the temporary file <b>%1\$s</b>.<br />Check the permissions of the %2\$s directory."] = "Nem lehet Ã­rni a hÃºr az ideiglenes fÃ¡jl <b>%1\$s</b>.<br />EllenÃµrizze a jogosultsÃ¡gait a %2\$s kÃ¶nyvtÃ¡rat.";
$net2ftp_messages["Unable to close the handle of the temporary file"] = "Nem sikerÃ¼lt bezÃ¡rni a kilincset az ideiglenes fÃ¡jl";
$net2ftp_messages["Unable to put the file <b>%1\$s</b> on the FTP server.<br />You may not have write permissions on the directory."] = "Nem sikerÃ¼lt tenni a fÃ¡jlt <b>%1\$s</b>az FTP-kiszolgÃ¡lÃ³ra.<br />Lehet, hogy nincs Ã­rÃ¡si jogosultsÃ¡ga a kÃ¶nyvtÃ¡rban.";
$net2ftp_messages["Unable to delete the temporary file"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni az ideiglenes fÃ¡jlt";

// ftp_copymovedelete()
$net2ftp_messages["Processing directory <b>%1\$s</b>"] = "FeldolgozÃ¡s kÃ¶nyvtÃ¡r <b>%1\$s</b>";
$net2ftp_messages["The target directory <b>%1\$s</b> is the same as or a subdirectory of the source directory <b>%2\$s</b>, so this directory will be skipped"] = "A cÃ©l kÃ¶nyvtÃ¡r <b>%1\$s</b> megegyezik, vagy egy alkÃ¶nyvtÃ¡r a forrÃ¡s kÃ¶nyvtÃ¡r<b>%2\$s</b>, Ã­gy ez a kÃ¶nyvtÃ¡r kimarad";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, so this directory will be skipped"] = "A kÃ¶nyvtÃ¡r <b>%1\$s</b> tartalmaz egy tiltott kulcsszÃ³t, Ã­gy ez a kÃ¶nyvtÃ¡r kimarad";
$net2ftp_messages["The directory <b>%1\$s</b> contains a banned keyword, aborting the move"] = "A kÃ¶nyvtÃ¡r <b>%1\$s</b> tartalmaz egy tiltott kulcsszÃ³t, megszakÃ­tva a lÃ©pÃ©s";
$net2ftp_messages["Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing the copy/move process..."] = "Nem sikerÃ¼lt lÃ©trehozni a alkÃ¶nyvtÃ¡rba <b>%1\$s</b>. TalÃ¡n mÃ¡r lÃ©teznek. Folytatva a mÃ¡solÃ¡s / Ã¡thelyezÃ©s folyamata...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "Created cÃ©l alkÃ¶nyvtÃ¡r <b>%1\$s</b>";
$net2ftp_messages["The directory <b>%1\$s</b> could not be selected, so this directory will be skipped"] = "A kÃ¶nyvtÃ¡r <b>%1\$s</b> nem lehet kivÃ¡lasztani, Ã­gy ez a kÃ¶nyvtÃ¡r kimarad";
$net2ftp_messages["Unable to delete the subdirectory <b>%1\$s</b> - it may not be empty"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni a alkÃ¶nyvtÃ¡rba <b>%1\$s</b> - ez nem lehet Ã¼res";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "TÃ¶rÃ¶lt alkÃ¶nyvtÃ¡r <b>%1\$s</b>";
$net2ftp_messages["Deleted subdirectory <b>%1\$s</b>"] = "TÃ¶rÃ¶lt alkÃ¶nyvtÃ¡r <b>%1\$s</b>";
$net2ftp_messages["Unable to move the directory <b>%1\$s</b>"] = "Unable to move the directory <b>%1\$s</b>";
$net2ftp_messages["Moved directory <b>%1\$s</b>"] = "Moved directory <b>%1\$s</b>";
$net2ftp_messages["Processing of directory <b>%1\$s</b> completed"] = "TÃ¶rÃ¶lt alkÃ¶nyvtÃ¡r <b>%1\$s</b> befejezve";
$net2ftp_messages["The target for file <b>%1\$s</b> is the same as the source, so this file will be skipped"] = "A cÃ©l az, fÃ¡jl <b>%1\$s</b> ugyanaz, mint a forrÃ¡s, ezÃ©rt ez a fÃ¡jl kihagyÃ¡sra";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, so this file will be skipped"] = "A fÃ¡jl <b>%1\$s</b> tartalmaz egy tiltott kulcsszÃ³t, Ã­gy ez a fÃ¡jl kihagyÃ¡sra";
$net2ftp_messages["The file <b>%1\$s</b> contains a banned keyword, aborting the move"] = "A fÃ¡jl <b>%1\$s</b> tartalmaz egy tiltott kulcsszÃ³t, megszakÃ­tva a lÃ©pÃ©s";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be copied, so this file will be skipped"] = "A fÃ¡jl <b>%1\$s</b> tÃºl nagy ahhoz, hogy mÃ¡solhatÃ³, Ã­gy ez a fÃ¡jl kihagyÃ¡sra";
$net2ftp_messages["The file <b>%1\$s</b> is too big to be moved, aborting the move"] = "A fÃ¡jl <b>%1\$s</b> tÃºl nagy ahhoz, hogy mozgatni, megszakÃ­tva a lÃ©pÃ©s";
$net2ftp_messages["Unable to copy the file <b>%1\$s</b>"] = "Nem lehet mÃ¡solni a fÃ¡jlt <b>%1\$s</b>";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "MÃ¡solhatÃ³k fÃ¡jlt <b>%1\$s</b>";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>, aborting the move"] = "Nem sikerÃ¼lt Ã¡thelyezni a fÃ¡jlt <b>%1\$s</b>, megszakÃ­tva a lÃ©pÃ©s";
$net2ftp_messages["Unable to move the file <b>%1\$s</b>"] = "Unable to move the file <b>%1\$s</b>";
$net2ftp_messages["Moved file <b>%1\$s</b>"] = "Ãthelyzett fÃ¡jl <b>%1\$s</b>";
$net2ftp_messages["Unable to delete the file <b>%1\$s</b>"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni a fÃ¡jlt<b>%1\$s</b>";
$net2ftp_messages["Deleted file <b>%1\$s</b>"] = "TÃ¶rÃ¶lt fÃ¡jl <b>%1\$s</b>";
$net2ftp_messages["All the selected directories and files have been processed."] = "Az Ã¶sszes kivÃ¡lasztott kÃ¶nyvtÃ¡rak Ã©s fÃ¡jlok kerÃ¼ltek feldolgozÃ¡sra.";

// ftp_processfiles()

// ftp_getfile()
$net2ftp_messages["Unable to copy the remote file <b>%1\$s</b> to the local file using FTP mode <b>%2\$s</b>"] = "Nem lehet mÃ¡solni a tÃ¡voli fÃ¡jl <b>%1\$s</b> a helyi fÃ¡jl FTP-mÃ³dban <b>%2\$s</b>";
$net2ftp_messages["Unable to delete file <b>%1\$s</b>"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni a fÃ¡jlt <b>%1\$s</b>";

// ftp_putfile()
$net2ftp_messages["The file is too big to be transferred"] = "A fÃ¡jl tÃºl nagy ahhoz, hogy Ã¡t";
$net2ftp_messages["Daily limit reached: the file <b>%1\$s</b> will not be transferred"] = "Napi ElÃ©rte: a fÃ¡jl <b>%1\$s</b> nem kerÃ¼lnek Ã¡t";
$net2ftp_messages["Unable to copy the local file to the remote file <b>%1\$s</b> using FTP mode <b>%2\$s</b>"] = "Nem lehet mÃ¡solni a helyi fÃ¡jlt a tÃ¡voli fÃ¡jl <b>%1\$s</b> az FTP mÃ³d <b>%2\$s</b>";
$net2ftp_messages["Unable to delete the local file"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni a helyi fÃ¡jl";

// ftp_downloadfile()
$net2ftp_messages["Unable to delete the temporary file"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni az ideiglenes fÃ¡jlt";
$net2ftp_messages["Unable to send the file to the browser"] = "Nem sikerÃ¼lt elkÃ¼ldeni a fÃ¡jlt a bÃ¶ngÃ©szÃµ";

// ftp_zip()
$net2ftp_messages["Unable to create the temporary file"] = "Nem sikerÃ¼lt lÃ©trehozni az ideiglenes fÃ¡jlt";
$net2ftp_messages["The zip file has been saved on the FTP server as <b>%1\$s</b>"] = "A zip fÃ¡jl mentett az FTP szerverre <b>%1\$s</b>";
$net2ftp_messages["Requested files"] = "KÃ©rt fÃ¡jlok";

$net2ftp_messages["Dear,"] = "Kedves,";
$net2ftp_messages["Someone has requested the files in attachment to be sent to this email account (%1\$s)."] = "Valaki azt kÃ©rte a csatolt fÃ¡jlokat kÃ¼ldeni az e-mail fiÃ³k (%1\$s).";
$net2ftp_messages["If you know nothing about this or if you don't trust that person, please delete this email without opening the Zip file in attachment."] = "Ha nem tudsz semmit errÃµl, vagy ha nem bÃ­zol a szemÃ©ly, tÃ¶rÃ¶lje az e-mail megnyitÃ¡sa nÃ©lkÃ¼l a zip fÃ¡jlt mellÃ©kletkÃ©nt.";
$net2ftp_messages["Note that if you don't open the Zip file, the files inside cannot harm your computer."] = "Ne feledjÃ¼k, hogy ha nem tudja megnyitni a zip fÃ¡jlt, a fÃ¡jlok belsejÃ©ben ne kÃ¡rosÃ­tsa a szÃ¡mÃ­tÃ³gÃ©pet.";
$net2ftp_messages["Information about the sender: "] = "InformÃ¡ciÃ³ a feladÃ³nak: ";
$net2ftp_messages["IP address: "] = "IP address: ";
$net2ftp_messages["Time of sending: "] = "KÃ¼ldÃ©s idÃµpontja: ";
$net2ftp_messages["Sent via the net2ftp application installed on this website: "] = "KeresztÃ¼l kÃ¼ldÃ¶tt net2ftp alkalmazÃ¡s telepÃ­tve van ezen a honlapon: ";
$net2ftp_messages["Webmaster's email: "] = "Webmaster e-mail cÃ­me: ";
$net2ftp_messages["Message of the sender: "] = "Ãzenet a feladÃ³nak: ";
$net2ftp_messages["net2ftp is free software, released under the GNU/GPL license. For more information, go to http://www.net2ftp.com."] = "net2ftp szabad szoftver, megjelent a GNU / GPL licensz Ã©rvÃ©nyes. TovÃ¡bbi informÃ¡ciÃ³kÃ©rt lÃ¡togasson el ahttp://www.net2ftp.com.";

$net2ftp_messages["The zip file has been sent to <b>%1\$s</b>."] = "A zip fÃ¡jl nem Ã©rkezett <b>%1\$s</b>.";

// acceptFiles()
$net2ftp_messages["File <b>%1\$s</b> is too big. This file will not be uploaded."] = "FÃ¡jl <b>%1\$s</b> tÃºl nagy. Ez a fÃ¡jl nem lesz feltÃ¶ltve.";
$net2ftp_messages["File <b>%1\$s</b> is contains a banned keyword. This file will not be uploaded."] = "FÃ¡jl <b>%1\$s</b> nem tartalmaz egy tiltott kulcsszÃ³t. Ez a fÃ¡jl nem lesz feltÃ¶ltve.";
$net2ftp_messages["Could not generate a temporary file."] = "Nem sikerÃ¼lt lÃ©trehozni egy ideiglenes fÃ¡jlt.";
$net2ftp_messages["File <b>%1\$s</b> could not be moved"] = "FÃ¡jl <b>%1\$s</b> volna nem lehet mozgatni";
$net2ftp_messages["File <b>%1\$s</b> is OK"] = "FÃ¡jl <b>%1\$s</b> rendben van";
$net2ftp_messages["Unable to move the uploaded file to the temp directory.<br /><br />The administrator of this website has to <b>chmod 777</b> the /temp directory of net2ftp."] = "Nem tud mozogni a feltÃ¶ltÃ¶tt fÃ¡jlt a Temp kÃ¶nyvtÃ¡rba.<br /><br />A rendszergazda ezen a honlapon, hogy <b>chmod 777</b> a / temp cÃ­mjegyzÃ©ke net2ftp.";
$net2ftp_messages["You did not provide any file to upload."] = "Ãn nem adott ki a feltÃ¶ltendÃµ fÃ¡jlt.";

// ftp_transferfiles()
$net2ftp_messages["File <b>%1\$s</b> could not be transferred to the FTP server"] = "FÃ¡jl <b>%1\$s</b> nem lehetett Ã¡t az FTP szerver";
$net2ftp_messages["File <b>%1\$s</b> has been transferred to the FTP server using FTP mode <b>%2\$s</b>"] = "FÃ¡jl <b>%1\$s</b> Ã¡tkerÃ¼lt az FTP szerver az FTP mÃ³d <b>%2\$s</b>";
$net2ftp_messages["Transferring files to the FTP server"] = "FÃ¡jlok Ã¡tvitele az FTP szerverre";

// ftp_unziptransferfiles()
$net2ftp_messages["Processing archive nr %1\$s: <b>%2\$s</b>"] = "FeldolgozÃ¡s archÃ­vum nr %1\$s: <b>%2\$s</b>";
$net2ftp_messages["Archive <b>%1\$s</b> was not processed because its filename extension was not recognized. Only zip, tar, tgz and gz archives are supported at the moment."] = "ArhÃ­v <b>%1\$s</b> nem volt feldolgozni, mert a fÃ¡jl kiterjesztÃ©se nem volt ismert. Csak a zip, tar, tgz, Ã©s gz archÃ­vum tÃ¡mogatott abban a pillanatban.";
$net2ftp_messages["Unable to extract the files and directories from the archive"] = "KÃ©ptelen-hoz kivonat a fÃ¡jlokat Ã©s kÃ¶nyvtÃ¡rakat az archÃ­vumbÃ³l";
$net2ftp_messages["Archive contains filenames with ../ or ..\\ - aborting the extraction"] = "ArchÃ­vum fÃ¡jlnevek a ../ vagy ..\\ - megszakÃ­tva a kitermelÃ©si";
$net2ftp_messages["Could not unzip entry %1\$s (error code %2\$s)"] = "Could not unzip entry %1\$s (error code %2\$s)";
$net2ftp_messages["Created directory %1\$s"] = "KÃ¶nyvtÃ¡r lÃ©trehozÃ¡sa %1\$s";
$net2ftp_messages["Could not create directory %1\$s"] = "Nem sikerÃ¼lt lÃ©trehozni a kÃ¶nyvtÃ¡rat %1\$s";
$net2ftp_messages["Copied file %1\$s"] = "MÃ¡solhatÃ³k fÃ¡jlt %1\$s";
$net2ftp_messages["Could not copy file %1\$s"] = "Nem lehet mÃ¡solni file %1\$s";
$net2ftp_messages["Unable to delete the temporary directory"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni az ideiglenes kÃ¶nyvtÃ¡r";
$net2ftp_messages["Unable to delete the temporary file %1\$s"] = "Nem sikerÃ¼lt tÃ¶rÃ¶lni az ideiglenes fÃ¡jlt %1\$s";

// ftp_mysite()
$net2ftp_messages["Unable to execute site command <b>%1\$s</b>"] = "Nem lehet vÃ©grehajtani a parancsot site <b>%1\$s</b>";

// shutdown()
$net2ftp_messages["Your task was stopped"] = "Az Ãn feladata az volt, abbahagyta";
$net2ftp_messages["The task you wanted to perform with net2ftp took more time than the allowed %1\$s seconds, and therefor that task was stopped."] = "A feladat akartÃ¡l vÃ©grehajthatÃ³ net2ftp tÃ¶bb idÃµt, mint a megengedett %1\$s mÃ¡sodperc, Ã©s ennek feladata az volt, hogy megÃ¡llt.";
$net2ftp_messages["This time limit guarantees the fair use of the web server for everyone."] = "Ez a hatÃ¡ridÃµ garantÃ¡lja a tisztessÃ©ges felhasznÃ¡lÃ¡sa a webszerver mindenki szÃ¡mÃ¡ra.";
$net2ftp_messages["Try to split your task in smaller tasks: restrict your selection of files, and omit the biggest files."] = "PrÃ³bÃ¡lja meg osztott a feladatot kisebb feladatok: korlÃ¡tozzÃ¡k a kijelÃ¶lt fÃ¡jlok, Ã©s ki lehet hagyni a legnagyobb fÃ¡jl.";
$net2ftp_messages["If you really need net2ftp to be able to handle big tasks which take a long time, consider installing net2ftp on your own server."] = "Ha tÃ©nyleg szÃ¼ksÃ©g van net2ftp, hogy kÃ©pes legyen kezelni a nagy feladatokat, amelyek hosszÃº idÃµt vesz igÃ©nybe, helyezzen Ã¼zembe net2ftp sajÃ¡t szerveren.";

// SendMail()
$net2ftp_messages["You did not provide any text to send by email!"] = "Ãn nem adott szÃ¶veget kÃ¼ldeni e-mailben!";
$net2ftp_messages["You did not supply a From address."] = "Ãn nem a szolgÃ¡ltatÃ¡s FeladÃ³ cÃ­m.";
$net2ftp_messages["You did not supply a To address."] = "Te nem a szolgÃ¡ltatÃ¡s foglalkozzanak.";
$net2ftp_messages["Due to technical problems the email to <b>%1\$s</b> could not be sent."] = "MÃ»szaki problÃ©mÃ¡k miatt az e-mail <b>%1\$s</b> nem lehet elkÃ¼ldeni.";

// tempdir2()
$net2ftp_messages["Unable to create a temporary directory because (unvalid parent directory)"] = "Unable to create a temporary directory because (unvalid parent directory)";
$net2ftp_messages["Unable to create a temporary directory because (parent directory is not writeable)"] = "Unable to create a temporary directory because (parent directory is not writeable)";
$net2ftp_messages["Unable to create a temporary directory (too many tries)"] = "Unable to create a temporary directory (too many tries)";

// -------------------------------------------------------------------------
// /includes/logging.inc.php
// -------------------------------------------------------------------------
// logAccess(), logLogin(), logError()
$net2ftp_messages["Unable to execute the SQL query."] = "Nem lehet vÃ©grehajtani az SQL lekÃ©rdezÃ©st.";
$net2ftp_messages["Unable to open the system log."] = "Nem sikerÃ¼lt megnyitni a rendszer naplÃ³t.";
$net2ftp_messages["Unable to write a message to the system log."] = "Nem lehet Ã­rni egy Ã¼zenetet a rendszer naplÃ³t.";

// getLogStatus(), putLogStatus()
$net2ftp_messages["Table net2ftp_log_status contains duplicate entries."] = "Table net2ftp_log_status contains duplicate entries.";
$net2ftp_messages["Table net2ftp_log_status could not be updated."] = "Table net2ftp_log_status could not be updated.";

// rotateLogs()
$net2ftp_messages["The log tables were renamed successfully."] = "The log tables were renamed successfully.";
$net2ftp_messages["The log tables could not be renamed."] = "The log tables could not be renamed.";
$net2ftp_messages["The log tables were copied successfully."] = "The log tables were copied successfully.";
$net2ftp_messages["The log tables could not be copied."] = "The log tables could not be copied.";
$net2ftp_messages["The oldest log table was dropped successfully."] = "The oldest log table was dropped successfully.";
$net2ftp_messages["The oldest log table could not be dropped."] = "The oldest log table could not be dropped.";


// -------------------------------------------------------------------------
// /includes/registerglobals.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Please enter your username and password for FTP server "] = "KÃ©rjÃ¼k, adja meg felhasznÃ¡lÃ³nevÃ©t Ã©s jelszavÃ¡t az FTP-kiszolgÃ¡lÃ³ ";
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Ãn nem adja meg a szemÃ©lyes bejelentkezÃ©si adatait a felugrÃ³ ablakban.<br />Kattintson \"Menjen a bejelentkezÃµ oldalra\"lent.";
$net2ftp_messages["Access to the net2ftp Admin panel is disabled, because no password has been set in the file settings.inc.php. Enter a password in that file, and reload this page."] = "HozzÃ¡fÃ©rÃ©s a net2ftp Admin panel le van tiltva, mert nincs jelszÃ³ Ã¡llapÃ­tottak meg a fÃ¡jlban settings.inc.php. Ãrja be a jelszÃ³t az adott fÃ¡jlt, Ã©s Ãºjra tÃ¶lteni az oldalt.";
$net2ftp_messages["Please enter your Admin username and password"] = "KÃ©rjÃ¼k, adja meg az AdminisztrÃ¡tor felhasznÃ¡lÃ³nevÃ©t Ã©s jelszavÃ¡t "; 
$net2ftp_messages["You did not fill in your login information in the popup window.<br />Click on \"Go to the login page\" below."] = "Ãn nem adja meg a szemÃ©lyes bejelentkezÃ©si adatait a felugrÃ³ ablakban.<br />Kattintson \"Menjen a bejelentkezÃµ oldalra\"lent.";
$net2ftp_messages["Wrong username or password for the net2ftp Admin panel. The username and password can be set in the file settings.inc.php."] = "HibÃ¡s a felhasznÃ¡lÃ³ nÃ©v, vagy jelszÃ³ a net2ftp Admin panel. A felhasznÃ¡lÃ³nÃ©v Ã©s a jelszÃ³ lehet beÃ¡llÃ­tani a fÃ¡jl settings.inc.php.";


// -------------------------------------------------------------------------
// /skins/skins.inc.php
// -------------------------------------------------------------------------
$net2ftp_messages["Blue"] = "KÃ©k";
$net2ftp_messages["Grey"] = "SzÃ¼rke";
$net2ftp_messages["Black"] = "Feket";
$net2ftp_messages["Yellow"] = "SÃ¡rga";
$net2ftp_messages["Pastel"] = "Pasztell";

// getMime()
$net2ftp_messages["Directory"] = "KÃ¶nyvtÃ¡r";
$net2ftp_messages["Symlink"] = "Symlink";
$net2ftp_messages["ASP script"] = "ASP script";
$net2ftp_messages["Cascading Style Sheet"] = "Cascading Style Sheet";
$net2ftp_messages["HTML file"] = "HTML fÃ¡jl";
$net2ftp_messages["Java source file"] = "Java forrÃ¡sfÃ¡jl";
$net2ftp_messages["JavaScript file"] = "JavaScript file";
$net2ftp_messages["PHP Source"] = "PHP Source";
$net2ftp_messages["PHP script"] = "PHP script";
$net2ftp_messages["Text file"] = "SzÃ¶veges fÃ¡jl";
$net2ftp_messages["Bitmap file"] = "Bitmap fÃ¡jl";
$net2ftp_messages["GIF file"] = "GIF fÃ¡jl";
$net2ftp_messages["JPEG file"] = "JPEG fÃ¡jl";
$net2ftp_messages["PNG file"] = "PNG fÃ¡jl";
$net2ftp_messages["TIF file"] = "TIF fÃ¡jl";
$net2ftp_messages["GIMP file"] = "GIMP fÃ¡jl";
$net2ftp_messages["Executable"] = "KivihetÃµ";
$net2ftp_messages["Shell script"] = "Shell script";
$net2ftp_messages["MS Office - Word document"] = "MS Office - Word dokumentum";
$net2ftp_messages["MS Office - Excel spreadsheet"] = "MS Office - Excel tÃ¡blÃ¡zat";
$net2ftp_messages["MS Office - PowerPoint presentation"] = "MS Office - PowerPoint prezentÃ¡ciÃ³";
$net2ftp_messages["MS Office - Access database"] = "MS Office - Access adatbÃ¡zis";
$net2ftp_messages["MS Office - Visio drawing"] = "MS Office - Visio rajz";
$net2ftp_messages["MS Office - Project file"] = "MS Office - Project fÃ¡jl";
$net2ftp_messages["OpenOffice - Writer 6.0 document"] = "OpenOffice - Writer 6.0 dokumentum";
$net2ftp_messages["OpenOffice - Writer 6.0 template"] = "OpenOffice - Writer 6.0 sablon";
$net2ftp_messages["OpenOffice - Calc 6.0 spreadsheet"] = "OpenOffice - Calc 6.0 tÃ¡blÃ¡zat";
$net2ftp_messages["OpenOffice - Calc 6.0 template"] = "OpenOffice - Calc 6.0 sablon";
$net2ftp_messages["OpenOffice - Draw 6.0 document"] = "OpenOffice - Draw 6.0 dokumentum";
$net2ftp_messages["OpenOffice - Draw 6.0 template"] = "OpenOffice - Draw 6.0 sablon";
$net2ftp_messages["OpenOffice - Impress 6.0 presentation"] = "OpenOffice - Impress 6.0 prezentÃ¡ciÃ³";
$net2ftp_messages["OpenOffice - Impress 6.0 template"] = "OpenOffice - Impress 6.0 sablon";
$net2ftp_messages["OpenOffice - Writer 6.0 global document"] = "OpenOffice - Writer 6.0 nemzetkÃ¶zi dokumentum";
$net2ftp_messages["OpenOffice - Math 6.0 document"] = "OpenOffice - Math 6.0 dokumentum";
$net2ftp_messages["StarOffice - StarWriter 5.x document"] = "StarOffice - StarWriter 5.x dokumentum";
$net2ftp_messages["StarOffice - StarWriter 5.x global document"] = "StarOffice - StarWriter 5.x nemzetkÃ¶zi dokumentum";
$net2ftp_messages["StarOffice - StarCalc 5.x spreadsheet"] = "StarOffice - StarCalc 5.x tÃ¡blÃ¡zat";
$net2ftp_messages["StarOffice - StarDraw 5.x document"] = "StarOffice - StarDraw 5.x nemzetkÃ¶zi dokumentum";
$net2ftp_messages["StarOffice - StarImpress 5.x presentation"] = "StarOffice - StarImpress 5.x prezentÃ¡ciÃ³";
$net2ftp_messages["StarOffice - StarImpress Packed 5.x file"] = "StarOffice - StarImpress Packed 5.x fÃ¡jl";
$net2ftp_messages["StarOffice - StarMath 5.x document"] = "StarOffice - StarMath 5.x nemzetkÃ¶zi dokumentum";
$net2ftp_messages["StarOffice - StarChart 5.x document"] = "StarOffice - StarChart 5.x nemzetkÃ¶zi dokumentum";
$net2ftp_messages["StarOffice - StarMail 5.x mail file"] = "StarOffice - StarMail 5.x e-mail fÃ¡jl";
$net2ftp_messages["Adobe Acrobat document"] = "Adobe Acrobat dokumentum";
$net2ftp_messages["ARC archive"] = "ARC archÃ­vuma";
$net2ftp_messages["ARJ archive"] = "ARJ archÃ­vuma";
$net2ftp_messages["RPM"] = "RPM";
$net2ftp_messages["GZ archive"] = "GZ archÃ­vuma";
$net2ftp_messages["TAR archive"] = "TAR archÃ­vuma";
$net2ftp_messages["Zip archive"] = "Zip archÃ­vuma";
$net2ftp_messages["MOV movie file"] = "MOV filmfÃ¡jlt";
$net2ftp_messages["MPEG movie file"] = "MPEG filmfÃ¡jlt";
$net2ftp_messages["Real movie file"] = "Real filmfÃ¡jlt";
$net2ftp_messages["Quicktime movie file"] = "Quicktime filmfÃ¡jlt";
$net2ftp_messages["Shockwave flash file"] = "Shockwave flash fÃ¡jl";
$net2ftp_messages["Shockwave file"] = "Shockwave fÃ¡jl";
$net2ftp_messages["WAV sound file"] = "WAV hangfÃ¡jlra";
$net2ftp_messages["Font file"] = "Font fÃ¡jl";
$net2ftp_messages["%1\$s File"] = "%1\$s FÃ¡jl";
$net2ftp_messages["File"] = "FÃ¡jl";

// getAction()
$net2ftp_messages["Back"] = "Vissza";
$net2ftp_messages["Submit"] = "TovÃ¡bb";
$net2ftp_messages["Refresh"] = "FrissÃ­tÃ©s";
$net2ftp_messages["Details"] = "RÃ©szletek";
$net2ftp_messages["Icons"] = "Ikonok";
$net2ftp_messages["List"] = "Lista";
$net2ftp_messages["Logout"] = "KilÃ©pÃ©s";
$net2ftp_messages["Help"] = "SÃºgÃ³";
$net2ftp_messages["Bookmark"] = "KÃ¶nyvjelzÃµ";
$net2ftp_messages["Save"] = "MentÃ©s";
$net2ftp_messages["Default"] = "AlapÃ©rtelmezett";


// -------------------------------------------------------------------------
// /skins/[skin]/header.template.php and footer.template.php
// -------------------------------------------------------------------------
$net2ftp_messages["Help Guide"] = "SegÃ­tsÃ©g ÃtmutatÃ³ ";
$net2ftp_messages["Forums"] = "FÃ³rumok";
$net2ftp_messages["License"] = "EngedÃ©ly";
$net2ftp_messages["Powered by"] = "KÃ©szÃ­tett";
$net2ftp_messages["You are now taken to the net2ftp forums. These forums are for net2ftp related topics only - not for generic webhosting questions."] = "Ãn most mÃ¡r bevittÃ©k a net2ftp fÃ³rumokon. E fÃ³rumok szÃ¡mÃ¡ra net2ftp kapcsolatos tÃ©mÃ¡k csak - nem a generikus webhosting kÃ©rdÃ©sek.";
$net2ftp_messages["Standard"] = "Standard";
$net2ftp_messages["Mobile"] = "Mobile";

// -------------------------------------------------------------------------
// Admin module
if ($net2ftp_globals["state"] == "admin") {
// -------------------------------------------------------------------------

// /modules/admin/admin.inc.php
$net2ftp_messages["Admin functions"] = "Admin funkciÃ³k";

// /skins/[skin]/admin1.template.php
$net2ftp_messages["Version information"] = "VerziÃ³ informÃ¡ciÃ³";
$net2ftp_messages["This version of net2ftp is up-to-date."] = "Ez a vÃ¡ltozat a net2ftp naprakÃ©sz.";
$net2ftp_messages["The latest version information could not be retrieved from the net2ftp.com server. Check the security settings of your browser, which may prevent the loading of a small file from the net2ftp.com server."] = "Ez a vÃ¡ltozat a net2ftp is up-to-date.";
$net2ftp_messages["Logging"] = "NaplÃ³zÃ¡s";
$net2ftp_messages["Date from:"] = "IdÃµpontot:";
$net2ftp_messages["to:"] = "to:";
$net2ftp_messages["Empty logs"] = "Ãres naplÃ³k";
$net2ftp_messages["View logs"] = "NaplÃ³k megtekintÃ©se";
$net2ftp_messages["Go"] = "Go";
$net2ftp_messages["Setup MySQL tables"] = "Setup MySQL tÃ¡blÃ¡k";
$net2ftp_messages["Create the MySQL database tables"] = "LÃ©tre a MySQL adatbÃ¡zis-tÃ¡blÃ¡k";

} // end admin

// -------------------------------------------------------------------------
// Admin_createtables module
if ($net2ftp_globals["state"] == "admin_createtables") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_createtables.inc.php
$net2ftp_messages["Admin functions"] = "Admin funkciÃ³k";
$net2ftp_messages["The handle of file %1\$s could not be opened."] = "A fÃ¡jl megfogva %1\$s nem lehet megnyitni.";
$net2ftp_messages["The file %1\$s could not be opened."] = "A fÃ¡jl %1\$s nem lehet megnyitni.";
$net2ftp_messages["The handle of file %1\$s could not be closed."] = "A fÃ¡jl megfogva %1\$s nem lehet bezÃ¡rni.";
$net2ftp_messages["The connection to the server <b>%1\$s</b> could not be set up. Please check the database settings you've entered."] = "A kapcsolat a kiszolgÃ¡lÃ³val <b>%1\$s</b> nem lehetett lÃ©trehozni. KÃ©rjÃ¼k, ellenÃµrizze az adatbÃ¡zis beÃ¡llÃ­tÃ¡sokat lÃ©pett.";
$net2ftp_messages["Unable to select the database <b>%1\$s</b>."] = "Nem vÃ¡laszthatja az adatbÃ¡zis <b>%1\$s</b>.";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> could not be executed."] = "Az SQL lekÃ©rdezÃ©s nr <b>%1\$s</b> is nem hajthatÃ³ vÃ©gre.";
$net2ftp_messages["The SQL query nr <b>%1\$s</b> was executed successfully."] = "Az SQL lekÃ©rdezÃ©snr <b>%1\$s</b> hajtottÃ¡k vÃ©gre sikeresen.";

// /skins/[skin]/admin_createtables1.template.php
$net2ftp_messages["Please enter your MySQL settings:"] = "KÃ©rjÃ¼k, adja meg a MySQL beÃ¡llÃ­tÃ¡sok:";
$net2ftp_messages["MySQL username"] = "MySQL felhasznÃ¡lÃ³nevÃ©t";
$net2ftp_messages["MySQL password"] = "MySQL jelszavÃ¡t";
$net2ftp_messages["MySQL database"] = "MySQL adatbÃ¡zis";
$net2ftp_messages["MySQL server"] = "MySQL szerver";
$net2ftp_messages["This SQL query is going to be executed:"] = "Ez az SQL-lekÃ©rdezÃ©s lesz vÃ©gre:";
$net2ftp_messages["Execute"] = "VÃ©grehajt";

// /skins/[skin]/admin_createtables2.template.php
$net2ftp_messages["Settings used:"] = "BeÃ¡llÃ­tÃ¡sok:";
$net2ftp_messages["MySQL password length"] = "A MySQL jelszÃ³ hossza";
$net2ftp_messages["Results:"] = "EredmÃ©ny:";

} // end admin_createtables


// -------------------------------------------------------------------------
// Admin_viewlogs module
if ($net2ftp_globals["state"] == "admin_viewlogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_viewlogs.inc.php
$net2ftp_messages["Admin functions"] = "Admin funkciÃ³k";
$net2ftp_messages["Unable to execute the SQL query <b>%1\$s</b>."] = "Nem lehet vÃ©grehajtani az SQL lekÃ©rdezÃ©st <b>%1\$s</b>.";
$net2ftp_messages["No data"] = "Nincs adat";

} // end admin_viewlogs


// -------------------------------------------------------------------------
// Admin_emptylogs module
if ($net2ftp_globals["state"] == "admin_emptylogs") {
// -------------------------------------------------------------------------

// /modules/admin_createtables/admin_emptylogs.inc.php
$net2ftp_messages["Admin functions"] = "Admin funkciÃ³k";
$net2ftp_messages["The table <b>%1\$s</b> was emptied successfully."] = "A tÃ¡blÃ¡zat <b>%1\$s</b> kiÃ¼rÃ¼lt sikeresen.";
$net2ftp_messages["The table <b>%1\$s</b> could not be emptied."] = "A tÃ¡blÃ¡zat <b>%1\$s</b> nem kell Ã¼rÃ­teni.";
$net2ftp_messages["The table <b>%1\$s</b> was optimized successfully."] = "A tÃ¡blÃ¡zat <b>%1\$s</b> sikeres volt optimalizÃ¡lva.";
$net2ftp_messages["The table <b>%1\$s</b> could not be optimized."] = "A tÃ¡blÃ¡zat <b>%1\$s</b> nem lehetne optimalizÃ¡lni.";

} // end admin_emptylogs


// -------------------------------------------------------------------------
// Advanced module
if ($net2ftp_globals["state"] == "advanced") {
// -------------------------------------------------------------------------

// /modules/advanced/advanced.inc.php
$net2ftp_messages["Advanced functions"] = "HaladÃ³ funkciÃ³k";

// /skins/[skin]/advanced1.template.php
$net2ftp_messages["Go"] = "Go";
$net2ftp_messages["Disabled"] = "Tiltva";
$net2ftp_messages["Advanced FTP functions"] = "Advanced FTP fÃ¼ggvÃ©nyek";
$net2ftp_messages["Send arbitrary FTP commands to the FTP server"] = "KÃ¼ldjÃ¶n tetszÃµleges FTP-parancsok az FTP-kiszolgÃ¡lÃ³";
$net2ftp_messages["This function is available on PHP 5 only"] = "Ez a funkciÃ³ csak a PHP 5";
$net2ftp_messages["Troubleshooting functions"] = "HibaelhÃ¡rÃ­tÃ¡si feladatok";
$net2ftp_messages["Troubleshoot net2ftp on this webserver"] = "ElhÃ¡rÃ­tÃ¡sa net2ftp ezen a webszerveren";
$net2ftp_messages["Troubleshoot an FTP server"] = "ElhÃ¡rÃ­tÃ¡sa az FTP szerver";
$net2ftp_messages["Test the net2ftp list parsing rules"] = "PrÃ³bÃ¡lja ki a net2ftp lista parsing szabÃ¡lyok";
$net2ftp_messages["Translation functions"] = "FordÃ­tÃ¡si feladatok";
$net2ftp_messages["Introduction to the translation functions"] = "BevezetÃ©s a fordÃ­tÃ¡si feladatok";
$net2ftp_messages["Extract messages to translate from code files"] = "Kivonat Ã¼zenetek lefordÃ­tani a kÃ³dot kÃ©p";
$net2ftp_messages["Check if there are new or obsolete messages"] = "EllenÃµrizze, hogy vannak Ãºj Ã¼zenetek vagy elavult";

$net2ftp_messages["Beta functions"] = "BÃ©ta funkciÃ³k";
$net2ftp_messages["Send a site command to the FTP server"] = "KÃ¼ldje el egy webhely parancsot az FTP szerver";
$net2ftp_messages["Apache: password-protect a directory, create custom error pages"] = "Apache: jelszÃ³val vÃ©deni egy kÃ¶nyvtÃ¡rat, hozzon lÃ©tre egyÃ©ni lapokat";
$net2ftp_messages["MySQL: execute an SQL query"] = "MySQL: kivÃ©gez egy SQL lekÃ©rdezÃ©s";


// advanced()
$net2ftp_messages["The site command functions are not available on this webserver."] = "A weboldal irÃ¡nyÃ­tÃ³ funkciÃ³k nem Ã¡llnak rendelkezÃ©sre ezen a webszerveren.";
$net2ftp_messages["The Apache functions are not available on this webserver."] = "Az Apache funkciÃ³k nem Ã©rhetÃµk el ezen a webszerveren.";
$net2ftp_messages["The MySQL functions are not available on this webserver."] = "A MySQL fÃ¼ggvÃ©nyek nem Ã©rhetÃµk el ezen a webszerveren.";
$net2ftp_messages["Unexpected state2 string. Exiting."] = "VÃ¡ratlan state2 string. KilÃ©pett.";

} // end advanced


// -------------------------------------------------------------------------
// Advanced_ftpserver module
if ($net2ftp_globals["state"] == "advanced_ftpserver") {
// -------------------------------------------------------------------------

// /modules/advanced_ftpserver/advanced_ftpserver.inc.php
$net2ftp_messages["Troubleshoot an FTP server"] = "ElhÃ¡rÃ­tÃ¡sa az FTP szerver";

// /skins/[skin]/advanced_ftpserver1.template.php
$net2ftp_messages["Connection settings:"] = "Kapcsolat beÃ¡llÃ­tÃ¡sai:";
$net2ftp_messages["FTP server"] = "FTP szerver";
$net2ftp_messages["FTP server port"] = "FTP szerver port";
$net2ftp_messages["Username"] = "FelhasznÃ¡lÃ³nÃ©v";
$net2ftp_messages["Password"] = "JelszÃ³";
$net2ftp_messages["Password length"] = "JelszÃ³ hossza";
$net2ftp_messages["Passive mode"] = "PasszÃ­v mÃ³d";
$net2ftp_messages["Directory"] = "KÃ¶nyvtÃ¡r";
$net2ftp_messages["Printing the result"] = "NyomtatÃ¡s eredmÃ©nye";

// /skins/[skin]/advanced_ftpserver2.template.php
$net2ftp_messages["Connecting to the FTP server: "] = "KapcsolÃ³dÃ¡s az FTP szerver: ";
$net2ftp_messages["Logging into the FTP server: "] = "Bejelentkezik az FTP szerver: ";
$net2ftp_messages["Setting the passive mode: "] = "A passzÃ­v mÃ³d beÃ¡llÃ­tÃ¡sa: ";
$net2ftp_messages["Getting the FTP server system type: "] = "Megismeri az FTP-kiszolgÃ¡lÃ³ rendszer tÃ­pusÃ¡t: ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "MegvÃ¡ltoztatÃ¡sa a kÃ¶nyvtÃ¡r %1\$s: ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "A kÃ¶nyvtÃ¡rat az FTP szerver: %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "Hogyan lehet a nyers listÃ¡ja kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat: ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "KiprÃ³bÃ¡lÃ¡s mÃ¡sodik alkalommal kap a nyers listÃ¡t kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat: ";
$net2ftp_messages["Closing the connection: "] = "A kapcsolat bezÃ¡rÃ¡sa: ";
$net2ftp_messages["Raw list of directories and files:"] = "Nyers listÃ¡ja kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat:";
$net2ftp_messages["Parsed list of directories and files:"] = "Parsed listÃ¡ja kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat:";

$net2ftp_messages["OK"] = "OK";
$net2ftp_messages["not OK"] = "nem OK";

} // end advanced_ftpserver


// -------------------------------------------------------------------------
// Advanced_parsing module
if ($net2ftp_globals["state"] == "advanced_parsing") {
// -------------------------------------------------------------------------

$net2ftp_messages["Test the net2ftp list parsing rules"] = "PrÃ³bÃ¡lja ki a net2ftp lista parsing szabÃ¡lyok";
$net2ftp_messages["Sample input"] = "Minta bemenet";
$net2ftp_messages["Parsed output"] = "ÃtvizsgÃ¡lt bemenet";

} // end advanced_parsing


// -------------------------------------------------------------------------
// Advanced_webserver module
if ($net2ftp_globals["state"] == "advanced_webserver") {
// -------------------------------------------------------------------------

$net2ftp_messages["Troubleshoot your net2ftp installation"] = "ElhÃ¡rÃ­tÃ¡sa a telepÃ­tÃµ net2ftp";
$net2ftp_messages["Printing the result"] = "NyomtatÃ¡s eredmÃ©nye";

$net2ftp_messages["Checking if the FTP module of PHP is installed: "] = "EllenÃµrzÃ©se, ha az FTP modul a PHP telepÃ­tÃ©sÃ©t: ";
$net2ftp_messages["yes"] = "igen";
$net2ftp_messages["no - please install it!"] = "nem - KÃ©rjÃ¼k, telepÃ­tse azt!";

$net2ftp_messages["Checking the permissions of the directory on the web server: a small file will be written to the /temp folder and then deleted."] = "EllenÃµrzi a jogosultsÃ¡gait a kÃ¶nyvtÃ¡rat a webszerveren: egy kis fÃ¡jlt kell Ã­rni a / temp mappÃ¡t, majd el kell hagyni.";
$net2ftp_messages["Creating filename: "] = "FÃ¡jlnÃ©v lÃ©trehozÃ¡sa: ";
$net2ftp_messages["OK. Filename: %1\$s"] = "OK. FÃ¡jlneve: %1\$s";
$net2ftp_messages["not OK"] = "nem OK";
$net2ftp_messages["OK"] = "OK";
$net2ftp_messages["not OK. Check the permissions of the %1\$s directory"] = "nem OK. EllenÃµrizze a jogosultsÃ¡gait a %1\$s kÃ¶nyvtÃ¡rat";
$net2ftp_messages["Opening the file in write mode: "] = "A fÃ¡jl Ã­rÃ¡sra hasznÃ¡lni: ";
$net2ftp_messages["Writing some text to the file: "] = "ÃrÃ¡s nÃ©hÃ¡ny szÃ¶veget a fÃ¡jlba: ";
$net2ftp_messages["Closing the file: "] = "A fÃ¡jl bezÃ¡rÃ¡sa: ";
$net2ftp_messages["Deleting the file: "] = "TÃ¶rli a fÃ¡jlt: ";

$net2ftp_messages["Testing the FTP functions"] = "TesztelÃ©s az FTP fÃ¼ggvÃ©nyek";
$net2ftp_messages["Connecting to a test FTP server: "] = "CsatlakozÃ¡s teszt FTP szerver: ";
$net2ftp_messages["Connecting to the FTP server: "] = "KapcsolÃ³dÃ¡s az FTP szerver: ";
$net2ftp_messages["Logging into the FTP server: "] = "Bejelentkezik az FTP szerver: ";
$net2ftp_messages["Setting the passive mode: "] = "A passzÃ­v mÃ³d beÃ¡llÃ­tÃ¡sa: ";
$net2ftp_messages["Getting the FTP server system type: "] = "Megismeri az FTP-kiszolgÃ¡lÃ³ rendszer tÃ­pusÃ¡t: ";
$net2ftp_messages["Changing to the directory %1\$s: "] = "MegvÃ¡ltoztatÃ¡sa a kÃ¶nyvtÃ¡r %1\$s: ";
$net2ftp_messages["The directory from the FTP server is: %1\$s "] = "A kÃ¶nyvtÃ¡rat az FTP szerver: %1\$s ";
$net2ftp_messages["Getting the raw list of directories and files: "] = "Hogyan lehet a nyers listÃ¡ja kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat: ";
$net2ftp_messages["Trying a second time to get the raw list of directories and files: "] = "KiprÃ³bÃ¡lÃ¡s mÃ¡sodik alkalommal kap a nyers listÃ¡t kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat: ";
$net2ftp_messages["Closing the connection: "] = "A kapcsolat bezÃ¡rÃ¡sa: ";
$net2ftp_messages["Raw list of directories and files:"] = "Nyers listÃ¡ja kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat:";
$net2ftp_messages["Parsed list of directories and files:"] = "Parsed listÃ¡ja kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat:";
$net2ftp_messages["OK"] = "OK";
$net2ftp_messages["not OK"] = "nem OK";

} // end advanced_webserver


// -------------------------------------------------------------------------
// Bookmark module
if ($net2ftp_globals["state"] == "bookmark") {
// -------------------------------------------------------------------------

$net2ftp_messages["Drag and drop one of the links below to the bookmarks bar"] = "Drag and drop one of the links below to the bookmarks bar";
$net2ftp_messages["Right-click on one of the links below and choose \"Add to Favorites...\""] = "Right-click on one of the links below and choose \"Add to Favorites...\"";
$net2ftp_messages["Right-click on one the links below and choose \"Add Link to Bookmarks...\""] = "Right-click on one the links below and choose \"Add Link to Bookmarks...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark link...\""] = "Right-click on one of the links below and choose \"Bookmark link...\"";
$net2ftp_messages["Right-click on one of the links below and choose \"Bookmark This Link...\""] = "Right-click on one of the links below and choose \"Bookmark This Link...\"";
$net2ftp_messages["One click access (net2ftp won't ask for a password - less safe)"] = "One click access (net2ftp won't ask for a password - less safe)";
$net2ftp_messages["Two click access (net2ftp will ask for a password - safer)"] = "Two click access (net2ftp will ask for a password - safer)";
$net2ftp_messages["Note: when you will use this bookmark, a popup window will ask you for your username and password."] =  "MegjegyzÃ©s:: mikor fogja hasznÃ¡lni ezt a kÃ¶nyvjelzÃµt, egy felugrÃ³ ablak fogja kÃ©rni a felhasznÃ¡lÃ³nevÃ©t Ã©s jelszavÃ¡t.";

} // end bookmark


// -------------------------------------------------------------------------
// Browse module
if ($net2ftp_globals["state"] == "browse") {
// -------------------------------------------------------------------------

// /modules/browse/browse.inc.php
$net2ftp_messages["Choose a directory"] = "VÃ¡lassza ki a kÃ¶nyvtÃ¡rat";
$net2ftp_messages["Please wait..."] = "KÃ©rem vÃ¡rjon...";

// browse()
$net2ftp_messages["Directories with names containing \' cannot be displayed correctly. They can only be deleted. Please go back and select another subdirectory."] = "KÃ¶nyvtÃ¡rak neveit tartalmazÃ³ \' nem jelenÃ­thetÃµ meg helyesen. Csak akkor lehet hagyni. KÃ©rjÃ¼k, lÃ©pjen vissza Ã©s vÃ¡lasszon mÃ¡sik alkÃ¶nyvtÃ¡r.";

$net2ftp_messages["Daily limit reached: you will not be able to transfer data"] = "Napi ElÃ©rte: nem lesz kÃ©pes adatÃ¡tvitelre";
$net2ftp_messages["In order to guarantee the fair use of the web server for everyone, the data transfer volume and script execution time are limited per user, and per day. Once this limit is reached, you can still browse the FTP server but not transfer data to/from it."] = "Annak Ã©rdekÃ©ben, hogy biztosÃ­tsa a tisztessÃ©ges felhasznÃ¡lÃ¡sa a webszerver mindenki szÃ¡mÃ¡ra, az adatÃ¡tvitel volumene Ã©s szkript vÃ©grehajtÃ¡si idejÃ©t korlÃ¡tozzÃ¡k egy felhasznÃ¡lÃ³, vagy naponta. Amint elÃ©rik a limitet, akkor is bÃ¶ngÃ©szni az FTP szerver, de nem adja Ã¡t az adatokat / tÃµle.";
$net2ftp_messages["If you need unlimited usage, please install net2ftp on your own web server."] = "Ha szÃ¼ksÃ©g van korlÃ¡tlan hasznÃ¡lata, kÃ©rjÃ¼k telepÃ­tse net2ftp sajÃ¡t webszerveren.";

// printdirfilelist()
// Keep this short, it must fit in a small button!
$net2ftp_messages["New dir"] = "Ãj kÃ¶nyvtÃ¡r";
$net2ftp_messages["New file"] = "Ãj fÃ¡jl";
$net2ftp_messages["HTML templates"] = "HTML sablon";
$net2ftp_messages["Upload"] = "FeltÃ¶ltÃ©s";
$net2ftp_messages["Java Upload"] = "Java feltÃ¶ltÃ©s";
$net2ftp_messages["Flash Upload"] = "Flash feltÃ¶ltÃ©s";
$net2ftp_messages["Install"] = "InstallÃ¡ciÃ³";
$net2ftp_messages["Advanced"] = "SpeciÃ¡lis";
$net2ftp_messages["Copy"] = "MÃ¡sol";
$net2ftp_messages["Move"] = "Mozgat";
$net2ftp_messages["Delete"] = "TÃ¶rlÃ©s";
$net2ftp_messages["Rename"] = "ÃtnevezÃ©s";
$net2ftp_messages["Chmod"] = "Chmod";
$net2ftp_messages["Download"] = "LetÃ¶ltÃ©s";
$net2ftp_messages["Unzip"] = "Unzip";
$net2ftp_messages["Zip"] = "Zip";
$net2ftp_messages["Size"] = "MÃ©ret";
$net2ftp_messages["Search"] = "KeresÃ©s";
$net2ftp_messages["Go to the parent directory"] = "Menj a szÃ¼lÃµ kÃ¶nyvtÃ¡r";
$net2ftp_messages["Go"] = "Go";
$net2ftp_messages["Transform selected entries: "] = "Transform kivÃ¡lasztott bejegyzÃ©sek: ";
$net2ftp_messages["Transform selected entry: "] = "Transform kijelÃ¶lt bejegyzÃ©st: ";
$net2ftp_messages["Make a new subdirectory in directory %1\$s"] = "KÃ©szÃ­ts egy Ãºj alkÃ¶nyvtÃ¡r a kÃ¶nyvtÃ¡rban %1\$s";
$net2ftp_messages["Create a new file in directory %1\$s"] = "Hozzon lÃ©tre egy Ãºj fÃ¡jlt a kÃ¶nyvtÃ¡rban %1\$s";
$net2ftp_messages["Create a website easily using ready-made templates"] = "Hozzon lÃ©tre egy weboldal segÃ­tsÃ©gÃ©vel kÃ¶nnyen kÃ©sz sablonok";
$net2ftp_messages["Upload new files in directory %1\$s"] = "FeltÃ¶ltÃ©s Ãºj fÃ¡jlokat a kÃ¶nyvtÃ¡rban %1\$s";
$net2ftp_messages["Upload directories and files using a Java applet"] = "Upload kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat hasznÃ¡l Java applet";
$net2ftp_messages["Upload files using a Flash applet"] = "FeltÃ¶lteni fÃ¡jlokat Flash kisalkalmazÃ¡s";
$net2ftp_messages["Install software packages (requires PHP on web server)"] = "TelepÃ­tÃ©sÃ©hez szoftvercsomagok (requires PHP webszerver)";
$net2ftp_messages["Go to the advanced functions"] = "Menj a speciÃ¡lis funkciÃ³kat";
$net2ftp_messages["Copy the selected entries"] = "A kijelÃ¶lt tÃ©telek mÃ¡solÃ¡sa";
$net2ftp_messages["Move the selected entries"] = "A kijelÃ¶lt tÃ©telek  mozgatÃ¡sa";
$net2ftp_messages["Delete the selected entries"] = "A kijelÃ¶lt tÃ©telek tÃ¶rlÃ©se";
$net2ftp_messages["Rename the selected entries"] = "A kijelÃ¶lt tÃ©telek Ã¡tnevezÃ©se";
$net2ftp_messages["Chmod the selected entries (only works on Unix/Linux/BSD servers)"] = "Chmod a kivÃ¡lasztott pont (csak akkor mÃ»kÃ¶dik, Unix / Linux / BSD szerverek)";
$net2ftp_messages["Download a zip file containing all selected entries"] = "Le egy zip fÃ¡jl tartalmazza az Ã¶sszes kivÃ¡lasztott pont";
$net2ftp_messages["Unzip the selected archives on the FTP server"] = "Unzip a kivÃ¡lasztott archÃ­vumokat az FTP szerveren";
$net2ftp_messages["Zip the selected entries to save or email them"] = "Zip a kivÃ¡lasztott pont menteni, vagy elkÃ¼ldheti e-mailben";
$net2ftp_messages["Calculate the size of the selected entries"] = "Ki kell szÃ¡mÃ­tani a mÃ©rete a kivÃ¡lasztott pont";
$net2ftp_messages["Find files which contain a particular word"] = "Keresse meg a fÃ¡jlokat, amelyek tartalmazzÃ¡k az adott szÃ³t";
$net2ftp_messages["Click to sort by %1\$s in descending order"] = "Kattintson ide a rendezÃ©shez %1\$s a csÃ¶kkenÃµ sorrendben";
$net2ftp_messages["Click to sort by %1\$s in ascending order"] = "Kattintson ide a rendezÃ©shez %1\$s a nÃ¶vekvÃµ sorrendben";
$net2ftp_messages["Ascending order"] = "NÃ¶vekvÃµ sorrendben";
$net2ftp_messages["Descending order"] = "CsÃ¶kkenÃµ sorrendben";
$net2ftp_messages["Upload files"] = "FeltÃ¶lt fÃ¡jlokat";
$net2ftp_messages["Up"] = "Fel";
$net2ftp_messages["Click to check or uncheck all rows"] = "JelÃ¶lje be vagy tÃ¶rÃ¶lje az Ã¶sszes sorok";
$net2ftp_messages["All"] = "Ãsszes";
$net2ftp_messages["Name"] = "NÃ©v";
$net2ftp_messages["Type"] = "TÃ­pus";
//$net2ftp_messages["Size"] = "Size";
$net2ftp_messages["Owner"] = "Tulajdonos";
$net2ftp_messages["Group"] = "Csoport";
$net2ftp_messages["Perms"] = "Perms";
$net2ftp_messages["Mod Time"] = "MÃ³d. idÃµ";
$net2ftp_messages["Actions"] = "AkciÃ³";
$net2ftp_messages["Select the directory %1\$s"] = "VÃ¡lassza ki a kÃ¶nyvtÃ¡rat %1\$s";
$net2ftp_messages["Select the file %1\$s"] = "VÃ¡lassza ki a fÃ¡jlt %1\$s";
$net2ftp_messages["Select the symlink %1\$s"] = "VÃ¡lassza ki a symlink - %1\$s";
$net2ftp_messages["Go to the subdirectory %1\$s"] = "Menj a alkÃ¶nyvtÃ¡rba %1\$s";
$net2ftp_messages["Download the file %1\$s"] = "A fÃ¡jl letÃ¶ltÃ©sÃ©hez %1\$s";
$net2ftp_messages["Follow symlink %1\$s"] = "Symlinket kÃ¶vesse %1\$s";
$net2ftp_messages["View"] = "NÃ©zet";
$net2ftp_messages["Edit"] = "Szerkeszt";
$net2ftp_messages["Update"] = "FrissÃ­tÃ©s";
$net2ftp_messages["Open"] = "MegnyitÃ¡s";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "Tekintse meg a kijelÃ¶lt fÃ¡jl forrÃ¡skÃ³djÃ¡t %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "Szerkessze a forrÃ¡skÃ³d fÃ¡jl %1\$s";
$net2ftp_messages["Upload a new version of the file %1\$s and merge the changes"] = "A fÃ¡jl Ãºjabb verziÃ³jÃ¡t a fÃ¡jl %1\$s Ã©s egyesÃ­tÃ©se a vÃ¡ltozÃ¡sok";
$net2ftp_messages["View image %1\$s"] = "KÃ©p megtekintÃ©se %1\$s";
$net2ftp_messages["View the file %1\$s from your HTTP web server"] = "NÃ©zzem meg, hogy a fÃ¡jl %1\$s az Ãn HTTP webszerverÃ©n van";
$net2ftp_messages["(Note: This link may not work if you don't have your own domain name.)"] = "(MegjegyzÃ©s: Ez a kapcsolat nem mÃ»kÃ¶dik, ha Ãn nem rendelkezik sajÃ¡t domain nÃ©v.)";
$net2ftp_messages["This folder is empty"] = "Ez a mappa Ã¼res";

// printSeparatorRow()
$net2ftp_messages["Directories"] = "Directories";
$net2ftp_messages["Files"] = "Files";
$net2ftp_messages["Symlinks"] = "Symlinks";
$net2ftp_messages["Unrecognized FTP output"] = "Unrecognized FTP output";
$net2ftp_messages["Number"] = "Number";
$net2ftp_messages["Size"] = "MÃ©ret";
$net2ftp_messages["Skipped"] = "Skipped";
$net2ftp_messages["Data transferred from this IP address today"] = "Data transferred from this IP address today";
$net2ftp_messages["Data transferred to this FTP server today"] = "Data transferred to this FTP server today";

// printLocationActions()
$net2ftp_messages["Language:"] = "Nyelv:";
$net2ftp_messages["Skin:"] = "FelÃ¼let:";
$net2ftp_messages["View mode:"] = "NÃ©zetmÃ³d:";
$net2ftp_messages["Directory Tree"] = "KÃ¶nyvtÃ¡rfa";

// ftp2http()
$net2ftp_messages["Execute %1\$s in a new window"] = "VÃ©grehajtaja %1\$s egy Ãºj ablakban";
$net2ftp_messages["This file is not accessible from the web"] = "This file is not accessible from the web";

// printDirectorySelect()
$net2ftp_messages["Double-click to go to a subdirectory:"] = "Kattintson duplÃ¡n az alkÃ¶nyvtÃ¡rba lÃ©pÃ©shez:";
$net2ftp_messages["Choose"] = "VÃ¡lasztÃ¡s";
$net2ftp_messages["Up"] = "Fel";

} // end browse


// -------------------------------------------------------------------------
// Calculate size module
if ($net2ftp_globals["state"] == "calculatesize") {
// -------------------------------------------------------------------------
$net2ftp_messages["Size of selected directories and files"] = "Size of selected directories and files";
$net2ftp_messages["The total size taken by the selected directories and files is:"] = "The total size taken by the selected directories and files is:";
$net2ftp_messages["The number of files which were skipped is:"] = "The number of files which were skipped is:";

} // end calculatesize


// -------------------------------------------------------------------------
// Chmod module
if ($net2ftp_globals["state"] == "chmod") {
// -------------------------------------------------------------------------
$net2ftp_messages["Chmod directories and files"] = "Chmod kÃ¶nyvtÃ¡rak Ã©s fÃ¡jlok";
$net2ftp_messages["Set all permissions"] = "Minden engedÃ©ly beÃ¡llÃ­tÃ¡sa";
$net2ftp_messages["Read"] = "OlvasÃ¡s";
$net2ftp_messages["Write"] = "ÃrÃ¡s";
$net2ftp_messages["Execute"] = "VÃ©grehajt";
$net2ftp_messages["Owner"] = "Tulajdonos";
$net2ftp_messages["Group"] = "Csoport";
$net2ftp_messages["Everyone"] = "Mindenki";
$net2ftp_messages["To set all permissions to the same values, enter those permissions and click on the button \"Set all permissions\""] = "A minden engedÃ©ly beÃ¡llÃ­tÃ¡sa Ã©rvÃ©nyesÃ­tÃ©sÃ©hez Ã­rja be a fent emlÃ­tett engedÃ©lyeket Ã©s kattintson a gombra \"Minden engedÃ©ly beÃ¡llÃ­tÃ¡sa\"";
$net2ftp_messages["Set the permissions of directory <b>%1\$s</b> to: "] = "Set the permissions of directory <b>%1\$s</b> to: ";
$net2ftp_messages["Set the permissions of file <b>%1\$s</b> to: "] = "Set the permissions of file <b>%1\$s</b> to: ";
$net2ftp_messages["Set the permissions of symlink <b>%1\$s</b> to: "] = "Set the permissions of symlink <b>%1\$s</b> to: ";
$net2ftp_messages["Chmod value"] = "Chmod Ã©rtÃ©k";
$net2ftp_messages["Chmod also the subdirectories within this directory"] = "Chmod also the subdirectories within this directory";
$net2ftp_messages["Chmod also the files within this directory"] = "Chmod also the files within this directory";
$net2ftp_messages["The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again."] = "The chmod nr <b>%1\$s</b> is out of the range 000-777. Please try again.";

} // end chmod


// -------------------------------------------------------------------------
// Clear cookies module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// Copy/Move/Delete module
if ($net2ftp_globals["state"] == "copymovedelete") {
// -------------------------------------------------------------------------
$net2ftp_messages["Choose a directory"] = "VÃ¡lassza ki a kÃ¶nyvtÃ¡rat";
$net2ftp_messages["Copy directories and files"] = "Copy directories and files";
$net2ftp_messages["Move directories and files"] = "Move directories and files";
$net2ftp_messages["Delete directories and files"] = "Delete directories and files";
$net2ftp_messages["Are you sure you want to delete these directories and files?"] = "Are you sure you want to delete these directories and files?";
$net2ftp_messages["All the subdirectories and files of the selected directories will also be deleted!"] = "All the subdirectories and files of the selected directories will also be deleted!";
$net2ftp_messages["Set all targetdirectories"] = "Set all targetdirectories";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "Note: the target directory must already exist before anything can be copied into it.";
$net2ftp_messages["Different target FTP server:"] = "Different target FTP server:";
$net2ftp_messages["Username"] = "FelhasznÃ¡lÃ³nÃ©v";
$net2ftp_messages["Password"] = "JelszÃ³";
$net2ftp_messages["Leave empty if you want to copy the files to the same FTP server."] = "Leave empty if you want to copy the files to the same FTP server.";
$net2ftp_messages["If you want to copy the files to another FTP server, enter your login data."] = "If you want to copy the files to another FTP server, enter your login data.";
$net2ftp_messages["Leave empty if you want to move the files to the same FTP server."] = "Leave empty if you want to move the files to the same FTP server.";
$net2ftp_messages["If you want to move the files to another FTP server, enter your login data."] = "If you want to move the files to another FTP server, enter your login data.";
$net2ftp_messages["Copy directory <b>%1\$s</b> to:"] = "Copy directory <b>%1\$s</b> to:";
$net2ftp_messages["Move directory <b>%1\$s</b> to:"] = "Move directory <b>%1\$s</b> to:";
$net2ftp_messages["Directory <b>%1\$s</b>"] = "Directory <b>%1\$s</b>";
$net2ftp_messages["Copy file <b>%1\$s</b> to:"] = "Copy file <b>%1\$s</b> to:";
$net2ftp_messages["Move file <b>%1\$s</b> to:"] = "Move file <b>%1\$s</b> to:";
$net2ftp_messages["File <b>%1\$s</b>"] = "File <b>%1\$s</b>";
$net2ftp_messages["Copy symlink <b>%1\$s</b> to:"] = "Copy symlink <b>%1\$s</b> to:";
$net2ftp_messages["Move symlink <b>%1\$s</b> to:"] = "Move symlink <b>%1\$s</b> to:";
$net2ftp_messages["Symlink <b>%1\$s</b>"] = "Symlink <b>%1\$s</b>";
$net2ftp_messages["Target directory:"] = "Target directory:";
$net2ftp_messages["Target name:"] = "Target name:";
$net2ftp_messages["Processing the entries:"] = "Processing the entries:";

} // end copymovedelete


// -------------------------------------------------------------------------
// Download file module
// -------------------------------------------------------------------------
// No messages


// -------------------------------------------------------------------------
// EasyWebsite module
if ($net2ftp_globals["state"] == "easyWebsite") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create a website in 4 easy steps"] = "Create a website in 4 easy steps";
$net2ftp_messages["Template overview"] = "Template overview";
$net2ftp_messages["Template details"] = "Template details";
$net2ftp_messages["Files are copied"] = "Files are copied";
$net2ftp_messages["Edit your pages"] = "Edit your pages";

// Screen 1 - printTemplateOverview
$net2ftp_messages["Click on the image to view the details of a template."] = "Click on the image to view the details of a template.";
$net2ftp_messages["Back to the Browse screen"] = "Back to the Browse screen";
$net2ftp_messages["Template"] = "Template";
$net2ftp_messages["Copyright"] = "Copyright";
$net2ftp_messages["Click on the image to view the details of this template"] = "Click on the image to view the details of this template";

// Screen 2 - printTemplateDetails
$net2ftp_messages["The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?"] = "The template files will be copied to your FTP server. Existing files with the same filename will be overwritten. Do you want to continue?";
$net2ftp_messages["Install template to directory: "] = "Install template to directory: ";
$net2ftp_messages["Install"] = "InstallÃ¡ciÃ³";
$net2ftp_messages["Size"] = "MÃ©ret";
$net2ftp_messages["Preview page"] = "Preview page";
$net2ftp_messages["opens in a new window"] = "opens in a new window";

// Screen 3
$net2ftp_messages["Please wait while the template files are being transferred to your server: "] = "Please wait while the template files are being transferred to your server: ";
$net2ftp_messages["Done."] = "Done.";
$net2ftp_messages["Continue"] = "Continue";

// Screen 4 - printEasyAdminPanel
$net2ftp_messages["Edit page"] = "Edit page";
$net2ftp_messages["Browse the FTP server"] = "Browse the FTP server";
$net2ftp_messages["Add this link to your favorites to return to this page later on!"] = "Add this link to your favorites to return to this page later on!";
$net2ftp_messages["Edit website at %1\$s"] = "Edit website at %1\$s";
$net2ftp_messages["Internet Explorer: right-click on the link and choose \"Add to Favorites...\""] = "Internet Explorer: jobb gombbal a hivatkozÃ¡sra, Ã©s vÃ¡lassza a \"Add a kedvencekhez...\"";
$net2ftp_messages["Netscape, Mozilla, Firefox: right-click on the link and choose \"Bookmark This Link...\""] = "Netscape, Mozilla, Firefox: right-click on the link and choose \"Linket adja a KÃ¶nyvjelzÃµhÃ¶z ...\"";

// ftp_copy_local2ftp
$net2ftp_messages["WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing..."] = "WARNING: Unable to create the subdirectory <b>%1\$s</b>. It may already exist. Continuing...";
$net2ftp_messages["Created target subdirectory <b>%1\$s</b>"] = "Created cÃ©l alkÃ¶nyvtÃ¡r <b>%1\$s</b>";
$net2ftp_messages["WARNING: Unable to copy the file <b>%1\$s</b>. Continuing..."] = "WARNING: Unable to copy the file <b>%1\$s</b>. Continuing...";
$net2ftp_messages["Copied file <b>%1\$s</b>"] = "MÃ¡solhatÃ³k fÃ¡jlt <b>%1\$s</b>";
}


// -------------------------------------------------------------------------
// Edit module
if ($net2ftp_globals["state"] == "edit") {
// -------------------------------------------------------------------------

// /modules/edit/edit.inc.php
$net2ftp_messages["Unable to open the template file"] = "Unable to open the template file";
$net2ftp_messages["Unable to read the template file"] = "Unable to read the template file";
$net2ftp_messages["Please specify a filename"] = "Please specify a filename";
$net2ftp_messages["Status: This file has not yet been saved"] = "Status: This file has not yet been saved";
$net2ftp_messages["Status: Saved on <b>%1\$s</b> using mode %2\$s"] = "Status: Saved on <b>%1\$s</b> using mode %2\$s";
$net2ftp_messages["Status: <b>This file could not be saved</b>"] = "Status: <b>This file could not be saved</b>";
$net2ftp_messages["Not yet saved"] = "Not yet saved";
$net2ftp_messages["Could not be saved"] = "Could not be saved";
$net2ftp_messages["Saved at %1\$s"] = "Saved at %1\$s";

// /skins/[skin]/edit.template.php
$net2ftp_messages["Directory: "] = "Directory: ";
$net2ftp_messages["File: "] = "File: ";
$net2ftp_messages["New file name: "] = "New file name: ";
$net2ftp_messages["Character encoding: "] = "Character encoding: ";
$net2ftp_messages["Note: changing the textarea type will save the changes"] = "Note: changing the textarea type will save the changes";
$net2ftp_messages["Copy up"] = "Copy up";
$net2ftp_messages["Copy down"] = "Copy down";

} // end if edit


// -------------------------------------------------------------------------
// Find string module
if ($net2ftp_globals["state"] == "findstring") {
// -------------------------------------------------------------------------

// /modules/findstring/findstring.inc.php 
$net2ftp_messages["Search directories and files"] = "Search directories and files";
$net2ftp_messages["Search again"] = "Search again";
$net2ftp_messages["Search results"] = "Search results";
$net2ftp_messages["Please enter a valid search word or phrase."] = "Please enter a valid search word or phrase.";
$net2ftp_messages["Please enter a valid filename."] = "Please enter a valid filename.";
$net2ftp_messages["Please enter a valid file size in the \"from\" textbox, for example 0."] = "Please enter a valid file size in the \"from\" textbox, for example 0.";
$net2ftp_messages["Please enter a valid file size in the \"to\" textbox, for example 500000."] = "Please enter a valid file size in the \"to\" textbox, for example 500000.";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"from\" textbox."] = "Please enter a valid date in Y-m-d format in the \"from\" textbox.";
$net2ftp_messages["Please enter a valid date in Y-m-d format in the \"to\" textbox."] = "Please enter a valid date in Y-m-d format in the \"to\" textbox.";
$net2ftp_messages["The word <b>%1\$s</b> was not found in the selected directories and files."] = "The word <b>%1\$s</b> was not found in the selected directories and files.";
$net2ftp_messages["The word <b>%1\$s</b> was found in the following files:"] = "The word <b>%1\$s</b> was found in the following files:";

// /skins/[skin]/findstring1.template.php
$net2ftp_messages["Search for a word or phrase"] = "Search for a word or phrase";
$net2ftp_messages["Case sensitive search"] = "Case sensitive search";
$net2ftp_messages["Restrict the search to:"] = "Restrict the search to:";
$net2ftp_messages["files with a filename like"] = "files with a filename like";
$net2ftp_messages["(wildcard character is *)"] = "(wildcard character is *)";
$net2ftp_messages["files with a size"] = "files with a size";
$net2ftp_messages["files which were last modified"] = "files which were last modified";
$net2ftp_messages["from"] = "from";
$net2ftp_messages["to"] = "to";

$net2ftp_messages["Directory"] = "KÃ¶nyvtÃ¡r";
$net2ftp_messages["File"] = "FÃ¡jl";
$net2ftp_messages["Line"] = "Line";
$net2ftp_messages["Action"] = "Action";
$net2ftp_messages["View"] = "NÃ©zet";
$net2ftp_messages["Edit"] = "Szerkeszt";
$net2ftp_messages["View the highlighted source code of file %1\$s"] = "Tekintse meg a kijelÃ¶lt fÃ¡jl forrÃ¡skÃ³djÃ¡t %1\$s";
$net2ftp_messages["Edit the source code of file %1\$s"] = "Szerkessze a forrÃ¡skÃ³d fÃ¡jl %1\$s";

} // end findstring


// -------------------------------------------------------------------------
// Help module
// -------------------------------------------------------------------------
// No messages yet


// -------------------------------------------------------------------------
// Install size module
if ($net2ftp_globals["state"] == "install") {
// -------------------------------------------------------------------------

// /modules/install/install.inc.php
$net2ftp_messages["Install software packages"] = "Install software packages";
$net2ftp_messages["Unable to open the template file"] = "Unable to open the template file";
$net2ftp_messages["Unable to read the template file"] = "Unable to read the template file";
$net2ftp_messages["Unable to get the list of packages"] = "Unable to get the list of packages";

// /skins/blue/install1.template.php
$net2ftp_messages["The net2ftp installer script has been copied to the FTP server."] = "The net2ftp installer script has been copied to the FTP server.";
$net2ftp_messages["This script runs on your web server and requires PHP to be installed."] = "This script runs on your web server and requires PHP to be installed.";
$net2ftp_messages["In order to run it, click on the link below."] = "In order to run it, click on the link below.";
$net2ftp_messages["net2ftp has tried to determine the directory mapping between the FTP server and the web server."] = "net2ftp has tried to determine the directory mapping between the FTP server and the web server.";
$net2ftp_messages["Should this link not be correct, enter the URL manually in your web browser."] = "Should this link not be correct, enter the URL manually in your web browser.";

} // end install


// -------------------------------------------------------------------------
// Java upload module
if ($net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload directories and files using a Java applet"] = "Upload kÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat hasznÃ¡l Java applet";
$net2ftp_messages["Your browser does not support applets, or you have disabled applets in your browser settings."] = "Your browser does not support applets, or you have disabled applets in your browser settings.";
$net2ftp_messages["To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now."] = "To use this applet, please install the newest version of Sun's java. You can get it from <a href=\"http://www.java.com/\">java.com</a>. Click on Get It Now.";
$net2ftp_messages["The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment)."] = "The online installation is about 1-2 MB and the offline installation is about 13 MB. This 'end-user' java is called JRE (Java Runtime Environment).";
$net2ftp_messages["Alternatively, use net2ftp's normal upload or upload-and-unzip functionality."] = "Alternatively, use net2ftp's normal upload or upload-and-unzip functionality.";

} // end jupload



// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login") {
// -------------------------------------------------------------------------
$net2ftp_messages["Login!"] = "BelÃ©pÃ©s!";
$net2ftp_messages["Once you are logged in, you will be able to:"] = "MiutÃ¡n bejelentkezett, Ãn kÃ©pes lesz:";
$net2ftp_messages["Navigate the FTP server"] = "NavigÃ¡lni az FTP szerveren";
$net2ftp_messages["Once you have logged in, you can browse from directory to directory and see all the subdirectories and files."] = "Ha mÃ¡r bejelentkezett, akkor bÃ¶ngÃ©szhetÃ¼nk a kÃ¶nyvtÃ¡rbÃ³l kÃ¶nyvtÃ¡rba, Ã©s lÃ¡tni az alkÃ¶nyvtÃ¡rakat Ã©s fÃ¡jlokat.";
$net2ftp_messages["Upload files"] = "FeltÃ¶lt fÃ¡jlokat";
$net2ftp_messages["There are 3 different ways to upload files: the standard upload form, the upload-and-unzip functionality, and the Java Applet."] = "Jelenleg 3 kÃ¼lÃ¶nbÃ¶zÃµ mÃ³don lehet feltÃ¶lteni fÃ¡jlokat: a szabvÃ¡nyos feltÃ¶ltÃ©si Ã»rlapon, a feltÃ¶ltÃ©s-Ã©s unzip funkciÃ³, Ã©s a Java kisalkalmazÃ¡ssal.";
$net2ftp_messages["Download files"] = "FÃ¡jlok letÃ¶ltÃ©se";
$net2ftp_messages["Click on a filename to quickly download one file.<br />Select multiple files and click on Download; the selected files will be downloaded in a zip archive."] = "Kattintson egy fÃ¡jlnevÃ©vre gyorsan letÃ¶lt egy fÃ¡jlt. <br /> VÃ¡lasszon ki tÃ¶bb fÃ¡jlt, Ã©s kattintson a Downloadra, a kivÃ¡lasztott fÃ¡jlok letÃ¶ltÃ©sÃ©t a zip archÃ­vumban.";
$net2ftp_messages["Zip files"] = "Zip fÃ¡jlok";
$net2ftp_messages["... and save the zip archive on the FTP server, or email it to someone."] = "... and save the zip archive on the FTP server, or email it to someone.";
$net2ftp_messages["Unzip files"] = "Unzip fÃ¡jl";
$net2ftp_messages["Different formats are supported: .zip, .tar, .tgz and .gz."] = "Different formats are supported: .zip, .tar, .tgz and .gz.";
$net2ftp_messages["Install software"] = "Szoftver InstallÃ¡lÃ¡s";
$net2ftp_messages["Choose from a list of popular applications (PHP required)."] = "Choose from a list of popular applications (PHP required).";
$net2ftp_messages["Copy, move and delete"] = "Copy, move and delete";
$net2ftp_messages["Directories are handled recursively, meaning that their content (subdirectories and files) will also be copied, moved or deleted."] = "Directories are handled recursively, meaning that their content (subdirectories and files) will also be copied, moved or deleted.";
$net2ftp_messages["Copy or move to a 2nd FTP server"] = "Copy or move to a 2nd FTP server";
$net2ftp_messages["Handy to import files to your FTP server, or to export files from your FTP server to another FTP server."] = "Handy to import files to your FTP server, or to export files from your FTP server to another FTP server.";
$net2ftp_messages["Rename and chmod"] = "Rename and chmod";
$net2ftp_messages["Chmod handles directories recursively."] = "Chmod handles directories recursively.";
$net2ftp_messages["View code with syntax highlighting"] = "View code with syntax highlighting";
$net2ftp_messages["PHP functions are linked to the documentation on php.net."] = "PHP functions are linked to the documentation on php.net.";
$net2ftp_messages["Plain text editor"] = "Plain text editor";
$net2ftp_messages["Edit text right from your browser; every time you save the changes the new file is transferred to the FTP server."] = "Edit text right from your browser; every time you save the changes the new file is transferred to the FTP server.";
$net2ftp_messages["HTML editors"] = "HTML editors";
$net2ftp_messages["Edit HTML a What-You-See-Is-What-You-Get (WYSIWYG) form; there are 2 different editors to choose from."] = "Edit HTML a What-You-See-Is-What-You-Get (WYSIWYG) form; there are 2 different editors to choose from.";
$net2ftp_messages["Code editor"] = "Code editor";
$net2ftp_messages["Edit HTML and PHP in an editor with syntax highlighting."] = "Edit HTML and PHP in an editor with syntax highlighting.";
$net2ftp_messages["Search for words or phrases"] = "Search for words or phrases";
$net2ftp_messages["Filter out files based on the filename, last modification time and filesize."] = "Filter out files based on the filename, last modification time and filesize.";
$net2ftp_messages["Calculate size"] = "Calculate size";
$net2ftp_messages["Calculate the size of directories and files."] = "Calculate the size of directories and files.";

$net2ftp_messages["FTP server"] = "FTP szerver";
$net2ftp_messages["Example"] = "PÃ©lda";
$net2ftp_messages["Port"] = "Port";
$net2ftp_messages["Protocol"] = "Protocol";
$net2ftp_messages["Username"] = "FelhasznÃ¡lÃ³nÃ©v";
$net2ftp_messages["Password"] = "JelszÃ³";
$net2ftp_messages["Anonymous"] = "NÃ©vtelen";
$net2ftp_messages["Passive mode"] = "PasszÃ­v mÃ³d";
$net2ftp_messages["Initial directory"] = "KezdÃµ kÃ¶nyvtÃ¡r";
$net2ftp_messages["Language"] = "Nyelv";
$net2ftp_messages["Skin"] = "FelÃ¼let";
$net2ftp_messages["FTP mode"] = "FTP mÃ³d";
$net2ftp_messages["Automatic"] = "Automatikus";
$net2ftp_messages["Login"] = "BelÃ©pÃ©s";
$net2ftp_messages["Clear cookies"] = "SÃ¼tik tÃ¶rlÃ©se";
$net2ftp_messages["Admin"] = "AdminisztrÃ¡tor";
$net2ftp_messages["Please enter an FTP server."] = "Please enter an FTP server.";
$net2ftp_messages["Please enter a username."] = "KÃ©rem adja meg a felhasznÃ¡lÃ³i nevÃ©t.";
$net2ftp_messages["Please enter a password."] = "KÃ©rem adja meg a jelszÃ³t.";

} // end login


// -------------------------------------------------------------------------
// Login module
if ($net2ftp_globals["state"] == "login_small") {
// -------------------------------------------------------------------------

$net2ftp_messages["Please enter your Administrator username and password."] = "KÃ©rem adja meg az AdminisztrÃ¡tor felhasznÃ¡lÃ³i nevÃ©t Ã©s jelszavÃ¡t.";
$net2ftp_messages["Please enter your username and password for FTP server <b>%1\$s</b>."] = "KÃ©rjÃ¼k, adja meg felhasznÃ¡lÃ³nevÃ©t Ã©s jelszavÃ¡t az FTP-kiszolgÃ¡lÃ³hoz <b>%1\$s</b>.";
$net2ftp_messages["Username"] = "FelhasznÃ¡lÃ³nÃ©v";
$net2ftp_messages["Your session has expired; please enter your password for FTP server <b>%1\$s</b> to continue."] = "MÃ»veleti ideje lejÃ¡rt, kÃ©rjÃ¼k adja meg a jelszÃ³t az FTP-kiszolgÃ¡lÃ³ <b>%1\$s</b> folytatÃ¡sÃ¡hoz.";
$net2ftp_messages["Your IP address has changed; please enter your password for FTP server <b>%1\$s</b> to continue."] = "Az Ãn IP cÃ­me megvÃ¡ltozott; KÃ©rjÃ¼k, adja meg a jelszavÃ¡t az FTP-kiszolgÃ¡lÃ³ <b>%1\$s</b> folytatÃ¡sÃ¡hoz.";
$net2ftp_messages["Password"] = "JelszÃ³";
$net2ftp_messages["Login"] = "BelÃ©pÃ©s";
$net2ftp_messages["Continue"] = "Continue";

} // end login_small


// -------------------------------------------------------------------------
// Logout module
if ($net2ftp_globals["state"] == "logout") {
// -------------------------------------------------------------------------

// logout.inc.php
$net2ftp_messages["Login page"] = "Login page";

// logout.template.php
$net2ftp_messages["You have logged out from the FTP server. To log back in, <a href=\"%1\$s\" title=\"Login page (accesskey l)\" accesskey=\"l\">follow this link</a>."] = "You have logged out from the FTP server. To log back in, <a href=\"%1\$s\" title=\"Login page (accesskey l)\" accesskey=\"l\">follow this link</a>.";
$net2ftp_messages["Note: other users of this computer could click on the browser's Back button and access the FTP server."] = "Note: other users of this computer could click on the browser's Back button and access the FTP server.";
$net2ftp_messages["To prevent this, you must close all browser windows."] = "To prevent this, you must close all browser windows.";
$net2ftp_messages["Close"] = "Close";
$net2ftp_messages["Click here to close this window"] = "Click here to close this window";

} // end logout


// -------------------------------------------------------------------------
// New directory module
if ($net2ftp_globals["state"] == "newdir") {
// -------------------------------------------------------------------------
$net2ftp_messages["Create new directories"] = "Create new directories";
$net2ftp_messages["The new directories will be created in <b>%1\$s</b>."] = "The new directories will be created in <b>%1\$s</b>.";
$net2ftp_messages["New directory name:"] = "New directory name:";
$net2ftp_messages["Directory <b>%1\$s</b> was successfully created."] = "Directory <b>%1\$s</b> was successfully created.";
$net2ftp_messages["Directory <b>%1\$s</b> could not be created."] = "Directory <b>%1\$s</b> could not be created.";

} // end newdir


// -------------------------------------------------------------------------
// Raw module
if ($net2ftp_globals["state"] == "raw") {
// -------------------------------------------------------------------------

// /modules/raw/raw.inc.php
$net2ftp_messages["Send arbitrary FTP commands"] = "Send arbitrary FTP commands";


// /skins/[skin]/raw1.template.php
$net2ftp_messages["List of commands:"] = "List of commands:";
$net2ftp_messages["FTP server response:"] = "FTP server response:";

} // end raw


// -------------------------------------------------------------------------
// Rename module
if ($net2ftp_globals["state"] == "rename") {
// -------------------------------------------------------------------------
$net2ftp_messages["Rename directories and files"] = "Rename directories and files";
$net2ftp_messages["Old name: "] = "Old name: ";
$net2ftp_messages["New name: "] = "New name: ";
$net2ftp_messages["The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>"] = "The new name may not contain any dots. This entry was not renamed to <b>%1\$s</b>";
$net2ftp_messages["The new name may not contain any banned keywords. This entry was not renamed to <b>%1\$s</b>"] = "The new name may not contain any banned keywords. This entry was not renamed to <b>%1\$s</b>";
$net2ftp_messages["<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> was successfully renamed to <b>%2\$s</b>";
$net2ftp_messages["<b>%1\$s</b> could not be renamed to <b>%2\$s</b>"] = "<b>%1\$s</b> could not be renamed to <b>%2\$s</b>";

} // end rename


// -------------------------------------------------------------------------
// Unzip module
if ($net2ftp_globals["state"] == "unzip") {
// -------------------------------------------------------------------------

// /modules/unzip/unzip.inc.php
$net2ftp_messages["Unzip archives"] = "Unzip archives";
$net2ftp_messages["Getting archive %1\$s of %2\$s from the FTP server"] = "ArhÃ­v kinyerÃ©se  %1\$s kÃ¶zÃ¼l %2\$s az FTP szerveren";
$net2ftp_messages["Unable to get the archive <b>%1\$s</b> from the FTP server"] = "Unable to get the archive <b>%1\$s</b> from the FTP server";

// /skins/[skin]/unzip1.template.php
$net2ftp_messages["Set all targetdirectories"] = "Set all targetdirectories";
$net2ftp_messages["To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\"."] = "To set a common target directory, enter that target directory in the textbox above and click on the button \"Set all targetdirectories\".";
$net2ftp_messages["Note: the target directory must already exist before anything can be copied into it."] = "Note: the target directory must already exist before anything can be copied into it.";
$net2ftp_messages["Unzip archive <b>%1\$s</b> to:"] = "Unzip archive <b>%1\$s</b> to:";
$net2ftp_messages["Target directory:"] = "Target directory:";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "Use folder names (creates subdirectories automatically)";

} // end unzip


// -------------------------------------------------------------------------
// Upload module
if ($net2ftp_globals["state"] == "upload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Upload to directory:"] = "Upload to directory:";
$net2ftp_messages["Files"] = "Files";
$net2ftp_messages["Archives"] = "Archives";
$net2ftp_messages["Files entered here will be transferred to the FTP server."] = "Files entered here will be transferred to the FTP server.";
$net2ftp_messages["Archives entered here will be decompressed, and the files inside will be transferred to the FTP server."] = "Archives entered here will be decompressed, and the files inside will be transferred to the FTP server.";
$net2ftp_messages["Add another"] = "Add another";
$net2ftp_messages["Use folder names (creates subdirectories automatically)"] = "Use folder names (creates subdirectories automatically)";

$net2ftp_messages["Choose a directory"] = "VÃ¡lassza ki a kÃ¶nyvtÃ¡rat";
$net2ftp_messages["Please wait..."] = "KÃ©rem vÃ¡rjon...";
$net2ftp_messages["Uploading... please wait..."] = "Uploading... please wait...";
$net2ftp_messages["If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files."] = "If the upload takes more than the allowed <b>%1\$s seconds<\/b>, you will have to try again with less/smaller files.";
$net2ftp_messages["This window will close automatically in a few seconds."] = "This window will close automatically in a few seconds.";
$net2ftp_messages["Close window now"] = "Close window now";

$net2ftp_messages["Upload files and archives"] = "Upload files and archives";
$net2ftp_messages["Upload results"] = "Upload results";
$net2ftp_messages["Checking files:"] = "Checking files:";
$net2ftp_messages["Transferring files to the FTP server:"] = "Transferring files to the FTP server:";
$net2ftp_messages["Decompressing archives and transferring files to the FTP server:"] = "Decompressing archives and transferring files to the FTP server:";
$net2ftp_messages["Upload more files and archives"] = "Upload more files and archives";

} // end upload


// -------------------------------------------------------------------------
// Messages which are shared by upload and jupload
if ($net2ftp_globals["state"] == "upload" || $net2ftp_globals["state"] == "jupload") {
// -------------------------------------------------------------------------
$net2ftp_messages["Restrictions:"] = "Restrictions:";
$net2ftp_messages["The maximum size of one file is restricted by net2ftp to <b>%1\$s</b> and by PHP to <b>%2\$s</b>"] = "The maximum size of one file is restricted by net2ftp to <b>%1\$s</b> and by PHP to <b>%2\$s</b>";
$net2ftp_messages["The maximum execution time is <b>%1\$s seconds</b>"] = "The maximum execution time is <b>%1\$s seconds</b>";
$net2ftp_messages["The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension"] = "The FTP transfer mode (ASCII or BINARY) will be automatically determined, based on the filename extension";
$net2ftp_messages["If the destination file already exists, it will be overwritten"] = "If the destination file already exists, it will be overwritten";

} // end upload or jupload


// -------------------------------------------------------------------------
// View module
if ($net2ftp_globals["state"] == "view") {
// -------------------------------------------------------------------------

// /modules/view/view.inc.php
$net2ftp_messages["View file %1\$s"] = "View file %1\$s";
$net2ftp_messages["View image %1\$s"] = "KÃ©p megtekintÃ©se %1\$s";
$net2ftp_messages["View Macromedia ShockWave Flash movie %1\$s"] = "View Macromedia ShockWave Flash movie %1\$s";
$net2ftp_messages["Image"] = "Image";

// /skins/[skin]/view1.template.php
$net2ftp_messages["Syntax highlighting powered by <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>"] = "Syntax highlighting powered by <a href=\"http://luminous.asgaard.co.uk\">Luminous</a>";
$net2ftp_messages["To save the image, right-click on it and choose 'Save picture as...'"] = "To save the image, right-click on it and choose 'Save picture as...'";

} // end view


// -------------------------------------------------------------------------
// Zip module
if ($net2ftp_globals["state"] == "zip") {
// -------------------------------------------------------------------------

// /modules/zip/zip.inc.php
$net2ftp_messages["Zip entries"] = "Zip entries";

// /skins/[skin]/zip1.template.php
$net2ftp_messages["Save the zip file on the FTP server as:"] = "Save the zip file on the FTP server as:";
$net2ftp_messages["Email the zip file in attachment to:"] = "Email the zip file in attachment to:";
$net2ftp_messages["Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email."] = "Note that sending files is not anonymous: your IP address as well as the time of the sending will be added to the email.";
$net2ftp_messages["Some additional comments to add in the email:"] = "Some additional comments to add in the email:";

$net2ftp_messages["You did not enter a filename for the zipfile. Go back and enter a filename."] = "You did not enter a filename for the zipfile. Go back and enter a filename.";
$net2ftp_messages["The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>"] = "The email address you have entered (%1\$s) does not seem to be valid.<br />Please enter an address in the format <b>username@domain.com</b>";

} // end zip

?>