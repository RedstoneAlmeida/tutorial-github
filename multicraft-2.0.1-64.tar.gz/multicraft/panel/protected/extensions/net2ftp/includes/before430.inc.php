<?php

//   -------------------------------------------------------------------------------
//  |                  net2ftp: a web based FTP client                              |
//  |              Copyright (c) 2003-2013 by David Gartner                         |
//  |                                                                               |
//  | This program is free software; you can redistribute it and/or                 |
//  | modify it under the terms of the GNU General Public License                   |
//  | as published by the Free Software Foundation; either version 2                |
//  | of the License, or (at your option) any later version.                        |
//  |                                                                               |
//   -------------------------------------------------------------------------------




// **************************************************************************************
// **************************************************************************************
// **                                                                                  **
// **                                                                                  **

function debug_backtrace() {

// --------------
// This function is defined when the PHP version is < 4.3.0
// --------------

	return "There is no backtrace information available, because this websites runs an older version of PHP (before 4.3.0).";

} // end function debug_backtrace

// **                                                                                  **
// **                                                                                  **
// **************************************************************************************
// **************************************************************************************



?>