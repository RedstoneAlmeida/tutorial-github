<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/blue/status/status.template.php begin -->
<div id="container">
<script type="text/javascript">self.setprogress("p_561b57_",0,"",0); </script>
<!-- Template /skins/blue/status/status.template.php end -->
