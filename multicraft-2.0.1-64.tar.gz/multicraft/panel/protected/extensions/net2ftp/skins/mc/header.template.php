<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/mc/statusbar.template.php begin -->
<script type="text/javascript" src="<?php echo Theme::js('net2ftp/status.js'); ?>"></script>
<?php require_once($net2ftp_globals["application_skinsdir"] . "/" . $net2ftp_globals["skin"] . "/status/status.template.php"); ?>
<!-- Template /skins/mc/statusbar.template.php end -->
