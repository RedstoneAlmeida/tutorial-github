<?php
/**
 *
 *   Copyright © 2010-2016 by xhost.ch GmbH
 *
 *   All rights reserved.
 *
 **/

class UserController extends Controller
{
    public $layout='//layouts/column2';

    public function filters()
    {
        return array(
            'accessControl',
        );
    }

    public function accessRules()
    {
        return array(
            array('allow',
                'actions'=>array('index', 'view', 'autocomplete'),
                'users'=>array('@'),
            ),
            array('allow',
                'actions'=>array('create', 'update', 'delete'),
                'expression'=>'$user->isStaff()',
            ),
            array('deny',
                'users'=>array('*'),
            ),
        );
    }

    public function actionView($id)
    {
        $id = (int)$id;
        if (!Yii::app()->user->isStaff() && (Yii::app()->params['hide_userlist'] === true)
            && (((int)Yii::app()->user->id) !== $id))
        {
            throw new CHttpException(403, Yii::t('mc', 'You are not authorized to perform this action.'));
        }
        $model = $this->loadModel($id);
        $model->scenario = Yii::app()->user->isSuperuser() ? 'superuserUpdate' : 'update';
        
        if (Yii::app()->user->isStaff())
            $model->sendData = isset($_POST['User']['sendData']) ? $_POST['User']['sendData'] : true;

        $staffEdit = Yii::app()->user->isStaff() && !in_array($model->global_role, array('superuser', 'staff'));
        $edit = Yii::app()->user->isSuperuser()
            || ($staffEdit && $model->name != Yii::app()->user->superuser)
            || (Yii::app()->user->name == $model->name);

        if(isset($_POST['User']) && $edit)
        {
            if (Yii::app()->params['demo_mode'] == 'enabled' && in_array($model->name, array('admin', 'owner', 'user')))
            {
                Yii::app()->user->setFlash('user', Yii::t('mc', 'Function disabled in demo mode.'));
                $this->redirect(array('view','id'=>$model->id));
            }
            if (Yii::app()->user->name !== Yii::app()->user->superuser
                    && $model->name == Yii::app()->user->superuser)
            {
                Yii::app()->user->setFlash('user', Yii::t('mc', 'Access Denied'));
                $this->redirect(array('view','id'=>$model->id));
            }
            $nameBackup = $model->name;
            $pwBackup = $model->password;
            $emailBackup = $model->email;
            $globalRoleBackup = $model->global_role;
            $model->attributes=$_POST['User'];
            if (!strlen($_POST['User']['password']))
                $model->password = $pwBackup;
            if (Yii::app()->user->name == $model->name) // edit self, require confirmation for superuser as well
            {
                if (strlen($_POST['User']['password']) || $emailBackup != $model->email)
                {
                    if (!@strlen($_POST['oldPassword']))
                        $model->addError('oldPassword', Yii::t('mc', 'Enter current password to confirm the changes.'));
                    else if (!Yii::app()->user->verifyPassword($_POST['oldPassword']))
                        $model->addError('oldPassword', Yii::t('mc', 'Incorrect password'));
                }
                if (strlen($_POST['User']['password']) && $model->password != $model->confirmPassword)
                    $model->addError('confirmPassword', Yii::t('mc', 'New Password must be repeated exactly.'));
            }
            if (!(Yii::app()->user->isSuperuser() || $staffEdit) || $model->name == Yii::app()->user->superuser
                || $nameBackup == Yii::app()->user->superuser)
                $model->name = $nameBackup;
            if (!Yii::app()->user->isSuperuser())
                $model->global_role = $globalRoleBackup;
            if($model->validate(null, false) && $model->save(false))
            {
                Yii::log('Updated user '.$model->id);
                Yii::app()->user->setFlash('user', Yii::t('mc', 'User saved.'));
                $this->redirect(array('view','id'=>$model->id));
            }
        }
        else if (isset($_POST['action']) && (($edit && Yii::app()->params['user_api_keys'] === true) || Yii::app()->user->isSuperuser()))
        {
            switch ($_POST['action'])
            {
            case 'new_api_key':
                $keyChars = 'abcdefghijkmnopqrstuwxyzABCDEFGHJKLMNPQRSTUWXYZ23456789-+=$#@*&%';
                $key = '';
                for ($i = 0; $i < 14; $i++)
                    $key .= $keyChars[rand(0, strlen($keyChars) - 1)];
                $model->api_key = $key;
                $model->save(false);
                Yii::log('Generated API key for user '.$model->id);
                Yii::app()->user->setFlash('user', Yii::t('mc', 'New API key generated.'));
                $this->redirect(array('view','id'=>$model->id));
                break;
            case 'del_api_key':
                $model->api_key = '';
                $model->save(false);
                Yii::log('Deleted API key for user '.$model->id);
                Yii::app()->user->setFlash('user', Yii::t('mc', 'API key deleted.'));
                $this->redirect(array('view','id'=>$model->id));
                break;
            }
        }
        $model->password = '';
        $model->confirmPassword = '';

        $allRoles = array_combine(User::$roles, User::getRoleLabels());
        $allRoles['staff'] = Yii::t('mc', 'Staff');
        $allRoles['superuser'] = Yii::t('mc', 'Superuser');

        $servers = array();
        $spp = 10;
        if (Yii::app()->user->isStaff())
        {
            if ($spp = Setting::model()->findByPk('serversPerPage'))
                $spp = max(1, (int)$spp->value);
            $sql = 'select `server_id` from `user_server` where `user_id`=? and `role`=\'owner\'';
            $cmd = Yii::app()->db->createCommand($sql);
            $cmd->bindValue(1, $model->id);
            $ids = $cmd->queryColumn();
            $servers = Server::model()->findAllByAttributes(array('id'=>array_values($ids)));
        }
        $this->render('view',array(
            'model'=>$model,
            'allRoles'=>$allRoles,
            'staffEdit'=>$staffEdit,
            'edit'=>$edit,
            'servers'=>new CArrayDataProvider($servers, array(
                'sort'=>array(
                    'attributes'=>array(
                        'name', 
                    ),
                ),
                'pagination'=>array('pageSize'=>$spp),
            )),
        ));
    }

    public function actionCreate()
    {
        $model=new User('create');
        $model->sendData = isset($_POST['User']['sendData']) ? $_POST['User']['sendData'] : true;
        $staffEdit = Yii::app()->user->isStaff() && !in_array($model->global_role, array('superuser', 'staff'));

        if(isset($_POST['User']))
        {
            $globalRoleBackup = $model->global_role;
            $model->attributes=$_POST['User'];
            if (!strlen($model->password) &&  Yii::app()->params['mail_welcome'])
                $model->password = substr(md5(rand().$model->name), 5, 13);
            if (!Yii::app()->user->isSuperuser())
                $model->global_role = $globalRoleBackup;
            if($model->save())
            {
                Yii::log('Created user '.$model->id);
                $this->redirect(array('view','id'=>$model->id));
            }
        }

        $allRoles = array_combine(User::$roles, User::getRoleLabels());
        $allRoles['staff'] = Yii::t('mc', 'Staff');
        $allRoles['superuser'] = Yii::t('mc', 'Superuser');

        $this->render('view',array(
            'model'=>$model,
            'allRoles'=>$allRoles,
            'staffEdit'=>$staffEdit,
            'edit'=>true,
        ));
    }

    public function actionDelete($id)
    {
        $model = $this->loadModel($id);
        if (Yii::app()->params['demo_mode'] == 'enabled' && in_array($model->name, array('admin', 'owner', 'user')))
        {
            Yii::app()->user->setFlash('user', Yii::t('mc', 'Function disabled in demo mode.'));
            $this->redirect(array('view','id'=>$model->id));
        }
        if(Yii::app()->request->isPostRequest)
        {
            if (!Yii::app()->user->isSuperuser() && in_array($model->global_role, array('superuser', 'staff')))
                throw new CHttpException(400,Yii::t('mc', 'Access Denied'));
            if ($model->name != Yii::app()->user->superuser)
            {
                Yii::log('Deleting user '.$model->id);
                $model->delete();   
            }

            if(!isset($_GET['ajax']))
                $this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('index'));
        }
        else
            throw new CHttpException(400, Yii::t('mc', 'Invalid request.'));
    }

    public function actionIndex()
    {
        if (!Yii::app()->user->isStaff() && Yii::app()->params['hide_userlist'])
            throw new CHttpException(403, Yii::t('mc', 'You are not authorized to perform this action.'));
        $model=new User(Yii::app()->user->isStaff() ? 'search' : 'userSearch');
        $model->unsetAttributes();
        if(isset($_GET['User']))
            $model->attributes=$_GET['User'];

        $this->render('index',array(
            'model'=>$model,
        ));
    }

    public function actionAutocomplete($server_id = 0)
    {
        if (Yii::app()->user->isStaff())
            $sv = null;
        else if ($server_id)
        {
            $sv = Server::model()->findByPk((int)$server_id);
            if (!$sv || !Yii::app()->user->can($sv->id, 'manage users'))
                return '[]';
        }
        else
            return '[]';

        $res = array();
        if (isset($_GET['term']))
        {
            $crit = new CDbCriteria();
            $crit->select = '`id`, `name`';
            $crit->order = '`name` asc';
            $crit->limit = 10;
            if ($sv)
            {
                $crit->addCondition('(select `role` from `user_server` where `server_id`=:server and `user_id`=`id`)!=\'\'');
                $crit->params = array(':server'=>$sv->id);
            }
            $crit->compare('`name`', (string)$_GET['term'], true);
            foreach (User::model()->findAll($crit) as $user)
                $res[] = $user->name;
        }
        header('Content-type: application/json');
        echo CJSON::encode($res);
    }

    public function loadModel($id)
    {
        $model=User::model()->findByPk((int)$id);
        if($model===null)
            throw new CHttpException(404,Yii::t('mc', 'The requested page does not exist.'));
        return $model;
    }

    protected function performAjaxValidation($model)
    {
        if(isset($_POST['ajax']) && $_POST['ajax']==='user-form')
        {
            echo CActiveForm::validate($model);
            Yii::app()->end();
        }
    }
}
