<?php
return 'Mobile Theme';
