<?php
return 'Classic Theme';
