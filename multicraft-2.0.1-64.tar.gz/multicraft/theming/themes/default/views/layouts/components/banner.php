        <div class="row" id="header">
            <div id="logo">
                <h1><?php echo CHtml::encode(Yii::app()->name); ?><small><?php echo Yii::t('mc', 'Minecraft Server Manager') ?></small></h1>
            </div>
        </div><!-- header -->